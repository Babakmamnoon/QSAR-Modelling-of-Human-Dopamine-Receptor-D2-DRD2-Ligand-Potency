# Model Card — DRD2 Ligand Potency Regressor

A model card in the sense of Mitchell et al. (2019): what this model is for, what it
was built from, how well it works, and — most importantly — where it should not be
used.

---

## 1. Model details

| | |
|---|---|
| **Name** | DRD2 QSAR potency regressor |
| **Version** | 1.0.0 |
| **Type** | Ligand-based QSAR regression (supervised, tabular) |
| **Task** | Predict pIC50 (−log₁₀ IC50 in M) against human Dopamine Receptor D2 |
| **Input** | A SMILES string |
| **Output** | Predicted pIC50, a conformal prediction interval, an applicability-domain flag, and the nearest training neighbour |
| **Architecture** | Selected on a held-out validation set from a six-rung ladder: mean predictor, 1-NN Tanimoto, Ridge, Random Forest, SVR (RBF), XGBoost |
| **Representation** | ECFP4, 2048-bit binary Morgan fingerprint (radius 2); alternatives benchmarked in the ablation |
| **Licence** | MIT |
| **Contact** | Babak Mamnoon, Ph.D. |

The exact selected model, its hyperparameters, all metrics and the configuration hash
for a given run are in `reports/metrics.json`. This card describes the system; that
file describes the run.

---

## 2. Intended use

### Primary intended use

Ranking and triage of small molecules for **DRD2 binding potency**, within the
chemical space the model was trained on, as one input among several to a
medicinal-chemistry decision.

Concretely, it is appropriate for:

- prioritising which analogues in a series to synthesise next;
- flagging compounds in a virtual library that merit a docking or an assay slot;
- providing a prior in an active-learning loop, using the conformal intervals to
  choose the next measurements.

### Intended users

Computational and medicinal chemists who can read an applicability-domain flag and
act on it. The model is not designed for use by anyone who will see only the point
prediction.

### Out of scope — do not use this model for

- **Any clinical, diagnostic or therapeutic decision.** This is a research tool.
- **Absolute potency claims.** A predicted pIC50 of 8.4 means "probably potent",
  not "IC50 = 4 nM". Quote the interval or quote nothing.
- **Compounds outside the applicability domain.** The `in_domain` flag exists to be
  obeyed. Out-of-domain predictions are a rank order at best.
- **Functional activity, efficacy or mechanism.** This model predicts a binding
  potency number. It says nothing about whether a compound is an agonist, an
  antagonist, an inverse agonist or a biased ligand — a distinction that matters
  enormously at DRD2 and that the training data only partly annotates.
- **Selectivity.** DRD2 potency alone does not tell you about DRD1, DRD3, 5-HT₂A,
  hERG or anything else. DRD2/DRD3 selectivity in particular is a real and unsolved
  problem that this single-target model does not address.
- **Safety assessment.** See §6.

---

## 3. Training data

| | |
|---|---|
| **Source** | ChEMBL, target `CHEMBL217` (human Dopamine Receptor D2) — live REST query, or a raw web-interface export (`DRD2.csv`, 2480 IC50 activity rows) |
| **Curated size** | 828 unique parent structures, pIC50 4.03 – 9.54 (SD 1.16), 434 Bemis–Murcko scaffolds |
| **Query** | `standard_type=IC50`, `standard_relation='='`, `standard_units='nM'`, `assay_type='B'`, `target_organism='Homo sapiens'` |
| **Provenance** | ChEMBL release, pull date and full query recorded in `data/raw/CHEMBL217_pull_manifest.json` |
| **Endpoint** | pIC50 = 9 − log₁₀(IC50 in nM) |
| **Curation audit** | `reports/curation_audit.csv` — per-stage row counts |
| **Rejected records** | `reports/rejected_records.csv` — every removed row, with its reason |

### Curation applied

1. Censored measurements (`>`, `<`, `≥`, `≤`) dropped — they are not regression targets.
2. Non-nanomolar units dropped rather than converted on assumption.
3. Rows carrying a ChEMBL `data_validity_comment` dropped.
4. **Plausibility window on pIC50 of [3, 11].** This removes physically impossible
   potencies arising from unit-handling errors — in the legacy dataset, five
   compounds with pIC50 up to 16.4 (sub-femtomolar), including dopamine,
   norepinephrine and serotonin.
5. RDKit standardization: metal disconnection, normalization, largest-fragment
   selection (strips salts), uncharging, canonical tautomer.
6. Element and heavy-atom sanity filters.
7. Mechanism policy: known agonists identifiable and separable via ChEMBL
   `action_type` plus a documented reference list.
8. Deduplication on the **InChIKey connectivity layer**; replicates aggregated by
   median; compounds whose replicates span more than 1 log unit dropped as
   irreproducible.

### Known composition biases

- Heavily **congeneric**: a small number of Bemis–Murcko scaffolds account for a
  large fraction of compounds, reflecting how medicinal-chemistry series are published.
- **Literature-selected**, not a designed screen: compounds were made and measured
  because someone thought they would be active.
- **Multi-laboratory**, so assay conditions, cell lines and radioligands vary.
- **Censored measurements removed.** 472 rows reported as `IC50 > x` are dropped,
  because they are not regression targets. They are also overwhelmingly the weak and
  inactive compounds, so the retained set under-represents genuine inactivity — see §6.
- Optionally **potency-truncated** (`apply_activity_cutoff`), disabled by default.

---

## 4. Evaluation

### Protocol

- **Split:** Bemis–Murcko **scaffold** split, three-way (train / validation / test).
  No scaffold and no structure appears in two partitions; both guarantees are
  asserted in code and tested in CI.
- **Model selection:** on the validation set only. The test set is used once.
- **Metrics:** R², RMSE, MAE, MedAE, Pearson r, Spearman ρ, Kendall τ, and the
  fraction of predictions within 0.5 and 1.0 log units — every one with a **95%
  percentile bootstrap confidence interval** (1000 resamples).
- **Additional validation:** scaffold-grouped nested cross-validation;
  y-scrambling with an empirical p-value; repeated splits across 10 seeds; a
  learning curve; the full baseline ladder; a molecular-representation ablation.
- **Comparison:** the same benchmark under a random split, reported side by side,
  so the optimism a random split introduces is visible rather than hidden.

### How to read the numbers

Three framings are essential and are stated in the README alongside the results:

1. **Against the 1-NN Tanimoto baseline.** A model that does not beat "copy the most
   similar measured compound" has not learned anything a lookup table lacks.
2. **Against the mean predictor.** On a potency-truncated dataset the target variance
   is small by construction, so R² is structurally low and a model can be genuinely
   useful while scoring near zero — or useless while scoring positive. The mean
   predictor is the floor that disambiguates this.
3. **Against the assay-noise ceiling.** Pooled multi-laboratory ChEMBL IC50 data has a
   reproducibility limit of roughly **0.7 log units RMSE** (Kalliokoski et al. 2013,
   *PLoS ONE* 8:e61007). No model can do better. A model that appears to has leaked.

---

## 5. Uncertainty quantification

**Applicability domain.** Mean Tanimoto similarity to the *k* = 5 nearest training
compounds, with the boundary set at the 5th percentile of the training set's own
leave-one-out neighbour similarity. Reported not as a flag alone but as an
**error-versus-distance curve** with confidence intervals, which quantifies how fast
predictions degrade outside the training neighbourhood.

**Conformal prediction intervals.** Split-conformal, with the finite-sample-corrected
quantile of held-out calibration residuals. The coverage guarantee is *marginal* and
assumes **exchangeability** between calibration and test data — an assumption a
scaffold split deliberately violates. Empirical coverage is therefore expected to
fall below nominal, and the observed shortfall is reported rather than papered over.

---

## 6. Limitations, risks and ethical considerations

### Scientific limitations

1. **Prospective performance is materially worse than the headline.** Under a
   temporal split (train pre-2015, test 2015-onward) the best model reaches RMSE 1.056
   against a mean-predictor floor of 1.238, versus 0.868 on a scaffold split. Quote the
   temporal number when describing expected deployment behaviour.
2. **Censored data discarded.** 472 `IC50 > x` rows were dropped as non-targets. Since
   these are largely the inactives, the model is weaker at recognising inactivity than
   its scaffold-split metrics suggest, and should not be used as a standalone
   virtual-screening filter without a classification arm trained on that data.
3. **Mechanistic heterogeneity.** ChEMBL annotates mechanism only for well-studied
   compounds, so agonists and antagonists may still be pooled in the unlabelled
   majority.
4. **Congeneric coverage.** Whole regions of DRD2-relevant chemistry are absent from
   the training data. The scaffold split makes the evaluation honest; it does not
   make the coverage better.
5. **Assay heterogeneity** across source laboratories sets the noise floor in §4.
6. **2D only.** No conformational, protein-structural or free-energy information.
7. **Activity cliffs.** Near-identical compounds with large potency differences are
   enumerated in `reports/activity_cliffs.csv`; the model's largest errors
   concentrate there, and no fingerprint-similarity model resolves them.

### Safety and dual-use

DRD2 is the principal target of antipsychotic drugs, and DRD2 antagonism carries real
clinical liabilities — extrapyramidal symptoms, tardive dyskinesia,
hyperprolactinaemia, and neuroleptic malignant syndrome. DRD2 agonism is central to
Parkinson's disease therapy and carries its own risks including impulse-control
disorders.

This model predicts one *in vitro* binding number. It is not a safety model, not an
efficacy model, and not a substitute for pharmacology. Any compound it prioritises
requires the full experimental and regulatory path before it is anything more than a
hypothesis.

The model is a potency-ranking aid over published medicinal chemistry. It does not
provide synthesis routes, and it offers no capability relevant to producing harmful
compounds that is not already available in the public literature it was trained on.

### Fairness

No human-subject data is involved, so demographic fairness considerations do not
apply in the usual sense. The relevant analogue of bias here is **chemical-space
bias** — the model is systematically better on chemistry resembling published DRD2
series — and it is quantified directly by the applicability-domain analysis.

---

## 7. Reproducing and auditing

```bash
conda env create -f environment.yml && conda activate drd2-qsar
python -m drd2_qsar.run --config configs/drd2.yaml
pytest tests -q
```

Every run writes `reports/metrics.json` containing the configuration hash, the full
environment manifest (package versions, git revision), the data provenance manifest
and every metric with its interval. Two runs of the same configuration against the
same cached ChEMBL pull produce identical numbers.

---

## 8. Citation

If this work is used, please cite the underlying resources:

- Zdrazil, B. *et al.* **ChEMBL: a highly effective platform for drug discovery.**
  *Nucleic Acids Research* (2024) 52:D1180–D1192.
- Landrum, G. **RDKit: Open-source cheminformatics.** https://www.rdkit.org
- Pedregosa, F. *et al.* **Scikit-learn: Machine Learning in Python.** *JMLR* (2011)
  12:2825–2830.
- Chen, T. & Guestrin, C. **XGBoost: A Scalable Tree Boosting System.** *KDD* (2016).
- Lundberg, S. & Lee, S.-I. **A Unified Approach to Interpreting Model Predictions.**
  *NeurIPS* (2017).
- Bemis, G. & Murcko, M. **The Properties of Known Drugs. 1. Molecular Frameworks.**
  *J. Med. Chem.* (1996) 39:2887–2893.
- Kalliokoski, T. *et al.* **Comparability of Mixed IC50 Data — A Statistical
  Analysis.** *PLoS ONE* (2013) 8:e61007.
- OECD. **Guidance Document on the Validation of (Q)SAR Models.** ENV/JM/MONO(2007)2.
- Mitchell, M. *et al.* **Model Cards for Model Reporting.** *FAT\** (2019).
