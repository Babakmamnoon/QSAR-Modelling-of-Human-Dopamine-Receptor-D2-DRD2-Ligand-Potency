#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Push this project to the GitHub repository the notebook expects.
#
# The notebook is only the narrative layer -- every computation lives in the
# drd2_qsar package. A repository holding just DRD2.csv and the .ipynb cannot
# run, which is why `from drd2_qsar import ...` fails in Colab.
#
# Run this from the project root (the folder containing pyproject.toml):
#     bash push_to_github.sh
# ---------------------------------------------------------------------------
set -euo pipefail

REPO="QSAR-Modelling-of-Human-Dopamine-Receptor-D2-DRD2-Ligand-Potency"
REMOTE="https://github.com/Babakmamnoon/${REPO}.git"
BRANCH="main"

if [[ ! -f pyproject.toml || ! -d src/drd2_qsar ]]; then
    echo "ERROR: run this from the project root (the folder with pyproject.toml)." >&2
    exit 1
fi

# DRD2.csv lives at the repo root and doubles as the offline fallback.
if [[ ! -f DRD2.csv && -f data/raw/DRD2_legacy_snapshot.csv ]]; then
    cp data/raw/DRD2_legacy_snapshot.csv DRD2.csv
    echo "staged DRD2.csv at the repository root"
fi

# Keep the Colab badge path honest: the notebook is under notebooks/.
if [[ ! -d .git ]]; then
    git init -q
    git branch -M "${BRANCH}"
fi

if ! git remote get-url origin >/dev/null 2>&1; then
    git remote add origin "${REMOTE}"
else
    git remote set-url origin "${REMOTE}"
fi

git add -A
if git diff --cached --quiet; then
    echo "nothing to commit"
else
    git commit -q -m "Add drd2_qsar package, configs, tests, figures and reports

The repository previously held only DRD2.csv, the notebook and the README,
so the notebook could not import drd2_qsar. This adds the package the
notebook runs on."
    echo "committed"
fi

echo
echo "About to push to ${REMOTE} (branch ${BRANCH})."
echo "The remote already has commits, so this will MERGE histories."
echo "If you would rather replace what is there, run:  git push -u origin ${BRANCH} --force"
echo
read -r -p "Push now? [y/N] " reply
[[ "${reply}" =~ ^[Yy]$ ]] || { echo "aborted"; exit 0; }

git pull --rebase --allow-unrelated-histories origin "${BRANCH}" || {
    echo
    echo "Rebase hit a conflict (most likely README.md or the notebook, which"
    echo "exist in both histories). Resolve the conflicts, then run:"
    echo "    git rebase --continue && git push -u origin ${BRANCH}"
    exit 1
}
git push -u origin "${BRANCH}"

echo
echo "Done. Verify the package is live:"
echo "  curl -s -o /dev/null -w '%{http_code}\\n' \\"
echo "    https://raw.githubusercontent.com/Babakmamnoon/${REPO}/${BRANCH}/pyproject.toml"
echo "A 200 means the notebook's setup cell will now work in Colab."
