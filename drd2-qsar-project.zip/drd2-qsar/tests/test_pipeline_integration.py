"""End-to-end smoke test on a tiny synthetic dataset.

Fast enough for CI, real enough to catch a broken wiring between stages.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from rdkit import Chem

from drd2_qsar import config, evaluate, features, models, splits


@pytest.fixture(scope="module")
def toy() -> pd.DataFrame:
    """A small congeneric-ish set with a real, learnable structure–activity signal."""
    cores = [
        "COc1ccc(N2CCN(C)CC2)cc1{}",
        "c1ccc2[nH]c({})cc2c1",
        "O=C(Nc1ccccc1{})c1ccccc1",
        "Clc1ccc(Oc2ccccc2{})cc1",
        "C1CCN(Cc2ccccc2{})CC1",
    ]
    subs = ["", "C", "CC", "CCC", "Cl", "Br", "F", "O", "N", "CO"]
    rows = []
    rng = np.random.default_rng(0)
    for ci, core in enumerate(cores):
        for si, sub in enumerate(subs):
            smi = core.format(sub)
            if Chem.MolFromSmiles(smi) is None:
                continue
            mol = Chem.MolFromSmiles(smi)
            # signal: potency tracks heavy-atom count plus a core effect
            pic50 = 5.0 + 0.08 * mol.GetNumHeavyAtoms() + 0.3 * ci + rng.normal(0, 0.15)
            rows.append(
                {
                    "chembl_id": f"CHEMBL{ci}{si}",
                    "smiles": Chem.MolToSmiles(mol),
                    "pIC50": pic50,
                    "inchikey14": Chem.MolToInchiKey(mol).split("-")[0],
                    "year": 2010 + si,
                }
            )
    return pd.DataFrame(rows).drop_duplicates("inchikey14").reset_index(drop=True)


def test_toy_dataset_is_usable(toy):
    assert len(toy) > 30
    assert toy["pIC50"].std() > 0.3


def test_full_modelling_cycle_runs(toy):
    work = splits.add_scaffolds(toy)
    idx = splits.scaffold_split(work, test_size=0.25, val_size=0.15, seed=0)
    splits.assert_no_structure_leak(work, idx)

    X = features.get_featurizer("ecfp4", 1024).transform(work["smiles"].tolist())
    y = work["pIC50"].to_numpy(float)
    fit = np.concatenate([idx["train"], idx["val"]])

    m = models.get_model("random_forest", seed=0, n_jobs=1).fit(X[fit], y[fit])
    pred = m.predict(X[idx["test"]])

    boot = evaluate.bootstrap_metrics(y[idx["test"]], pred, n_resamples=100, seed=0)
    assert set(boot["metric"]) >= {"R2", "RMSE", "MAE", "Spearman_rho"}
    rmse = boot.loc[boot["metric"] == "RMSE", "value"].iloc[0]
    assert np.isfinite(rmse) and rmse > 0


def test_model_beats_the_mean_predictor_on_learnable_signal(toy):
    """If a model cannot beat the mean on data with planted signal, it is broken."""
    work = splits.add_scaffolds(toy)
    idx = splits.random_split(work, 0.25, 0.15, seed=0)
    X = features.get_featurizer("ecfp4", 1024).transform(work["smiles"].tolist())
    y = work["pIC50"].to_numpy(float)
    fit = np.concatenate([idx["train"], idx["val"]])

    rf = models.get_model("random_forest", seed=0, n_jobs=1).fit(X[fit], y[fit])
    dm = models.get_model("dummy_mean", seed=0).fit(X[fit], y[fit])

    rf_rmse = evaluate.regression_metrics(y[idx["test"]], rf.predict(X[idx["test"]]))["RMSE"]
    dm_rmse = evaluate.regression_metrics(y[idx["test"]], dm.predict(X[idx["test"]]))["RMSE"]
    assert rf_rmse < dm_rmse


def test_applicability_domain_end_to_end(toy):
    work = splits.add_scaffolds(toy)
    idx = splits.scaffold_split(work, 0.25, 0.15, seed=0)
    fit = np.concatenate([idx["train"], idx["val"]])
    fps = features.rdkit_fps(work["smiles"].tolist())

    ad = evaluate.ApplicabilityDomain(k=3).fit([fps[i] for i in fit])
    X = features.get_featurizer("ecfp4", 1024).transform(work["smiles"].tolist())
    y = work["pIC50"].to_numpy(float)
    m = models.get_model("random_forest", seed=0, n_jobs=1).fit(X[fit], y[fit])

    prof = ad.error_profile(
        [fps[i] for i in idx["test"]],
        y[idx["test"]],
        m.predict(X[idx["test"]]),
        n_bins=3,
        n_boot=50,
        seed=0,
    )
    assert len(prof) >= 1
    assert (prof["rmse_ci_low"] <= prof["RMSE"]).all()
    assert (prof["RMSE"] <= prof["rmse_ci_high"]).all()


def test_config_roundtrip(tmp_path):
    p = tmp_path / "c.yaml"
    p.write_text("project:\n  seed: 7\n  data_dir: d\nsplit:\n  strategy: scaffold\n")
    cfg = config.load_config(p)
    assert cfg.seed == 7
    assert cfg.get("split.strategy") == "scaffold"
    assert cfg.get("nothing.here", "default") == "default"
    assert len(cfg.fingerprint()) == 12


def test_global_seed_makes_numpy_deterministic():
    config.set_global_seed(123)
    a = np.random.rand(5)
    config.set_global_seed(123)
    np.testing.assert_array_equal(a, np.random.rand(5))
