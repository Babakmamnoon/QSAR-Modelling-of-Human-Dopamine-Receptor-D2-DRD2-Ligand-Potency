"""Split tests.

The leakage tests here are the most important in the suite. A QSAR pipeline can
be wrong in many ways; leaking the test set is the way that produces a number
good enough that nobody looks further.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drd2_qsar import splits

SMILES = [
    "COc1ccc(N2CCN(CC3CC3c3ccccc3)CC2)cc1",
    "COc1ccc(N2CCN(CC3CC3c3ccccc3)CC2)cc1C",
    "COc1ccc(N2CCN(CC3CC3c3ccccc3)CC2)cc1Cl",
    "c1ccc2[nH]ccc2c1",
    "c1ccc2[nH]c(C)cc2c1",
    "c1ccc2[nH]c(CC)cc2c1",
    "C1CCNCC1",
    "C1CCN(C)CC1",
    "C1CCN(CC)CC1",
    "O=C(Nc1ccccc1)c1ccccc1",
    "O=C(Nc1ccccc1C)c1ccccc1",
    "O=C(Nc1ccccc1Cl)c1ccccc1",
    "c1ccc(-c2ccccc2)cc1",
    "Cc1ccc(-c2ccccc2)cc1",
    "Clc1ccc(-c2ccccc2)cc1",
    "c1ccc(Oc2ccccc2)cc1",
    "Cc1ccc(Oc2ccccc2)cc1",
    "Clc1ccc(Oc2ccccc2)cc1",
    "C1CCOC1",
    "C1CCOCC1",
]


@pytest.fixture
def df() -> pd.DataFrame:
    rng = np.random.default_rng(0)
    return pd.DataFrame(
        {
            "chembl_id": [f"CHEMBL{i}" for i in range(len(SMILES))],
            "smiles": SMILES,
            "pIC50": rng.normal(7.0, 1.0, len(SMILES)),
            "inchikey14": [f"KEY{i}" for i in range(len(SMILES))],
            "year": rng.integers(2005, 2022, len(SMILES)),
        }
    )


# --------------------------------------------------------------------------- #
def test_scaffold_is_computed(df):
    out = splits.add_scaffolds(df)
    assert "scaffold" in out.columns
    assert out["scaffold"].notna().all()
    # the three methoxyphenyl-piperazines share one framework
    assert out["scaffold"].nunique() < len(df)


def test_scaffold_split_has_no_scaffold_overlap(df):
    idx = splits.scaffold_split(df, test_size=0.25, val_size=0.15, seed=0)
    work = splits.add_scaffolds(df)
    sets = {k: set(work.iloc[v]["scaffold"]) for k, v in idx.items()}
    assert not (sets["train"] & sets["test"])
    assert not (sets["train"] & sets["val"])
    assert not (sets["val"] & sets["test"])


def test_split_partitions_are_disjoint_and_complete(df):
    for fn in (
        lambda: splits.scaffold_split(df, 0.25, 0.15, seed=0),
        lambda: splits.random_split(df, 0.25, 0.15, seed=0),
    ):
        idx = fn()
        all_idx = np.concatenate([idx["train"], idx["val"], idx["test"]])
        assert len(all_idx) == len(df), "every compound must land somewhere"
        assert len(set(all_idx)) == len(df), "no compound may land twice"


def test_structure_leak_detector_catches_a_planted_leak(df):
    """The guard must actually fire — a check that never fails is not a check."""
    idx = splits.random_split(df, 0.25, 0.15, seed=0)
    work = df.copy()
    # plant a duplicate structure key across train and test
    work.loc[idx["train"][0], "inchikey14"] = work.loc[idx["test"][0], "inchikey14"]
    with pytest.raises(AssertionError, match="Structure leakage"):
        splits.assert_no_structure_leak(work, idx)


def test_structure_leak_detector_passes_on_clean_split(df):
    idx = splits.scaffold_split(df, 0.25, 0.15, seed=0)
    splits.assert_no_structure_leak(df, idx)  # must not raise


def test_scaffold_split_is_deterministic(df):
    a = splits.scaffold_split(df, 0.25, 0.15, seed=7)
    b = splits.scaffold_split(df, 0.25, 0.15, seed=7)
    for k in a:
        np.testing.assert_array_equal(a[k], b[k])


def test_random_split_respects_requested_sizes(df):
    idx = splits.random_split(df, test_size=0.25, val_size=0.25, seed=0)
    assert len(idx["test"]) == pytest.approx(0.25 * len(df), abs=1)
    assert len(idx["val"]) == pytest.approx(0.25 * len(df), abs=1)


def test_temporal_split_puts_new_literature_in_test(df):
    idx = splits.temporal_split(df, "year", train_before=2015, seed=0)
    assert (df.iloc[idx["test"]]["year"] >= 2015).all()
    assert (df.iloc[idx["train"]]["year"] < 2015).all()


def test_temporal_split_refuses_when_years_are_missing(df):
    work = df.copy()
    work.loc[work.index[:15], "year"] = np.nan
    with pytest.raises(ValueError, match="publication year"):
        splits.temporal_split(work, "year", 2015)


def test_make_split_dispatches(df):
    cfg = {
        "strategy": "scaffold",
        "test_size": 0.25,
        "val_size": 0.15,
        "scaffold": {"balanced": True, "include_chirality": False},
    }
    idx = splits.make_split(df, cfg, seed=0)
    assert set(idx) == {"train", "val", "test"}
    with pytest.raises(ValueError, match="Unknown split strategy"):
        splits.make_split(df, {"strategy": "nonsense"}, seed=0)


def test_split_summary_shape(df):
    work = splits.add_scaffolds(df)
    idx = splits.scaffold_split(df, 0.25, 0.15, seed=0)
    summ = splits.split_summary(work, idx)
    assert set(summ["partition"]) == {"train", "val", "test"}
    assert summ["n"].sum() == len(df)
