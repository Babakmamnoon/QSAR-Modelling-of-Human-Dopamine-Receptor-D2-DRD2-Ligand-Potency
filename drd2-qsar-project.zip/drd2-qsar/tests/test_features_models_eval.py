"""Featurizer, model and evaluation tests.

Metric functions are checked against hand-computed values rather than against
another library, so a silent convention change (R² vs squared Pearson, say)
fails the suite instead of quietly shifting every reported number.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drd2_qsar import evaluate, features, models

SMILES = [
    "COc1ccc(N2CCNCC2)cc1",
    "c1ccc2[nH]ccc2c1",
    "O=C(Nc1ccccc1)c1ccccc1",
    "C1CCNCC1",
    "Clc1ccc(Oc2ccccc2)cc1",
]


# --------------------------------------------------------------------------- #
# Features
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "name,expected_cols",
    [("ecfp4", 2048), ("ecfp6", 2048), ("fcfp4", 2048), ("maccs", 167)],
)
def test_fingerprint_shapes(name, expected_cols):
    f = features.get_featurizer(name, n_bits=2048)
    X = f.transform(SMILES)
    assert X.shape == (len(SMILES), expected_cols)


def test_fingerprints_are_binary():
    X = features.get_featurizer("ecfp4").transform(SMILES)
    assert set(np.unique(X)).issubset({0.0, 1.0})


def test_featurization_is_deterministic():
    f = features.get_featurizer("ecfp4")
    np.testing.assert_array_equal(f.transform(SMILES), f.transform(SMILES))


def test_identical_smiles_give_identical_vectors():
    f = features.get_featurizer("ecfp4")
    X = f.transform([SMILES[0], SMILES[0]])
    np.testing.assert_array_equal(X[0], X[1])


def test_different_molecules_give_different_vectors():
    f = features.get_featurizer("ecfp4")
    X = f.transform(SMILES)
    assert not np.array_equal(X[0], X[1])


def test_invalid_smiles_yields_zero_vector_not_a_crash():
    f = features.get_featurizer("ecfp4")
    X = f.transform(["not_a_molecule"])
    assert X.shape == (1, 2048)
    assert X.sum() == 0


def test_descriptors_have_no_nan_or_inf():
    X = features.get_featurizer("rdkit_descriptors").transform(SMILES + ["bad_smiles"])
    assert np.isfinite(X).all()


def test_concat_featurizer_width():
    f = features.get_featurizer("ecfp4_plus_descriptors", n_bits=2048)
    X = f.transform(SMILES)
    n_desc = features.get_featurizer("rdkit_descriptors").n_bits
    assert X.shape == (len(SMILES), 2048 + n_desc)


def test_unknown_featurizer_raises():
    with pytest.raises(ValueError, match="Unknown featurizer"):
        features.get_featurizer("quantum_vibes")


def test_tanimoto_matrix_self_similarity_is_one():
    fps = features.rdkit_fps(SMILES)
    sim = features.tanimoto_matrix(fps, fps)
    np.testing.assert_allclose(np.diag(sim), 1.0, atol=1e-6)
    assert (sim >= -1e-6).all() and (sim <= 1 + 1e-6).all()


# --------------------------------------------------------------------------- #
# Models
# --------------------------------------------------------------------------- #
def test_tanimoto_knn_recovers_training_values_exactly():
    """1-NN on a compound it has already seen must return that compound's value."""
    X = features.get_featurizer("ecfp4").transform(SMILES)
    y = np.array([6.0, 7.0, 8.0, 9.0, 5.0])
    m = models.TanimotoKNNRegressor(n_neighbors=1).fit(X, y)
    np.testing.assert_allclose(m.predict(X), y)


def test_tanimoto_knn_similarity_matches_rdkit():
    X = features.get_featurizer("ecfp4").transform(SMILES)
    m = models.TanimotoKNNRegressor().fit(X, np.arange(len(SMILES), dtype=float))
    ours = m._similarity(X)
    fps = features.rdkit_fps(SMILES)
    theirs = features.tanimoto_matrix(fps, fps)
    np.testing.assert_allclose(ours, theirs, atol=1e-5)


@pytest.mark.parametrize(
    "name", ["dummy_mean", "knn_tanimoto", "ridge", "random_forest", "svr", "xgboost"]
)
def test_every_model_in_the_ladder_fits_and_predicts(name):
    rng = np.random.default_rng(0)
    X = rng.integers(0, 2, size=(60, 64)).astype(np.float32)
    y = X[:, :5].sum(axis=1) + rng.normal(0, 0.1, 60)
    m = models.get_model(name, seed=0, n_jobs=1).fit(X, y)
    pred = m.predict(X)
    assert pred.shape == (60,)
    assert np.isfinite(pred).all()


def test_unknown_model_raises():
    with pytest.raises(ValueError, match="Unknown model"):
        models.get_model("alchemy")


# --------------------------------------------------------------------------- #
# Metrics — checked against hand computation
# --------------------------------------------------------------------------- #
def test_perfect_prediction_metrics():
    y = np.array([5.0, 6.0, 7.0, 8.0, 9.0])
    m = evaluate.regression_metrics(y, y)
    assert m["R2"] == pytest.approx(1.0)
    assert m["RMSE"] == pytest.approx(0.0)
    assert m["MAE"] == pytest.approx(0.0)
    assert m["pct_within_1.0"] == pytest.approx(100.0)


def test_rmse_matches_hand_computation():
    y_true = np.array([1.0, 2.0, 3.0, 4.0])
    y_pred = np.array([1.5, 2.5, 2.5, 3.5])
    # residuals all ±0.5 -> RMSE 0.5, MAE 0.5
    m = evaluate.regression_metrics(y_true, y_pred)
    assert m["RMSE"] == pytest.approx(0.5)
    assert m["MAE"] == pytest.approx(0.5)


def test_r2_is_coefficient_of_determination_not_squared_pearson():
    """A perfectly correlated but biased prediction has r=1 and R2<1."""
    y_true = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    y_pred = y_true + 2.0  # perfect correlation, constant offset
    m = evaluate.regression_metrics(y_true, y_pred)
    assert m["Pearson_r"] == pytest.approx(1.0)
    assert m["R2"] < 0.5


def test_mean_predictor_has_zero_r2():
    y = np.array([4.0, 5.0, 6.0, 7.0, 8.0])
    m = evaluate.regression_metrics(y, np.full_like(y, y.mean()))
    assert m["R2"] == pytest.approx(0.0, abs=1e-9)


def test_pct_within_thresholds():
    y_true = np.array([7.0, 7.0, 7.0, 7.0])
    y_pred = np.array([7.2, 7.6, 8.5, 6.9])  # |e| = .2 .6 1.5 .1
    m = evaluate.regression_metrics(y_true, y_pred)
    assert m["pct_within_0.5"] == pytest.approx(50.0)
    assert m["pct_within_1.0"] == pytest.approx(75.0)


# --------------------------------------------------------------------------- #
# Bootstrap
# --------------------------------------------------------------------------- #
def test_bootstrap_intervals_bracket_the_point_estimate():
    rng = np.random.default_rng(0)
    y_true = rng.normal(7, 1, 200)
    y_pred = y_true + rng.normal(0, 0.5, 200)
    boot = evaluate.bootstrap_metrics(y_true, y_pred, n_resamples=200, seed=0)
    for _, r in boot.iterrows():
        if r["metric"] == "n" or not np.isfinite(r["ci_low"]):
            continue
        assert r["ci_low"] <= r["value"] <= r["ci_high"], f"{r['metric']} CI excludes point"


def test_bootstrap_is_reproducible():
    rng = np.random.default_rng(1)
    y = rng.normal(7, 1, 100)
    p = y + rng.normal(0, 0.4, 100)
    a = evaluate.bootstrap_metrics(y, p, n_resamples=100, seed=5)
    b = evaluate.bootstrap_metrics(y, p, n_resamples=100, seed=5)
    pd.testing.assert_frame_equal(a, b)


def test_wider_data_gives_wider_intervals():
    """Fewer compounds must produce a wider interval — a sanity check on the CI."""
    rng = np.random.default_rng(2)
    y_big = rng.normal(7, 1, 400)
    p_big = y_big + rng.normal(0, 0.5, 400)
    small = slice(0, 40)
    w_big = evaluate.bootstrap_metrics(y_big, p_big, 300, seed=0)
    w_small = evaluate.bootstrap_metrics(y_big[small], p_big[small], 300, seed=0)
    big = w_big.loc[w_big["metric"] == "RMSE", "ci_width"].iloc[0]
    sml = w_small.loc[w_small["metric"] == "RMSE", "ci_width"].iloc[0]
    assert sml > big


def test_format_ci_string():
    row = pd.Series({"value": 0.6123, "ci_low": 0.5412, "ci_high": 0.6741})
    assert evaluate.format_ci(row) == "0.612 [0.541, 0.674]"


# --------------------------------------------------------------------------- #
# Applicability domain and conformal
# --------------------------------------------------------------------------- #
def test_applicability_domain_scores_are_bounded():
    fps = features.rdkit_fps(SMILES)
    ad = evaluate.ApplicabilityDomain(k=2).fit(fps)
    s = ad.score(fps)
    assert ((s >= 0) & (s <= 1)).all()


def test_training_compounds_are_inside_their_own_domain():
    fps = features.rdkit_fps(SMILES * 4)
    ad = evaluate.ApplicabilityDomain(k=3).fit(fps)
    assert ad.in_domain(fps).mean() > 0.5


def test_conformal_intervals_contain_the_prediction():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(200, 10))
    y = X[:, 0] * 2 + rng.normal(0, 0.3, 200)
    res = evaluate.conformal_intervals(
        models.get_model("ridge", seed=0), X[:150], y[:150], X[150:], alpha=0.2, seed=0
    )
    assert (res["lower"] <= res["prediction"]).all()
    assert (res["prediction"] <= res["upper"]).all()
    assert res["half_width"] > 0


def test_conformal_coverage_is_approximately_nominal_when_exchangeable():
    """On an i.i.d. split the guarantee should actually hold."""
    rng = np.random.default_rng(3)
    X = rng.normal(size=(600, 8))
    y = X[:, 0] * 1.5 + rng.normal(0, 0.4, 600)
    res = evaluate.conformal_intervals(
        models.get_model("ridge", seed=0), X[:450], y[:450], X[450:], alpha=0.2, seed=0
    )
    cov = ((y[450:] >= res["lower"]) & (y[450:] <= res["upper"])).mean()
    assert cov >= 0.70  # nominal 0.80, allow finite-sample slack


def test_y_scrambling_null_is_centred_near_zero():
    rng = np.random.default_rng(0)
    X = rng.integers(0, 2, size=(150, 30)).astype(float)
    y = X[:, :3].sum(axis=1) + rng.normal(0, 0.2, 150)
    res = evaluate.y_scrambling(
        models.get_model("ridge", seed=0),
        X[:110],
        y[:110],
        X[110:],
        y[110:],
        n_permutations=15,
        seed=0,
    )
    assert res["real_r2"] > res["null_r2_mean"]
    assert res["null_r2_mean"] < 0.3
    assert 0 < res["p_value"] <= 1
