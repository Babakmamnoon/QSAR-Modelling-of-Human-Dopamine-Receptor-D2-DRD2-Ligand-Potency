"""Curation tests — the ones that would have caught the legacy dataset's defects."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from drd2_qsar import curate

STD_OPTS = {
    "largest_fragment": True,
    "uncharge": True,
    "normalize": True,
    "canonical_tautomer": True,
    "disconnect_metals": True,
    "remove_stereo": False,
}

CUR_CFG = {
    "pic50_min": 3.0,
    "pic50_max": 11.0,
    "standardize": STD_OPTS,
    "min_heavy_atoms": 8,
    "max_heavy_atoms": 70,
    "allowed_elements": ["H", "B", "C", "N", "O", "F", "Si", "P", "S", "Cl", "Se", "Br", "I"],
    "dedup_key": "inchikey14",
    "aggregate": "median",
    "max_replicate_spread": 1.0,
    "apply_activity_cutoff": False,
    "action_type_policy": "keep_all",
    "drop_validity_comments": ["Potential transcription error"],
}


def _raw(rows: list[dict]) -> pd.DataFrame:
    base = {
        "molecule_chembl_id": "CHEMBL1",
        "canonical_smiles": "CCO",
        "standard_type": "IC50",
        "standard_relation": "=",
        "standard_value": 100.0,
        "standard_units": "nM",
        "pchembl_value": 7.0,
        "assay_chembl_id": "A1",
        "assay_type": "B",
        "assay_description": "",
        "target_chembl_id": "CHEMBL217",
        "target_organism": "Homo sapiens",
        "document_chembl_id": "D1",
        "document_year": 2015,
        "data_validity_comment": None,
        "activity_comment": None,
        "potential_duplicate": 0,
    }
    return pd.DataFrame([{**base, **r} for r in rows])


# --------------------------------------------------------------------------- #
# Standardization
# --------------------------------------------------------------------------- #
def test_salt_is_stripped():
    """HBr salts must not become a different molecule from the free base."""
    std = curate.build_standardizer(STD_OPTS)
    salt = "Br.COc1ccc(N2CCNCC2)cc1"
    free = "COc1ccc(N2CCNCC2)cc1"
    assert std(salt) == std(free)
    assert "." not in std(salt)


def test_standardization_is_idempotent():
    """Standardizing twice must not change the answer."""
    std = curate.build_standardizer(STD_OPTS)
    for smi in ("CC(=O)Oc1ccccc1C(=O)O", "Cl.CN1CCN(c2ccccc2)CC1", "c1ccc2[nH]ccc2c1"):
        once = std(smi)
        assert once is not None
        assert std(once) == once


def test_invalid_smiles_returns_none():
    std = curate.build_standardizer(STD_OPTS)
    assert std("this is not a molecule") is None
    assert std("C1CC") is None


def test_inchikey_connectivity_collapses_salt_forms():
    k_salt, k14_salt = curate.inchikey_parts("Br.COc1ccc(N2CCNCC2)cc1")
    k_free, k14_free = curate.inchikey_parts("COc1ccc(N2CCNCC2)cc1")
    # the salt's own key differs, but after desalting the skeletons must match
    std = curate.build_standardizer(STD_OPTS)
    _, k14_std = curate.inchikey_parts(std("Br.COc1ccc(N2CCNCC2)cc1"))
    assert k14_std == k14_free


# --------------------------------------------------------------------------- #
# The five defects
# --------------------------------------------------------------------------- #
def test_implausible_potency_is_rejected():
    """This is the test that catches 'dopamine at pIC50 14'."""
    raw = _raw(
        [
            {
                "molecule_chembl_id": "GOOD",
                "canonical_smiles": "COc1ccc(N2CCNCC2)cc1",
                "standard_value": 100.0,
            },
            # 1e-7 nM  ->  pIC50 = 16
            {
                "molecule_chembl_id": "CHEMBL26736",
                "canonical_smiles": "NC1CCc2cc(O)c(O)cc2C1",
                "standard_value": 1e-7,
            },
        ]
    )
    clean, audit, rejected = curate.curate(raw, CUR_CFG)
    assert "CHEMBL26736" not in set(clean["chembl_id"])
    assert "GOOD" in set(clean["chembl_id"])
    assert (rejected["rejection_reason"].str.contains("plausibility")).any()


def test_censored_measurements_are_dropped():
    raw = _raw(
        [
            {"molecule_chembl_id": "EXACT", "canonical_smiles": "COc1ccc(N2CCNCC2)cc1"},
            {
                "molecule_chembl_id": "CENSORED",
                "canonical_smiles": "COc1ccc(N2CCNCC2)cc1C",
                "standard_relation": ">",
            },
        ]
    )
    clean, _, rejected = curate.curate(raw, CUR_CFG)
    assert "CENSORED" not in set(clean["chembl_id"])
    assert (rejected["rejection_reason"].str.contains("censored")).any()


def test_replicates_are_aggregated_by_median():
    raw = _raw(
        [
            {
                "molecule_chembl_id": "A",
                "canonical_smiles": "COc1ccc(N2CCNCC2)cc1",
                "standard_value": 100.0,
            },  # pIC50 7.0
            {
                "molecule_chembl_id": "A",
                "canonical_smiles": "COc1ccc(N2CCNCC2)cc1",
                "standard_value": 200.0,
            },  # pIC50 6.7
            {
                "molecule_chembl_id": "A",
                "canonical_smiles": "COc1ccc(N2CCNCC2)cc1",
                "standard_value": 150.0,
            },
        ]
    )
    clean, _, _ = curate.curate(raw, CUR_CFG)
    assert len(clean) == 1
    assert clean.iloc[0]["n_replicates"] == 3
    expected = float(np.median(9 - np.log10([100.0, 200.0, 150.0])))
    assert clean.iloc[0]["pIC50"] == pytest.approx(expected)


def test_irreproducible_replicates_are_dropped():
    """A compound measured at 1 nM and 100000 nM has no usable 'true' value."""
    raw = _raw(
        [
            {
                "molecule_chembl_id": "NOISY",
                "canonical_smiles": "COc1ccc(N2CCNCC2)cc1",
                "standard_value": 1.0,
            },
            {
                "molecule_chembl_id": "NOISY",
                "canonical_smiles": "COc1ccc(N2CCNCC2)cc1",
                "standard_value": 100000.0,
            },
            {
                "molecule_chembl_id": "CLEAN",
                "canonical_smiles": "COc1ccc(N2CCNCC2)cc1C",
                "standard_value": 50.0,
            },
        ]
    )
    clean, _, rejected = curate.curate(raw, CUR_CFG)
    assert "CLEAN" in set(clean["chembl_id"])
    assert len(clean) == 1
    assert (rejected["rejection_reason"].str.contains("replicate spread")).any()


def test_known_agonists_are_flagged_and_removable():
    cfg = {**CUR_CFG, "action_type_policy": "antagonists_only"}
    raw = _raw(
        [
            {
                "molecule_chembl_id": "CHEMBL59",
                "canonical_smiles": "NCCc1ccc(O)c(O)c1",
                "standard_value": 100.0,
            },
            {"molecule_chembl_id": "OTHER", "canonical_smiles": "COc1ccc(N2CCNCC2)cc1"},
        ]
    )
    clean, _, rejected = curate.curate(raw, cfg)
    assert "CHEMBL59" not in set(clean["chembl_id"])
    assert (rejected["rejection_reason"].str.contains("agonist")).any()


def test_audit_trail_accounts_for_every_row():
    """No compound may vanish without a recorded reason."""
    raw = _raw(
        [
            {"molecule_chembl_id": f"M{i}", "canonical_smiles": s, "standard_value": v}
            for i, (s, v) in enumerate(
                [
                    ("COc1ccc(N2CCNCC2)cc1", 100.0),
                    ("COc1ccc(N2CCNCC2)cc1C", 50.0),
                    ("CCO", 10.0),  # too small
                    ("NC1CCc2cc(O)c(O)cc2C1", 1e-7),  # implausible
                ]
            )
        ]
    )
    clean, audit, rejected = curate.curate(raw, CUR_CFG)
    frame = audit.to_frame()
    assert frame["n_removed"].sum() >= 2
    assert len(rejected) >= 2
    assert rejected["rejection_reason"].notna().all()


def test_pic50_conversion_is_correct():
    raw = _raw([{"canonical_smiles": "COc1ccc(N2CCNCC2)cc1", "standard_value": 1.0}])
    clean, _, _ = curate.curate(raw, CUR_CFG)
    assert clean.iloc[0]["pIC50"] == pytest.approx(9.0)  # 1 nM -> pIC50 9


def test_properties_computed_for_every_row():
    df = pd.Series(["COc1ccc(N2CCNCC2)cc1", "c1ccccc1", "not_a_molecule"])
    props = curate.compute_properties(df)
    assert len(props) == 3
    assert props.loc[0, "MW"] > 0
    assert np.isnan(props.loc[2, "MW"])
    assert "Lipinski_violations" in props.columns
