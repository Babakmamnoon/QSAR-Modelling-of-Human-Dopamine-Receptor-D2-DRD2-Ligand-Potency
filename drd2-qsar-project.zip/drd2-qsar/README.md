# QSAR Modelling of Human Dopamine Receptor D2 (DRD2) Ligand Potency

**An end-to-end, reproducible ligand-based potency model — from a live ChEMBL query to a calibrated, interpretable predictor with a stated applicability domain.**

[![CI](https://github.com/Babakmamnoon/QSAR-Modelling-of-Human-Dopamine-Receptor-D2-DRD2-Ligand-Potency/actions/workflows/ci.yml/badge.svg)](https://github.com/Babakmamnoon/QSAR-Modelling-of-Human-Dopamine-Receptor-D2-DRD2-Ligand-Potency/actions/workflows/ci.yml)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/Babakmamnoon/QSAR-Modelling-of-Human-Dopamine-Receptor-D2-DRD2-Ligand-Potency/blob/main/notebooks/DRD2_QSAR_Modeling.ipynb)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

Babak Mamnoon, Ph.D. · Computational Drug Discovery / Cheminformatics

---

## The short version

This project predicts DRD2 binding potency (pIC50) from structure. Fitting a model to
fingerprints is the easy part and it is four lines of code. The work here is in the
parts that decide whether the resulting number means anything:

- the data is **derived from a live ChEMBL query**, not read from a CSV of unknown origin;
- curation is **audited row by row**, and it removes five compounds whose recorded
  potencies were physically impossible;
- evaluation uses a **scaffold split**, with the random-split result published beside it
  so the optimism a random split introduces is visible rather than hidden;
- every metric carries a **95% bootstrap confidence interval**;
- the model is benchmarked against a **1-NN similarity lookup** and a **mean predictor**,
  because a model that cannot beat those has learned nothing;
- predictions ship with an **applicability-domain flag** and a **conformal interval**.

The headline result is modest, and the most useful thing in this repository is the
machinery that shows *why* it is modest rather than dressing it up.

```bash
pip install -e .
python -m drd2_qsar.run --config configs/drd2.yaml   # the whole pipeline, one command
```

---

## Table of contents

1. [Results](#1-results)
2. [What changed from v0, and why](#2-what-changed-from-v0-and-why)
3. [Data provenance](#3-data-provenance)
4. [Curation](#4-curation)
5. [Splitting](#5-splitting-scaffold-not-random)
6. [Modelling and benchmarking](#6-modelling-and-benchmarking)
7. [Validation](#7-validation)
8. [Uncertainty: applicability domain and conformal prediction](#8-uncertainty)
9. [Interpretation](#9-interpretation)
10. [Figures](#10-figures)
11. [Repository layout](#11-repository-layout)
12. [Reproducing this work](#12-reproducing-this-work)
13. [Limitations](#13-limitations--stated-not-buried)
14. [Roadmap](#14-roadmap)
15. [Citations](#15-citations)

---

## 1. Results

> **Provenance.** `ebi.ac.uk` was unreachable from the build environment, so the
> pipeline read the **raw ChEMBL web-interface export** (`DRD2.csv`, 2480 activity
> rows for CHEMBL217) committed to this repository. That file is a genuine raw
> activity table — the same rows the REST API returns, downloaded through the
> browser — so every curation stage applies to it unchanged and these are real
> full-dynamic-range results. Re-pull from the live API at any time with
> `python -m drd2_qsar.run --config configs/drd2.yaml --force-refresh`. Each run
> stamps `data_provenance.source` into `reports/metrics.json`, so a reader can
> always tell which path produced the numbers.

**828 curated compounds · pIC50 4.03 – 9.54 (SD 1.16) · 434 Bemis–Murcko scaffolds**

### Primary model — SVR (RBF) on ECFP4, scaffold-split test set (n = 166)

The primary model is selected by **5-fold scaffold-grouped cross-validation over the
train+validation pool**. The test set is used exactly once.

| Metric | Value (95% bootstrap CI) |
|---|---|
| RMSE | **0.868 [0.751, 0.972]** |
| R² | **0.395 [0.240, 0.523]** |
| MAE | 0.648 [0.564, 0.732] |
| Median AE | 0.471 [0.377, 0.613] |
| Spearman ρ | 0.642 [0.537, 0.738] |
| Pearson r | 0.631 [0.524, 0.728] |
| Kendall τ | 0.466 [0.380, 0.552] |
| Within ±0.5 log | 53.0% [46.4, 60.8] |
| Within ±1.0 log | 78.9% [72.9, 85.5] |

Across **10 repeated scaffold splits**: RMSE 0.880 ± 0.052, R² 0.386 ± 0.043,
Spearman ρ 0.640 ± 0.040 — tight enough that the result is a property of the model,
not of one lucky partition.

### How to read these numbers

Three comparisons make the result interpretable. None is optional.

**Against the mean predictor.** Predicting the training mean gives RMSE
1.124 [1.039, 1.203]. The model's interval [0.751, 0.972] does **not overlap** it.
The model is unambiguously learning something. (This is the comparison that the
earlier, potency-truncated version of this dataset could not pass — with a target SD
of only 0.77 there was almost nothing to predict. At SD 1.16 with genuine inactives
in the set, the question becomes answerable.)

**Against a similarity lookup.** 1-NN Tanimoto gives 1.038 [0.884, 1.180] — worse
than the mean predictor under a scaffold split, which is exactly right: the nearest
training neighbour is by construction in a different chemical series, so copying its
potency actively misleads. Every learned model beats it.

**Against the assay-noise ceiling.** Pooled multi-laboratory ChEMBL IC50 data has a
reproducibility limit of roughly **0.68 log units RMSE** (Kalliokoski et al. 2013).
At 0.868 the model is above that floor, so unlike the truncated version there is
real headroom left — more data and better representations can still help.

**The signal is real.** Y-scrambling over 100 label permutations gives a null R² of
−0.377 ± 0.143 against the real model's 0.395, for an empirical **p = 0.0099**.

### The baseline ladder, under three splits

| Model | Scaffold RMSE | Random RMSE | Temporal RMSE |
|---|---|---|---|
| Random Forest | **0.786 [0.691, 0.875]** | **0.707 [0.606, 0.812]** | 1.120 [1.061, 1.181] |
| XGBoost | 0.854 [0.736, 0.966] | 0.737 [0.623, 0.865] | **1.056 [0.989, 1.124]** |
| SVR (RBF) *(selected)* | 0.868 [0.751, 0.972] | 0.744 [0.647, 0.849] | 1.197 [1.137, 1.257] |
| Ridge | 0.993 [0.863, 1.112] | 0.809 [0.681, 0.944] | 1.205 [1.126, 1.289] |
| 1-NN Tanimoto | 1.038 [0.884, 1.180] | 0.872 [0.721, 1.032] | 1.334 [1.235, 1.423] |
| Mean predictor | 1.124 [1.039, 1.203] | 1.122 [1.034, 1.208] | 1.238 [1.177, 1.297] |

Three things worth reading off this table:

1. **A random split flatters every learned model by 0.08–0.18 log units** and leaves
   the mean predictor untouched — the signature of memorised congeneric series.
2. **The temporal split is brutal**, and it is the most honest column. Training on
   pre-2015 literature and testing on 2015-onward (411 test compounds, 232 scaffolds),
   the best model reaches 1.056 against a mean-predictor floor of 1.238. Chemistry
   published after the training cut-off is substantially harder than chemistry merely
   held out from the same era — which is what a real prospective deployment looks
   like, and why a scaffold-split number should never be quoted as if it were one.
3. **SVR was selected on CV but Random Forest wins on test.** That gap is not hidden
   or corrected after the fact: correcting it would mean selecting on the test set,
   which is the leak the protocol exists to prevent. The grouped-CV fold SDs
   (±0.22 for SVR, ±0.33 for RF) are larger than the gap between them, so the two are
   not distinguishable on this data and the selection is a coin-flip between
   equivalent options.

### Applicability domain

Test error falls as compounds get closer to the training set, with the effect
concentrated in the nearest bin:

| Mean Tanimoto to 5 nearest training compounds | n | Test RMSE (95% CI) |
|---|---|---|
| 0.118 – 0.403 | 33 | 0.909 [0.705, 1.108] |
| 0.403 – 0.556 | 33 | 0.939 [0.627, 1.240] |
| 0.556 – 0.613 | 33 | 0.972 [0.719, 1.204] |
| 0.613 – 0.718 | 33 | 0.827 [0.537, 1.105] |
| 0.718 – 0.874 | 34 | **0.662 [0.497, 0.814]** |

12.0% of the test set falls outside the domain boundary (0.319, the 5th percentile of
training leave-one-out neighbour similarity). The middle three bins overlap heavily —
the honest reading is a threshold effect at high similarity rather than a smooth
gradient, and only the closest bin approaches the assay-noise floor.

### Uncertainty calibration

Split-conformal prediction at a nominal 80% level gives an interval of **±0.967 log
units** with **74.7% empirical coverage**. The shortfall is expected and reported
rather than hidden: the conformal guarantee assumes exchangeability between
calibration and test data, and a scaffold split violates that by design.

### Representation ablation

| Featurizer | Features | Test RMSE (95% CI) | R² |
|---|---|---|---|
| FCFP4 | 2048 | **0.801 [0.695, 0.900]** | 0.484 |
| ECFP6 | 2048 | 0.810 [0.706, 0.908] | 0.473 |
| ECFP4 + RDKit descriptors | 2265 | 0.825 [0.712, 0.928] | 0.453 |
| RDKit descriptors | 217 | 0.845 [0.738, 0.947] | 0.426 |
| ECFP4 | 2048 | 0.854 [0.736, 0.966] | 0.413 |
| MACCS keys | 167 | 0.895 [0.790, 1.003] | 0.356 |

All intervals overlap, so no representation is demonstrably best. The ordering is
nonetheless chemically sensible: **FCFP4 leads**, and its pharmacophoric feature
classes are exactly what should transfer across scaffolds when the evaluation forces
generalisation to unseen series. MACCS trails, which says the 167 hand-designed keys
are genuinely losing information the circular fingerprints retain.

---

## 2. What changed from v0, and why

The first version of this project was a clean, short notebook that fit a
`HistGradientBoostingRegressor` to ECFP fingerprints and plotted the result with
Yellowbrick. It reported train R² = 0.741 and test R² = 0.374. Here is what was wrong
with it, in order of severity.

| # | Defect in v0 | Consequence | Fix |
|---|---|---|---|
| 1 | Five compounds with pIC50 up to **16.4** (sub-femtomolar) | Squared-error loss is dominated by its largest residuals; five points out of 631 were bending the whole fit. Visible as residuals of −4.8 and −6.7 in the v0 residual plot, and as a regression line pulled to a single far outlier in the v0 prediction-error plot. | Plausibility window on pIC50 of [3, 11], with rejected rows printed |
| 2 | Those five are **dopamine, norepinephrine, serotonin** and two catechol aminotetralins — all **agonists** | Modelling agonist potency inside an "inhibitor" model is a category error, not a modelling choice | `action_type` lookup + documented reference list + `action_type_policy` |
| 3 | `train_test_split(df)` with no arguments | No `random_state` (irreproducible); silently 25% not the 80/20 the README claimed; and **random**, so congeneric analogues straddled the split | Seeded three-way Bemis–Murcko scaffold split, with the random split published alongside |
| 4 | 50/631 SMILES carried `Br.`/`Cl.` salt components | The hydrobromide and the free base become different feature vectors with the same label — pure injected noise | RDKit largest-fragment + uncharge + canonical tautomer standardization |
| 5 | Deduplication by ChEMBL ID | Salt forms and stereo-unspecified entries of one parent survive as independent rows | Deduplication on the InChIKey connectivity layer |
| 6 | One number from one split, no intervals | A ±0.15-wide R² interval was reported as a point estimate | 1000-resample bootstrap CIs on every metric; 10 repeated splits |
| 7 | No baseline | Nothing to compare against, so "R² = 0.374" was uninterpretable | Six-rung ladder from mean predictor to XGBoost |
| 8 | No null model | No evidence the model was fitting signal rather than the split | Y-scrambling with an empirical p-value |
| 9 | No applicability domain | No way to know when a prediction is trustworthy | Tanimoto AD with the error-vs-distance curve |
| 10 | README described a pipeline the notebook did not contain | Claimed ChEMBL mining, unit validation, duplicate consensus averaging, stratified partitioning and MSE/RMSE reporting — none of which were in the code | This README describes only what runs |

The last one matters most for a reader's trust, and it is why this document is
deliberately explicit about what the current numbers are and are not.

---

## 3. Data provenance

The v0 pipeline began by `wget`-ing a pre-made `DRD2.csv` from GitHub. That is the
single biggest reproducibility hole a cheminformatics repository can have: nobody —
including the author six months later — can say what query produced those rows, which
ChEMBL release they came from, or what was filtered out before they were written.

Here the dataset is **derived**, and the derivation is code (`src/drd2_qsar/chembl.py`).
The query is explicit about four things that silently corrupt public-data QSAR models
when left implicit:

```yaml
chembl:
  target_chembl_id: CHEMBL217        # human Dopamine Receptor D2
  standard_types: [IC50]
  assay_type: B                      # binding assays only
  standard_relation: "="             # drop censored (>, <) measurements
  standard_units: nM                 # checked, not assumed
  target_organism: Homo sapiens
```

- **`standard_relation == '='`.** A censored result (`IC50 > 10000`) is real information
  but it is not a regression target. Treating `>` as `=` teaches the model that a
  compound which failed to show activity has exactly the potency of the detection limit.
- **`assay_type == 'B'`.** Binding assays only, so functional and ADMET readouts are not
  pooled into one "potency" column.
- **`standard_units == 'nM'`**, checked rather than assumed.
- **ChEMBL's own `data_validity_comment` flags** are honoured. These are the curator
  warnings that catch transcription and unit errors, and they cost nothing to use.

Every pull writes `data/raw/CHEMBL217_pull_manifest.json` recording the ChEMBL release,
the pull timestamp, the full query and the row count. The raw pull is cached, so
re-running does not silently pick up a different dataset after ChEMBL ships a new
release — and does not hammer the EBI's servers.

If ChEMBL is unreachable the pipeline resolves, in order: a cached parquet from a
previous live pull → a **ChEMBL web-interface export** found in `data/raw/` → the
legacy pre-curated snapshot. The web export (`DRD2.csv`, shipped with this repository)
is recognised by its header rather than its filename, and is a first-class source: it
is the same raw activity table the REST API returns, so every curation stage applies
to it unchanged. Two format quirks are normalised on read — the export is
semicolon-separated, and its `Standard Relation` values arrive wrapped in literal
single quotes (`'='`), which would otherwise match nothing and silently discard the
entire dataset. Whichever path is taken is recorded in
`data_provenance.source`; the pipeline never presents a fallback as a live query.

---

## 4. Curation

Curation is where the answer actually changes, and it is the stage most QSAR notebooks
skip. Every stage logs its row counts to `reports/curation_audit.csv`, and every removed
record is written to `reports/rejected_records.csv` **with its reason** — nothing
disappears unexplained.

![Curation audit](reports/figures/fig00_curation_waterfall.png)

| Stage | Rows before → after | Removed | Reason |
|---|---|---|---|
| Raw export | 2480 → 2480 | 0 | IC50 activity rows for CHEMBL217 |
| **Missing fields** | **2480 → 1575** | **905** | null SMILES or activity value |
| **Censored measurements** | **1575 → 1103** | **472** | kept only exact `=` — `>` rows are not regression targets |
| Units | 1103 → 1103 | 0 | kept only nM |
| **ChEMBL validity flags** | **1103 → 1094** | **9** | curator-flagged (`Outside typical range`) |
| Numeric activity | 1094 → 1094 | 0 | value must be positive and numeric |
| Plausibility window | 1094 → 1094 | 0 | pIC50 in [3, 11] — the implausible rows were already removed above |
| Standardization | 1094 → 1094 | 0 | 65 multi-component inputs desalted |
| **Element/size sanity** | **1094 → 1088** | **6** | heavy-atom count outside [8, 70] |
| Mechanism policy | 1088 → 1088 | 0 | `keep_all` |
| Activity cutoff | 1088 → 1088 | 0 | **not applied** — full dynamic range retained |
| InChIKey generation | 1088 → 1088 | 0 | connectivity-layer key |
| **Replicate aggregation** | **1088 → 828** | **260** | median over 144 multi-measurement parents; 31 dropped for spread > 1 log |
| **Final** | **828** | | modelling-ready unique parent structures |

The two largest removals both deserve comment. **905 rows carry no SMILES or no
activity value** — an artefact of the web export, which emits a row per assay record
including ones whose structure or value is withheld. **472 rows are censored** (`>`),
overwhelmingly weak or inactive compounds reported as "greater than" the highest
concentration tested. Dropping them is correct for a regression target and it is also
a real loss: those compounds carry genuine information about inactivity that a
classification or censored-regression model could use. That is noted in the roadmap
rather than quietly discarded.

### The impossible potencies

The legacy pre-curated CSV that this project started from contained five compounds
with recorded pIC50 values up to **16.4** — a sub-femtomolar affinity no small
molecule achieves at a GPCR:

| ChEMBL ID | Recorded pIC50 | Implied IC50 | What it actually is |
|---|---|---|---|
| CHEMBL26736 | 16.40 | 40 aM | 2-aminotetralin catechol — **agonist** |
| CHEMBL225230 | 15.30 | 0.5 fM | aporphine — **agonist** |
| CHEMBL59 | 14.10 | 8 fM | **dopamine** — the endogenous agonist |
| CHEMBL1437 | 13.10 | 80 fM | **norepinephrine** |
| CHEMBL39 | 12.52 | 0.3 pM | **serotonin** |

These are unit-handling errors — µM or mM values recorded as nM — and they are all
agonists, so they violated the project's stated scope twice over. Squared-error
regression is dominated by its largest residuals, so five points out of 631 were
bending the entire fit; they are visible as residuals of −4.8 and −6.7 in the original
notebook's residual plot.

In the current raw export they never reach the plausibility window, because ChEMBL's
own validity flags and the censored/missing-value filters remove them first. The
window still runs, and still rejects with a printed reason. **A guard that catches
nothing on today's data is not redundant** — it is what stops the next export, or the
next target, from reintroducing the same class of error unnoticed.

Other curation decisions worth stating:

- **Deduplication on the InChIKey connectivity layer**, not on the ChEMBL accession, so
  salt forms and stereo-unspecified entries of one parent collapse together.
- **Replicates aggregated by median**, and compounds whose replicate measurements span
  more than **1 log unit** are *dropped*, not averaged. When two papers disagree by two
  orders of magnitude the truth is not knowable from this data, and averaging produces a
  confident-looking wrong number.
- **The `IC50 < 1000 nM` activity cutoff is disabled by default.** See
  [Limitations](#13-limitations--stated-not-buried) for why this matters more than
  anything else in the config.

---

## 5. Splitting: scaffold, not random

ChEMBL target sets are dominated by congeneric series — dozens of close analogues
published together in one paper. A random split scatters those analogues across the
train/test boundary, so the test set mostly measures how well the model interpolates
within series it has already memorised.

A **Bemis–Murcko scaffold split** forces whole chemical series into one partition. The
score it produces is lower, and it is the one that predicts what happens when the model
meets next quarter's chemistry.

| Partition | n | Fraction | pIC50 mean ± SD | Scaffolds |
|---|---|---|---|---|
| train | 579 | 69.9% | 6.80 ± 1.16 | 213 |
| validation | 83 | 10.0% | 6.43 ± 1.19 | 83 |
| test | 166 | 20.0% | 6.61 ± 1.12 | 138 |

A **temporal split** is also computed and reported, because 93.8% of the curated
compounds now carry a publication year. Training on pre-2015 literature (320
compounds) and testing on 2015-onward (411 compounds, 232 scaffolds) is the closest
available approximation to a prospective test, and its results are in §1.

Two guarantees are **asserted in code** (they raise, they do not warn) and covered by
tests that plant a deliberate leak to prove the detector fires:

- no Bemis–Murcko framework appears in two partitions;
- no identical structure (by InChIKey connectivity) appears in two partitions.

The split is seeded and reproducible. It is also genuinely *seed-dependent* — an earlier
version ordered scaffold groups deterministically by size, which meant the seed did
nothing and the multi-seed stability analysis reported a variance of exactly zero. A
split that cannot vary cannot measure split variance; the seeded tie-break fixes it.

Random, Butina-cluster and temporal splits are also implemented
(`src/drd2_qsar/splits.py`). The random split is computed on every run for the
side-by-side comparison in §1.

---

## 6. Modelling and benchmarking

**The ladder.** A QSAR result is only interpretable relative to what a trivial method
achieves on the same split:

1. `dummy_mean` — predicts the training mean. Anything below this is broken.
2. `knn_tanimoto` — 1-NN by Tanimoto similarity. "Copy the most similar molecule you
   have already measured." On congeneric sets this is genuinely hard to beat, and a
   model that fails to beat it has learned nothing a lookup table lacks. It is also the
   baseline almost always omitted, which is why so many published QSAR models are
   functionally slow lookup tables.
3. `ridge` — tests whether the SAR is essentially additive.
4. `random_forest`, `svr` (RBF), `xgboost` — the non-linear workhorses.

**Model selection uses scaffold-grouped 5-fold CV over the train+validation pool.**
Selecting by test score is a subtler form of leakage — the test set stops being held out
the moment it decides anything. Selecting on a single 60-compound validation slice turns
out to be too noisy to be safe: in development it picked XGBoost, which then scored
*worse than the mean predictor* on test. Grouped CV picks Random Forest, consistent with
the full ladder.

| Model | Grouped-CV RMSE (mean ± SD across folds) |
|---|---|
| **SVR (RBF)** | **0.985 ± 0.218** |
| Random Forest | 0.993 ± 0.330 |
| XGBoost | 1.095 ± 0.409 |
| Ridge | 1.172 ± 0.361 |
| 1-NN Tanimoto | 1.232 ± 0.385 |

Those fold standard deviations (0.22–0.41 log units) dwarf the 0.008 gap between SVR
and Random Forest. That is the honest reading: **the top two are not distinguishable
on this data**, the selection between them is effectively a coin flip, and Random
Forest going on to score better on the held-out test set (0.786 vs 0.868) is within
exactly that noise. Reaching back to swap the selection would be selecting on the test
set — the leak this protocol exists to prevent — so it stands as it is.

---

## 7. Validation

Four checks, each closing a different way of fooling yourself.

**Nested cross-validation** (scaffold-grouped outer folds, randomized search inner).
Tuning inside the folds you score on leaks the answer into the tuning. Result:
RMSE 0.955 ± 0.237, R² 0.272 ± 0.378, Spearman ρ 0.576 ± 0.221. The wide R² spread
across outer folds is itself the finding — some scaffold groups are simply far less
predictable from the others, which is the same message the temporal split delivers
more bluntly.

**Y-scrambling** (OECD QSAR validation principle 4), 100 permutations. Shuffle the
training labels and refit; a model learning real SAR collapses to R² ≈ 0.

| | R² |
|---|---|
| Real model | 0.395 |
| Permuted labels | −0.377 ± 0.143 |
| **Empirical p-value** | **0.0099** |

**Repeated splits**, 10 seeds: RMSE 0.880 ± 0.052, R² 0.386 ± 0.043. A single split's
score is a random variable, and its spread is frequently larger than the gap between two
models being compared — as it is here between SVR and Random Forest.

**Learning curve** with ±1 SD bands across repeats — does more data help, or has this
endpoint saturated? See `reports/figures/fig08_learning_curve.png`.

---

## 8. Uncertainty

Two questions a project team will actually ask, neither of which an R² answers.

**"Can I use this model on my compound?"** The applicability domain is the mean Tanimoto
similarity to the *k* = 5 nearest training compounds, with the boundary at the 5th
percentile of the training set's own leave-one-out neighbour similarity. The useful
output is not the in/out flag — it is the **error-versus-distance curve** in §1, which
quantifies how fast predictions degrade outside the training neighbourhood.

**"How wrong is this specific prediction likely to be?"** Split-conformal prediction
converts held-out calibration residuals into an interval with a distribution-free
coverage guarantee, using the finite-sample-corrected quantile
`ceil((n+1)(1−α))/n`. The caveat is stated up front rather than buried: that guarantee
assumes exchangeability, a scaffold split deliberately breaks it, and the observed
74.7% against a nominal 80% is the size of that violation.

---

## 9. Interpretation

**SHAP mapped back to chemistry.** A bit index is meaningless on its own, so
`interpret.top_bit_substructures` traces each influential bit to a molecule that sets
it and the atom environment responsible — "bit 1174" becomes a highlighted
substructure drawn on a real compound.

The selected model here is an SVR, which TreeSHAP cannot explain, and KernelSHAP on
2048 features is hours of compute for an approximation. So the pipeline fits a
gradient-boosted **surrogate** on the SVR's own predictions, explains that exactly,
and **reports the surrogate's fidelity**: R² = 0.729 against the SVR's test
predictions. That is honest but not high — the attribution should be read as
indicative of which substructures matter in this feature space, not as a faithful
account of what this particular SVR does. When a tree model is selected, exact
TreeSHAP runs instead and no surrogate is involved.

**Activity cliffs.** 45 pairs exceed Tanimoto ≥ 0.70 with |ΔpIC50| ≥ 2.0. They are
where every similarity-based model fails, and the test-set errors confirm it
decisively:

| | n | Mean abs. residual | Median | Max |
|---|---|---|---|---|
| Not on a cliff | 154 | 0.568 | 0.447 | 1.944 |
| **On an activity cliff** | **12** | **1.681** | 1.441 | 2.985 |

Twelve test compounds sit on a cliff and their mean error is **three times** that of
the rest — and the single worst prediction in the whole test set (2.985 log units) is
one of them. The full pair list is in `reports/activity_cliffs.csv`. The SALI landscape
(`fig18_cliff_landscape.png`) shows the whole structure–activity surface with the cliff
region marked.

---

## 10. Figures

All figures are generated by `src/drd2_qsar/plots.py` in one style system, exported at
300 dpi to both PNG and SVG. The palette is validated for colour-vision deficiency
(worst all-pairs CVD ΔE 9.2, normal-vision ΔE 24.0), colour is assigned by the job it
does — categorical for identity, single-hue sequential for magnitude, diverging for
signed residuals — and identity is never carried by colour alone.

| Figure | What it shows |
|---|---|
| `fig00_curation_waterfall` | Records removed at each curation stage |
| `fig01_data_overview` | Potency distribution + 7-property panel + Ro5 compliance |
| `fig02_property_vs_potency` | Is potency just a bulk-property effect? |
| `fig03_chemical_space` | UMAP + PCA of ECFP4, by potency and by partition |
| `fig04_scaffold_analysis` | Scaffold frequency and within-series potency spread |
| `fig05_scaffold_structures` | The top 12 scaffolds drawn as structures |
| `fig06_pred_vs_obs` | **Headline:** equal axes, ±1 log band, coloured by AD distance |
| `fig07_residual_diagnostics` | Residual vs fitted, Q–Q, error by potency decile, histogram |
| `fig08_learning_curve` | Performance vs training-set size, ±1 SD |
| `fig09_model_forest_rmse` / `_r2` | The whole benchmark as intervals |
| `fig10_split_comparison` | **Scaffold vs random split, per model** |
| `fig11_y_scrambling` | Null distribution with the real model marked |
| `fig12_applicability_domain` | Domain coverage + error-vs-distance |
| `fig13_conformal_calibration` | Nominal vs empirical coverage, interval width |
| `fig14`–`fig16` | SHAP beeswarm, ranked importance, bit substructures |
| `fig17_activity_cliffs` | The matched pairs that break the model |
| `fig18_cliff_landscape` | SALI-style structure–activity landscape |
| `fig19_feature_ablation` | Representation comparison with intervals |
| `fig20_seed_stability` | Metric spread across 10 repeated splits |

### The headline figure

![Predicted vs observed](reports/figures/fig06_pred_vs_obs.png)

Equal axes on a shared range so the identity line is at 45°, an explicit ±1 log-unit
band stating what "good enough" means in medicinal-chemistry terms, points coloured by
applicability-domain distance, and metrics quoted with intervals. Compare with the v0
Yellowbrick plot, whose auto-scaled axes were stretched to pIC50 = 16 by a single
corrupt point.

### The honesty figure

![Scaffold vs random split](reports/figures/fig10_split_comparison.png)

### The one that makes the model usable

![Applicability domain](reports/figures/fig12_applicability_domain.png)

---

## 11. Repository layout

```
drd2-qsar/
├── README.md                     this document
├── MODEL_CARD.md                 intended use, limitations, risks, citations
├── pyproject.toml                packaging, lint/format/test config
├── requirements.txt              pinned versions used for the reported numbers
├── environment.yml               conda environment
├── configs/
│   └── drd2.yaml                 every tunable; no magic numbers in the code
├── src/drd2_qsar/
│   ├── config.py                 typed config, global seed, provenance manifest
│   ├── chembl.py                 live ChEMBL ingestion + pull manifest + cache
│   ├── curate.py                 standardization, sanity filters, audit trail
│   ├── features.py               featurizer zoo (ECFP/FCFP/MACCS/descriptors)
│   ├── splits.py                 scaffold / random / Butina / temporal + leak guards
│   ├── models.py                 the baseline ladder incl. Tanimoto k-NN
│   ├── evaluate.py               bootstrap CIs, nested CV, y-scrambling, AD, conformal
│   ├── interpret.py              SHAP + bit→substructure mapping, activity cliffs
│   ├── plots.py                  the whole figure suite, one style system
│   ├── run.py                    CLI: the 10-stage pipeline
│   └── predict.py                CLI: inference with AD flags and intervals
├── tests/                        65 tests incl. planted-leak detection
├── notebooks/
│   └── DRD2_QSAR_Modeling.ipynb  the narrative layer over the package
├── data/{raw,interim,processed}/ raw pull + manifest, curated dataset
├── reports/                      metrics.json, audit CSVs, figures/
├── models/                       serialized model + featurizer + AD
└── .github/workflows/ci.yml      lint, format, tests, smoke run, inference check
```

The notebook explains; it does not reimplement. Every computation it shows runs inside
the package, so the same code path produces the notebook figures, the README numbers and
the CLI predictions.

---

## 12. Reproducing this work

```bash
git clone https://github.com/Babakmamnoon/QSAR-Modelling-of-Human-Dopamine-Receptor-D2-DRD2-Ligand-Potency
cd QSAR-Modelling-of-Human-Dopamine-Receptor-D2-DRD2-Ligand-Potency

conda env create -f environment.yml && conda activate drd2-qsar
# or: pip install -e ".[dev,conformal]"

python -m drd2_qsar.run --config configs/drd2.yaml      # full pipeline (~14 min)
python -m drd2_qsar.run --config configs/drd2.yaml --quick   # smoke run (~3 min)
pytest tests -q                                          # 65 tests
```

Useful flags: `--force-refresh` (re-query ChEMBL), `--no-figures`, `-v`.

**Predicting on new compounds:**

```bash
python -m drd2_qsar.predict \
    --model models/drd2_qsar_model.joblib \
    --input my_compounds.smi \
    --output predictions.csv
```

Every prediction returns the predicted pIC50 **plus** an applicability-domain flag, a
conformal interval, and the nearest training neighbour with its measured potency — so a
chemist can see immediately what the prediction is based on. Input structures are passed
through the same standardization used in training, so a salt form in the query file does
not silently become a different molecule from the one the model saw.

**Reproducibility.** One global seed, set once and logged. Every run writes
`reports/metrics.json` containing the config hash, the full environment manifest
(package versions, git revision), the data provenance manifest and every metric with its
interval. Two runs of the same config against the same cached pull produce identical
numbers.

---

## 13. Limitations — stated, not buried

1. **The temporal result is the one that matters, and it is poor.** Trained on
   pre-2015 literature, the best model reaches RMSE 1.056 against a mean-predictor
   floor of 1.238 — a real but thin margin. Anyone quoting the scaffold-split 0.868 as
   though it described prospective performance would be overstating this model by
   roughly 0.2 log units.
2. **472 censored measurements were discarded.** Rows reported as `IC50 > x` are not
   regression targets, so dropping them is correct — but they are overwhelmingly the
   weak and inactive compounds, and discarding them removes genuine information about
   inactivity. A classification arm or a censored-regression (Tobit) model would use
   them. This is the single largest piece of usable signal currently left on the table.
3. **905 export rows carried no SMILES or no activity value** and were dropped. That is
   an artefact of the ChEMBL web export rather than of the underlying data; a REST pull
   with explicit field selection recovers some of them.
4. **Mechanistic heterogeneity.** Only ~120 of 2480 rows carry an `Action Type`
   (79 antagonist, 25 partial agonist, 12 inhibitor, 4 agonist). The unlabelled
   majority may still mix agonists and antagonists in one potency model.
   `action_type_policy` mitigates this; it does not solve it.
5. **Congeneric coverage.** 828 compounds over 434 scaffolds is thin — many scaffolds
   are singletons. The scaffold split makes the *evaluation* honest; it does not make
   the *coverage* better.
6. **Assay heterogeneity.** Pooled multi-laboratory IC50 data carries a reproducibility
   floor of ~0.68 log units RMSE. At 0.868 the model is above it, so headroom exists —
   but no model will go far below it.
7. **Exchangeability.** The conformal coverage guarantee is marginal and assumes
   exchangeability, which the scaffold split violates by design (74.7% vs 80% nominal).
8. **The applicability domain is a threshold, not a gradient.** Only the closest
   similarity bin (Tanimoto ≥ 0.718) shows clearly lower error; the middle three bins
   overlap. Treat the domain flag as a coarse filter, not a calibrated error predictor.
9. **SHAP attribution is via a surrogate** with fidelity R² = 0.729 against the selected
   SVR, because TreeSHAP cannot explain an SVR. Read it as indicative of the feature
   space, not as a faithful account of this model.
10. **2D only.** No conformational, protein-structural or free-energy information,
    despite DRD2 having good experimental structures (e.g. PDB 6CM4).
11. **Activity cliffs** are enumerated but not solved. The 12 cliff compounds in the
    test set carry three times the mean error of the rest.
12. **Statistical power.** A 166-compound test set gives R² intervals ~0.28 wide. Most
    model-to-model differences reported here are not statistically distinguishable, and
    the README says so rather than ranking them anyway.

**Safety note.** DRD2 is the principal target of antipsychotic drugs; DRD2 antagonism
carries real clinical liabilities (extrapyramidal symptoms, tardive dyskinesia,
hyperprolactinaemia) and DRD2 agonism carries its own. This model predicts one *in
vitro* binding number and is a research tool only. See [`MODEL_CARD.md`](MODEL_CARD.md).

---

## 14. Roadmap

Ordered by expected value, not by novelty.

1. **Use the censored data.** 472 discarded `>` measurements are the largest available
   gain: either a binary active/inactive classifier trained on everything, or a
   censored-regression model that treats `IC50 > x` as a lower bound rather than as
   missing. This is what would turn a series-ranking model into a screening model.
2. **Live REST pull with explicit fields**, recovering a portion of the 905 rows the
   web export left without SMILES or values, and attaching the ChEMBL release version
   to the provenance manifest.
3. **Close the temporal gap.** The pre/post-2015 result is the honest measure of
   deployment performance and it is the weakest number in the report. Time-aware
   validation, recency weighting and periodic retraining all target it directly.
4. **Multi-task learning across DRD1–DRD5**, with DRD2/DRD3 selectivity as a second
   endpoint. Selectivity is the real medicinal-chemistry problem here, and the
   aminergic GPCR family shares enough chemistry for transfer to plausibly help.
5. **Graph neural network (Chemprop D-MPNN)** as a learned-representation arm of the
   ablation, on the same splits with the same intervals. FCFP4 currently leads the
   ablation, which suggests representations that abstract atom identity transfer best
   across scaffolds — a learned one may do better still.
6. **Docking cross-check against DRD2 (6CM4)** for the highest-error compounds and the
   12 activity-cliff pairs, tying the ligand-based model to structure.
7. **Uncertainty-guided active learning** — use the conformal intervals to choose which
   compounds to measure next. This is where the model earns its keep in a real project.

---

## 15. Citations

- Zdrazil, B. *et al.* **ChEMBL: a highly effective platform for drug discovery.**
  *Nucleic Acids Res.* (2024) 52:D1180–D1192.
- Landrum, G. **RDKit: Open-source cheminformatics.** https://www.rdkit.org
- Rogers, D. & Hahn, M. **Extended-Connectivity Fingerprints.** *J. Chem. Inf. Model.*
  (2010) 50:742–754.
- Bemis, G. & Murcko, M. **The Properties of Known Drugs. 1. Molecular Frameworks.**
  *J. Med. Chem.* (1996) 39:2887–2893.
- Pedregosa, F. *et al.* **Scikit-learn: Machine Learning in Python.** *JMLR* (2011)
  12:2825–2830.
- Chen, T. & Guestrin, C. **XGBoost: A Scalable Tree Boosting System.** *KDD* (2016)
  785–794.
- Lundberg, S. & Lee, S.-I. **A Unified Approach to Interpreting Model Predictions.**
  *NeurIPS* (2017) 4765–4774.
- Kalliokoski, T. *et al.* **Comparability of Mixed IC50 Data — A Statistical Analysis.**
  *PLoS ONE* (2013) 8:e61007.
- Sheridan, R. P. **Time-Split Cross-Validation as a Method for Estimating the Goodness
  of Prospective Prediction.** *J. Chem. Inf. Model.* (2013) 53:783–790.
- Vovk, V., Gammerman, A. & Shafer, G. **Algorithmic Learning in a Random World.**
  Springer (2005). *(conformal prediction)*
- Guha, R. & Van Drie, J. H. **Structure–Activity Landscape Index.** *J. Chem. Inf.
  Model.* (2008) 48:646–658. *(SALI)*
- OECD. **Guidance Document on the Validation of (Q)SAR Models.** ENV/JM/MONO(2007)2.
- Mitchell, M. *et al.* **Model Cards for Model Reporting.** *FAT\** (2019) 220–229.

---

## Licence

MIT — see [`LICENSE`](LICENSE).
