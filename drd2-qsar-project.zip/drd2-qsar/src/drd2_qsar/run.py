"""CLI entry point — the whole pipeline, one command.

    python -m drd2_qsar.run --config configs/drd2.yaml

Stages
------
0  ingest      live ChEMBL pull (or cached), with a provenance manifest
1  curate      standardization, sanity filters, replicate aggregation, audit trail
2  characterise  property panel, chemical space, scaffold analysis
3  split       scaffold train/val/test (+ the random split for comparison)
4  benchmark   the baseline ladder, each with bootstrap CIs
5  ablate      molecular-representation comparison
6  validate    nested CV, y-scrambling, multi-seed repeats, learning curve
7  uncertainty applicability domain + conformal prediction intervals
8  interpret   SHAP attribution and activity cliffs
9  persist     model, metrics JSON, figures, model card inputs

Every stage writes its own artifact, so a failure in stage 8 does not cost you
stages 0–7, and any number in the README can be traced to a file on disk.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time

import joblib
import numpy as np
import pandas as pd

from . import chembl, curate, evaluate, features, interpret, models, plots, splits
from .config import Config, environment_manifest, load_config, set_global_seed, setup_logging

LOGGER = logging.getLogger("drd2_qsar.run")
logging.getLogger("shap").setLevel(logging.WARNING)


# --------------------------------------------------------------------------- #
def _json_safe(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj) if np.isfinite(obj) else None
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (pd.DataFrame,)):
        return obj.to_dict(orient="records")
    if isinstance(obj, (pd.Series,)):
        return obj.to_dict()
    return str(obj)


def run_pipeline(cfg: Config, stages: set[str] | None = None, force_refresh: bool = False) -> dict:
    t0 = time.time()
    cfg.ensure_dirs()
    set_global_seed(cfg.seed)
    seed = cfg.seed
    fig_dir = cfg.figure_dir
    fmts = tuple(cfg.get("plots.formats", ["png", "svg"]))
    plots.set_style(dpi=int(cfg.get("plots.dpi", 300)))

    results: dict = {
        "config_fingerprint": cfg.fingerprint(),
        "environment": environment_manifest(),
        "config": cfg.to_dict(),
    }

    def run(stage_name: str) -> bool:
        """Whether an optional stage (currently just figures) should execute."""
        return stages is None or stage_name in stages

    # ---------------------------------------------------------------- 0. ingest
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 0 — ChEMBL ingestion")
    raw, manifest = chembl.load_or_fetch(
        cfg["chembl"], cfg.data_dir / "raw", force_refresh=force_refresh
    )
    results["data_provenance"] = manifest.__dict__.copy()
    if manifest.source == "legacy_snapshot":
        LOGGER.warning(
            "DATA PROVENANCE WARNING: running on the legacy pre-curated snapshot. "
            "Metrics from this run are NOT the published numbers."
        )

    action_types = None
    if cfg.get("chembl.fetch_action_type", True) and manifest.source == "live":
        try:
            action_types = chembl.fetch_action_types(
                raw["molecule_chembl_id"].dropna().unique().tolist()
            )
        except chembl.ChEMBLUnavailable as exc:
            LOGGER.warning("action_type lookup skipped: %s", exc)

    # ---------------------------------------------------------------- 1. curate
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 1 — curation")
    clean, audit, rejected = curate.curate(raw, cfg["curation"], action_types)
    clean.to_csv(cfg.data_dir / "processed" / "drd2_curated.csv", index=False)
    rejected.to_csv(cfg.output_dir / "rejected_records.csv", index=False)
    audit.write(cfg.output_dir / "curation_audit.csv")
    results["curation_audit"] = audit.to_frame().to_dict(orient="records")
    results["n_compounds"] = int(len(clean))
    plots.plot_curation_waterfall(audit.to_frame(), fig_dir, fmts)

    if len(clean) < 100:
        raise RuntimeError(f"Only {len(clean)} compounds survived curation — check the config")

    # ------------------------------------------------------- 2. characterise
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 2 — dataset characterisation")
    props = curate.compute_properties(clean["smiles"])
    props.to_csv(cfg.data_dir / "processed" / "properties.csv", index=False)
    results["property_summary"] = props.describe().to_dict()
    if run("figures"):
        plots.plot_data_overview(clean, props, fig_dir, fmts)
        plots.plot_property_vs_potency(clean, props, fig_dir, fmts)

    # ---------------------------------------------------------------- 3. split
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 3 — partitioning")
    clean = splits.add_scaffolds(clean, cfg.get("split.scaffold.include_chirality", False))
    split_idx = splits.make_split(clean, cfg["split"], seed=seed)
    splits.assert_no_structure_leak(clean, split_idx)
    summary = splits.split_summary(clean, split_idx)
    summary.to_csv(cfg.output_dir / "split_summary.csv", index=False)
    results["split_summary"] = summary.to_dict(orient="records")
    results["split_strategy"] = cfg.get("split.strategy")
    LOGGER.info("\n%s", summary.to_string(index=False))

    random_idx = splits.random_split(
        clean, cfg.get("split.test_size", 0.2), cfg.get("split.val_size", 0.1), seed
    )

    if run("figures"):
        plots.plot_scaffold_analysis(clean, fig_dir, 20, fmts)
        plots.plot_scaffold_grid(clean, fig_dir, 12)

    # ------------------------------------------------------------- featurize
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 4 — featurization and benchmark")
    n_bits = int(cfg.get("features.n_bits", 2048))
    primary_name = cfg.get("features.primary", "ecfp4")
    featurizer = features.get_featurizer(primary_name, n_bits, cfg.get("features.counts", False))
    X = features.featurize_frame(clean, featurizer)
    y = clean["pIC50"].to_numpy(dtype=float)

    tr, va, te = split_idx["train"], split_idx["val"], split_idx["test"]
    # train+val is the fitting set for the final model; val is used for tuning
    fit_idx = np.concatenate([tr, va])

    boot_cfg = cfg.get("evaluation.bootstrap", {})
    n_boot = int(boot_cfg.get("n_resamples", 1000))
    ci = float(boot_cfg.get("ci", 0.95))
    noise_floor = float(cfg.get("evaluation.assay_noise.rmse_floor", 0.68))

    # --------------------------------------------------- 4. the baseline ladder
    zoo = list(cfg.get("models.zoo", ["dummy_mean", "knn_tanimoto", "ridge", "xgboost"]))
    n_jobs = int(cfg.get("models.n_jobs", -1))

    def bench(idx_map, label: str) -> tuple[dict, dict]:
        boots, preds = {}, {}
        a, b = idx_map["train"], idx_map["test"]
        a = np.concatenate([a, idx_map["val"]])
        for name in zoo:
            est = models.get_model(name, seed=seed, n_jobs=n_jobs)
            est.fit(X[a], y[a])
            p = est.predict(X[b])
            boots[name] = evaluate.bootstrap_metrics(y[b], p, n_boot, ci, seed)
            preds[name] = p
            pt = boots[name].set_index("metric")["value"]
            LOGGER.info(
                "  [%s|%s] RMSE=%.3f  R2=%.3f  rho=%.3f",
                label,
                name,
                pt["RMSE"],
                pt["R2"],
                pt["Spearman_rho"],
            )
        return boots, preds

    LOGGER.info("-- scaffold split --")
    boots_scaf, preds_scaf = bench(split_idx, "scaffold")
    comp_scaf = evaluate.compare_models(boots_scaf, "RMSE")
    comp_scaf_r2 = evaluate.compare_models(boots_scaf, "R2")

    LOGGER.info("-- random split (optimistic comparison) --")
    boots_rand, _ = bench(random_idx, "random")
    comp_rand = evaluate.compare_models(boots_rand, "RMSE")

    results["benchmark_scaffold"] = {k: v.to_dict(orient="records") for k, v in boots_scaf.items()}
    results["benchmark_random"] = {k: v.to_dict(orient="records") for k, v in boots_rand.items()}
    comp_scaf.to_csv(cfg.output_dir / "model_comparison_scaffold.csv", index=False)
    comp_rand.to_csv(cfg.output_dir / "model_comparison_random.csv", index=False)

    # -- temporal split: train on older literature, test on newer --------------
    # The closest available approximation to a prospective test, and the one a
    # hiring manager will ask about. It needs publication years, which only a
    # real ChEMBL pull carries, so it runs opportunistically rather than being
    # assumed — and says plainly why it was skipped when it cannot run.
    try:
        temporal_idx = splits.temporal_split(
            clean,
            cfg.get("split.temporal.year_column", "year"),
            int(cfg.get("split.temporal.train_before", 2015)),
            seed=seed,
        )
        if min(len(v) for v in temporal_idx.values()) < 25:
            raise ValueError("a temporal partition is too small to score")
        LOGGER.info("-- temporal split (pre/post %s) --", cfg.get("split.temporal.train_before"))
        boots_temp, _ = bench(temporal_idx, "temporal")
        comp_temp = evaluate.compare_models(boots_temp, "RMSE")
        comp_temp.to_csv(cfg.output_dir / "model_comparison_temporal.csv", index=False)
        results["benchmark_temporal"] = {
            k: v.to_dict(orient="records") for k, v in boots_temp.items()
        }
        results["temporal_split_summary"] = splits.split_summary(clean, temporal_idx).to_dict(
            orient="records"
        )
    except (ValueError, KeyError) as exc:
        LOGGER.warning("Temporal split not available: %s", exc)
        results["temporal_split_skipped"] = str(exc)

    if run("figures"):
        plots.plot_model_forest(
            comp_scaf,
            fig_dir,
            "RMSE",
            "knn_tanimoto",
            noise_floor,
            models.MODEL_DISPLAY_NAMES,
            fmts,
        )
        plots.plot_model_forest(
            comp_scaf_r2, fig_dir, "R2", "knn_tanimoto", None, models.MODEL_DISPLAY_NAMES, fmts
        )
        plots.plot_split_comparison(
            comp_scaf, comp_rand, fig_dir, "RMSE", models.MODEL_DISPLAY_NAMES, fmts
        )

    # -------------------------------------------------- 5. representation ablation
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 5 — molecular representation ablation")
    primary_model = cfg.get("models.primary", "xgboost")
    ablation_model = "xgboost" if str(primary_model).lower() == "auto" else primary_model
    abl_rows = []
    for fname in cfg.get("features.ablation", [primary_name]):
        f = features.get_featurizer(fname, n_bits, cfg.get("features.counts", False))
        Xa = f.transform(clean["smiles"].tolist())
        est = models.get_model(ablation_model, seed=seed, n_jobs=n_jobs)
        est.fit(Xa[fit_idx], y[fit_idx])
        b = evaluate.bootstrap_metrics(y[te], est.predict(Xa[te]), n_boot, ci, seed)
        r = b.loc[b["metric"] == "RMSE"].iloc[0]
        r2 = b.loc[b["metric"] == "R2"].iloc[0]
        abl_rows.append(
            {
                "featurizer": fname,
                "n_features": Xa.shape[1],
                "value": r["value"],
                "ci_low": r["ci_low"],
                "ci_high": r["ci_high"],
                "R2": r2["value"],
                "R2_ci_low": r2["ci_low"],
                "R2_ci_high": r2["ci_high"],
            }
        )
        LOGGER.info(
            "  [%s] %d features  RMSE=%.3f  R2=%.3f", fname, Xa.shape[1], r["value"], r2["value"]
        )
    ablation = pd.DataFrame(abl_rows)
    ablation.to_csv(cfg.output_dir / "feature_ablation.csv", index=False)
    results["feature_ablation"] = ablation.to_dict(orient="records")
    if run("figures"):
        plots.plot_feature_ablation(ablation, fig_dir, "RMSE", fmts)

    # ------------------------------------------------------- final model
    # Model selection uses the VALIDATION set only. Picking the primary model by
    # test-set score is a second, subtler form of leakage: the test set stops
    # being held out the moment it decides anything.
    if str(primary_model).lower() == "auto":
        # Selection is done by scaffold-grouped k-fold CV over the train+val pool,
        # never on the test set. A single held-out validation slice of ~60
        # compounds is itself a noisy estimator -- noisy enough that it can pick a
        # model that then underperforms on test, which is model selection adding
        # variance rather than removing it. Averaging over grouped folds uses the
        # same protocol as the final evaluation and is far more stable.
        from sklearn.model_selection import GroupKFold

        groups_fit = clean["scaffold"].to_numpy()[fit_idx]
        n_folds = min(5, len(np.unique(groups_fit)))
        gkf = GroupKFold(n_splits=n_folds)
        val_scores: dict[str, float] = {}
        val_spread: dict[str, float] = {}
        for name in zoo:
            if name == "dummy_mean":
                continue
            fold_rmse = []
            for f_tr, f_te in gkf.split(X[fit_idx], y[fit_idx], groups=groups_fit):
                est = models.get_model(name, seed=seed, n_jobs=n_jobs)
                est.fit(X[fit_idx][f_tr], y[fit_idx][f_tr])
                fold_rmse.append(
                    float(np.sqrt(np.mean((y[fit_idx][f_te] - est.predict(X[fit_idx][f_te])) ** 2)))
                )
            val_scores[name] = float(np.mean(fold_rmse))
            val_spread[name] = float(np.std(fold_rmse, ddof=1))
        primary_model = min(val_scores, key=val_scores.get)
        results["model_selection_cv_rmse"] = val_scores
        results["model_selection_cv_rmse_sd"] = val_spread
        LOGGER.info(
            "Model selected by %d-fold scaffold-grouped CV on train+val: %s  (%s)",
            n_folds,
            primary_model,
            ", ".join(
                f"{k}={v:.3f}+/-{val_spread[k]:.3f}"
                for k, v in sorted(val_scores.items(), key=lambda kv: kv[1])
            ),
        )

    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 6 — validation protocols for the primary model (%s)", primary_model)
    final = models.get_model(primary_model, seed=seed, n_jobs=n_jobs)
    final.fit(X[fit_idx], y[fit_idx])
    y_pred_test = final.predict(X[te])
    boot_final = evaluate.bootstrap_metrics(y[te], y_pred_test, n_boot, ci, seed)
    mtext = evaluate.metrics_table(boot_final)
    results["primary_model"] = primary_model
    results["primary_metrics"] = boot_final.to_dict(orient="records")
    results["primary_metrics_formatted"] = mtext
    LOGGER.info("Primary model test metrics: %s", json.dumps(mtext, indent=2))

    # nested CV (group-aware so it matches the scaffold protocol)
    ncv_cfg = cfg.get("models.nested_cv", {})
    ncv = evaluate.nested_cv(
        models.get_model(primary_model, seed=seed, n_jobs=n_jobs),
        X,
        y,
        models.get_param_distributions(primary_model),
        model_name=primary_model,
        outer_folds=int(ncv_cfg.get("outer_folds", 5)),
        inner_folds=int(ncv_cfg.get("inner_folds", 3)),
        n_iter=int(ncv_cfg.get("n_iter", 30)),
        scoring=ncv_cfg.get("scoring", "neg_root_mean_squared_error"),
        seed=seed,
        n_jobs=n_jobs,
        groups=clean["scaffold"].to_numpy(),
    )
    ncv_summary = ncv.summary()
    ncv_summary.to_csv(cfg.output_dir / "nested_cv_summary.csv", index=False)
    results["nested_cv"] = ncv_summary.to_dict(orient="records")
    results["nested_cv_best_params"] = ncv.best_params

    # y-scrambling
    ys = evaluate.y_scrambling(
        models.get_model(primary_model, seed=seed, n_jobs=n_jobs),
        X[fit_idx],
        y[fit_idx],
        X[te],
        y[te],
        n_permutations=int(cfg.get("evaluation.y_scrambling.n_permutations", 100)),
        seed=seed,
    )
    results["y_scrambling"] = {k: v for k, v in ys.items() if k not in ("null_r2", "null_rmse")}
    LOGGER.info(
        "Y-scrambling: real R2=%.3f, null R2=%.3f±%.3f, p=%.3g",
        ys["real_r2"],
        ys["null_r2_mean"],
        ys["null_r2_std"],
        ys["p_value"],
    )
    if run("figures"):
        plots.plot_y_scrambling(ys, fig_dir, fmts)

    # multi-seed repeats
    def _split_fn(d: pd.DataFrame, s: int):
        return splits.scaffold_split(
            d,
            cfg.get("split.test_size", 0.2),
            cfg.get("split.val_size", 0.1),
            balanced=cfg.get("split.scaffold.balanced", True),
            seed=s,
        )

    reps = evaluate.repeated_split_eval(
        models.get_model(primary_model, seed=seed, n_jobs=n_jobs),
        clean,
        lambda d: featurizer.transform(d["smiles"].tolist()),
        _split_fn,
        n_seeds=int(cfg.get("evaluation.repeats.n_seeds", 10)),
        base_seed=seed,
    )
    reps.to_csv(cfg.output_dir / "repeated_splits.csv", index=False)
    results["repeated_splits"] = {
        m: {"mean": float(reps[m].mean()), "std": float(reps[m].std(ddof=1))}
        for m in ("RMSE", "R2", "MAE", "Spearman_rho")
    }
    if run("figures"):
        plots.plot_seed_stability(reps, fig_dir, fmts)

    # learning curve
    lc = evaluate.learning_curve(
        models.get_model(primary_model, seed=seed, n_jobs=n_jobs),
        X[fit_idx],
        y[fit_idx],
        X[te],
        y[te],
        fractions=list(cfg.get("evaluation.learning_curve.fractions", [0.2, 0.5, 1.0])),
        n_repeats=int(cfg.get("evaluation.learning_curve.n_repeats", 5)),
        seed=seed,
    )
    lc.to_csv(cfg.output_dir / "learning_curve.csv", index=False)
    results["learning_curve"] = lc.to_dict(orient="records")
    if run("figures"):
        plots.plot_learning_curve(lc, fig_dir, noise_floor, fmts)

    # ------------------------------------------------- 7. uncertainty / AD
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 7 — applicability domain and conformal prediction")
    fps_all = features.rdkit_fps(clean["smiles"].tolist())
    ad = evaluate.ApplicabilityDomain(
        k=int(cfg.get("evaluation.applicability_domain.k_neighbors", 5))
    )
    ad.fit([fps_all[i] for i in fit_idx])
    test_fps = [fps_all[i] for i in te]
    ad_scores_test = ad.score(test_fps)
    ad_profile = ad.error_profile(
        test_fps,
        y[te],
        y_pred_test,
        n_bins=int(cfg.get("evaluation.applicability_domain.n_bins", 5)),
        seed=seed,
    )
    ad_profile.to_csv(cfg.output_dir / "applicability_domain_profile.csv", index=False)
    results["applicability_domain"] = {
        "threshold": ad.threshold_,
        "fraction_test_out_of_domain": float((ad_scores_test < ad.threshold_).mean()),
        "profile": ad_profile.to_dict(orient="records"),
    }
    if run("figures"):
        plots.plot_applicability_domain(
            ad_profile, ad.train_scores_, ad_scores_test, ad.threshold_, fig_dir, fmts
        )
        plots.plot_pred_vs_obs(
            y[te],
            y_pred_test,
            mtext,
            fig_dir,
            ad_scores_test,
            title=f"Predicted vs observed — {models.MODEL_DISPLAY_NAMES.get(primary_model, primary_model)}, scaffold-split test set",
            noise_floor=noise_floor,
            formats=fmts,
        )
        plots.plot_residual_diagnostics(y[te], y_pred_test, fig_dir, noise_floor, fmts)

    if cfg.get("conformal.enabled", True):
        cov = evaluate.coverage_curve(
            models.get_model(primary_model, seed=seed, n_jobs=n_jobs),
            X[fit_idx],
            y[fit_idx],
            X[te],
            y[te],
            calibration_fraction=float(cfg.get("conformal.calibration_fraction", 0.2)),
            seed=seed,
        )
        cov.to_csv(cfg.output_dir / "conformal_coverage.csv", index=False)
        conf = evaluate.conformal_intervals(
            models.get_model(primary_model, seed=seed, n_jobs=n_jobs),
            X[fit_idx],
            y[fit_idx],
            X[te],
            alpha=float(cfg.get("conformal.alpha", 0.2)),
            calibration_fraction=float(cfg.get("conformal.calibration_fraction", 0.2)),
            seed=seed,
        )
        covered = float(((y[te] >= conf["lower"]) & (y[te] <= conf["upper"])).mean())
        results["conformal"] = {
            "alpha": conf["alpha"],
            "nominal_coverage": 1 - conf["alpha"],
            "empirical_coverage": covered,
            "half_width": conf["half_width"],
            "coverage_curve": cov.to_dict(orient="records"),
        }
        LOGGER.info(
            "Conformal: nominal %.0f%% -> empirical %.1f%%, half-width %.3f",
            (1 - conf["alpha"]) * 100,
            covered * 100,
            conf["half_width"],
        )
        if run("figures"):
            plots.plot_conformal_calibration(cov, fig_dir, fmts)

    # ------------------------------------------------------ 8. interpretation
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 8 — interpretation")
    if cfg.get("interpretation.shap.enabled", True):
        try:
            feat_names = (
                featurizer.feature_names
                if hasattr(featurizer, "feature_names")
                else [f"bit_{i}" for i in range(X.shape[1])]
            )
            sv, shap_meta = interpret.compute_shap(
                final,
                X[fit_idx],
                X[te],
                background_size=int(cfg.get("interpretation.shap.background_size", 100)),
                seed=seed,
            )
            results["shap_method"] = shap_meta
            imp = interpret.shap_importance(sv, feat_names)
            imp.to_csv(cfg.output_dir / "shap_importance.csv", index=False)
            results["shap_top"] = imp.head(25).to_dict(orient="records")
            if run("figures"):
                plots.plot_shap_summary(
                    sv,
                    X[te],
                    feat_names,
                    fig_dir,
                    int(cfg.get("interpretation.shap.max_display", 20)),
                )
                plots.plot_shap_bar(imp, fig_dir, 20, fmts)
                recs = interpret.top_bit_substructures(
                    imp, clean.iloc[fit_idx]["smiles"].tolist(), featurizer, top_n=6
                )
                if recs:
                    plots.plot_bit_substructures(recs, fig_dir)
        except Exception as exc:
            LOGGER.warning("SHAP stage failed (non-fatal): %s", exc)

    cl_cfg = cfg.get("interpretation.activity_cliffs", {})
    pairs, sim_flat, delta_flat = interpret.find_activity_cliffs(
        clean,
        float(cl_cfg.get("similarity_threshold", 0.7)),
        float(cl_cfg.get("potency_delta", 2.0)),
    )
    if not pairs.empty:
        pairs.to_csv(cfg.output_dir / "activity_cliffs.csv", index=False)
        results["activity_cliffs"] = {
            "n_pairs": int(len(pairs)),
            "top": pairs.head(10).to_dict(orient="records"),
        }
        resid_map = dict(zip(clean.iloc[te]["chembl_id"], y[te] - y_pred_test))
        cliff_err = interpret.cliff_error_analysis(
            pairs, set(clean.iloc[te]["chembl_id"]), resid_map
        )
        if not cliff_err.empty:
            cliff_err.to_csv(cfg.output_dir / "cliff_error_analysis.csv", index=False)
            results["cliff_error_analysis"] = cliff_err.to_dict(orient="records")
        if run("figures"):
            plots.plot_activity_cliffs(pairs, fig_dir, int(cl_cfg.get("max_pairs_plotted", 6)))
    if run("figures"):
        plots.plot_cliff_landscape(
            sim_flat,
            delta_flat,
            fig_dir,
            float(cl_cfg.get("similarity_threshold", 0.7)),
            float(cl_cfg.get("potency_delta", 2.0)),
            fmts,
        )

    # ------------------------------------------------- 9. chemical space maps
    if run("figures"):
        LOGGER.info("Computing chemical-space embeddings")
        coords = {}
        try:
            from sklearn.decomposition import PCA

            coords["pca"] = PCA(n_components=2, random_state=seed).fit_transform(X)
        except Exception as exc:
            LOGGER.warning("PCA failed: %s", exc)
        try:
            import umap

            coords["umap"] = umap.UMAP(
                n_neighbors=15, min_dist=0.1, metric="jaccard", random_state=seed
            ).fit_transform(X)
        except Exception as exc:
            LOGGER.warning("UMAP failed (non-fatal): %s", exc)
        if coords:
            plots.plot_chemical_space(coords, clean, split_idx, fig_dir, fmts)

    # ------------------------------------------------------------ 10. persist
    LOGGER.info("=" * 78)
    LOGGER.info("STAGE 9 — persistence")
    artifact = {
        "model": final,
        "featurizer_name": primary_name,
        "n_bits": n_bits,
        "applicability_domain": ad,
        "config_fingerprint": cfg.fingerprint(),
        "train_smiles": clean.iloc[fit_idx]["smiles"].tolist(),
        "conformal_half_width": results.get("conformal", {}).get("half_width"),
        "version": "1.0.0",
    }
    model_path = cfg.model_dir / "drd2_qsar_model.joblib"
    joblib.dump(artifact, model_path)
    LOGGER.info("Model artifact -> %s", model_path)

    results["runtime_seconds"] = round(time.time() - t0, 1)
    metrics_path = cfg.output_dir / "metrics.json"
    metrics_path.write_text(json.dumps(results, indent=2, default=_json_safe))
    LOGGER.info("Metrics -> %s", metrics_path)
    LOGGER.info("Pipeline finished in %.1f s", results["runtime_seconds"])
    return results


# --------------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="drd2-qsar", description="End-to-end DRD2 QSAR pipeline")
    ap.add_argument("--config", default="configs/drd2.yaml", help="YAML config path")
    ap.add_argument(
        "--force-refresh",
        action="store_true",
        help="re-query ChEMBL even if a cached raw pull exists",
    )
    ap.add_argument("--no-figures", action="store_true", help="skip figure generation")
    ap.add_argument(
        "--quick", action="store_true", help="reduced bootstrap/permutation budget for a smoke test"
    )
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    setup_logging(logging.DEBUG if args.verbose else logging.INFO)
    cfg = load_config(args.config)

    if args.quick:
        cfg.raw["evaluation"]["bootstrap"]["n_resamples"] = 100
        cfg.raw["evaluation"]["y_scrambling"]["n_permutations"] = 10
        cfg.raw["evaluation"]["repeats"]["n_seeds"] = 3
        cfg.raw["evaluation"]["learning_curve"]["n_repeats"] = 2
        cfg.raw["models"]["nested_cv"]["n_iter"] = 5
        LOGGER.warning("QUICK MODE — reduced statistical budget, not for publication")

    stages = None if not args.no_figures else {"benchmark"}
    try:
        run_pipeline(cfg, stages=stages, force_refresh=args.force_refresh)
    except Exception:
        LOGGER.exception("Pipeline failed")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
