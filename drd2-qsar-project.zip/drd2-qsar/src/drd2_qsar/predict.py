"""Inference on new compounds, with the honesty layer attached.

    drd2-predict --model models/drd2_qsar_model.joblib --input new.smi --output preds.csv

A bare predicted number is not a deliverable. Every prediction this script emits
carries three things alongside it:

* an **applicability-domain flag** — is this compound in the chemical
  neighbourhood the model was trained on, or is the model extrapolating?
* a **conformal prediction interval** — the range that covers the truth at the
  configured rate, learned from held-out calibration residuals rather than
  asserted.
* the **nearest training neighbour** and its measured potency — so a chemist
  can immediately see what the prediction is really based on.

The same standardization used in training is applied to the input, so a salt
form or an odd tautomer in the query file does not silently become a different
molecule from the one the model saw.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from .config import setup_logging

LOGGER = logging.getLogger("drd2_qsar.predict")

STANDARDIZE_OPTS = {
    "largest_fragment": True,
    "uncharge": True,
    "normalize": True,
    "canonical_tautomer": True,
    "disconnect_metals": True,
    "remove_stereo": False,
}


def read_input(path: Path) -> pd.DataFrame:
    """Accept .smi (SMILES [name] per line) or .csv with a smiles column."""
    path = Path(path)
    if path.suffix.lower() in (".csv", ".tsv"):
        sep = "\t" if path.suffix.lower() == ".tsv" else ","
        df = pd.read_csv(path, sep=sep)
        col = next((c for c in df.columns if c.lower() in ("smiles", "canonical_smiles")), None)
        if col is None:
            raise ValueError(f"No SMILES column found in {path}")
        out = pd.DataFrame({"input_smiles": df[col].astype(str)})
        name_col = next((c for c in df.columns if c.lower() in ("name", "id", "chembl_id")), None)
        out["name"] = df[name_col].astype(str) if name_col else [f"mol_{i}" for i in range(len(df))]
        return out

    rows = []
    for i, line in enumerate(path.read_text().splitlines()):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        rows.append({"input_smiles": parts[0], "name": parts[1] if len(parts) > 1 else f"mol_{i}"})
    return pd.DataFrame(rows)


def predict(model_path: Path, smiles_df: pd.DataFrame) -> pd.DataFrame:
    from . import curate, features

    art = joblib.load(model_path)
    model = art["model"]
    featurizer = features.get_featurizer(art["featurizer_name"], art.get("n_bits", 2048))
    ad = art.get("applicability_domain")
    half_width = art.get("conformal_half_width")
    train_smiles = art.get("train_smiles", [])

    standardize = curate.build_standardizer(STANDARDIZE_OPTS)
    smiles_df = smiles_df.copy()
    smiles_df["smiles"] = [standardize(s) for s in smiles_df["input_smiles"]]

    bad = smiles_df["smiles"].isna()
    if bad.any():
        LOGGER.warning(
            "%d input structures could not be parsed and are reported as failures", int(bad.sum())
        )
    ok = smiles_df.loc[~bad].copy()
    if ok.empty:
        smiles_df["pIC50_pred"] = np.nan
        smiles_df["status"] = "unparseable"
        return smiles_df

    X = featurizer.transform(ok["smiles"].tolist())
    ok["pIC50_pred"] = model.predict(X)
    ok["IC50_nM_pred"] = 10 ** (9.0 - ok["pIC50_pred"])

    # applicability domain + nearest neighbour
    if ad is not None and train_smiles:
        query_fps = features.rdkit_fps(ok["smiles"].tolist())
        ok["ad_similarity"] = ad.score(query_fps)
        ok["in_domain"] = ok["ad_similarity"] >= ad.threshold_
        train_fps = features.rdkit_fps(train_smiles)
        sims = features.tanimoto_matrix(query_fps, train_fps)
        nn = sims.argmax(axis=1)
        ok["nearest_train_similarity"] = sims[np.arange(len(sims)), nn]
        ok["nearest_train_smiles"] = [train_smiles[i] for i in nn]
    else:
        ok["ad_similarity"] = np.nan
        ok["in_domain"] = pd.NA

    if half_width is not None:
        ok["pred_lower"] = ok["pIC50_pred"] - half_width
        ok["pred_upper"] = ok["pIC50_pred"] + half_width

    ok["status"] = np.where(
        ok["in_domain"].fillna(False), "ok", "out_of_domain — treat as a rank, not a value"
    )

    failed = smiles_df.loc[bad].copy()
    if not failed.empty:
        failed["pIC50_pred"] = np.nan
        failed["status"] = "unparseable"
    return pd.concat([ok, failed], ignore_index=True)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="drd2-predict", description="Predict DRD2 pIC50")
    ap.add_argument("--model", default="models/drd2_qsar_model.joblib")
    ap.add_argument("--input", required=True, help=".smi or .csv of query structures")
    ap.add_argument("--output", default="predictions.csv")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    setup_logging(logging.DEBUG if args.verbose else logging.INFO)
    df = read_input(Path(args.input))
    LOGGER.info("Predicting for %d structures", len(df))
    out = predict(Path(args.model), df)
    out.to_csv(args.output, index=False)

    # in_domain can be object-dtype (it carries pd.NA for unparseable rows), and
    # `~` on an object Series does a bitwise-not on the Python bools — ~True is -2,
    # not False — which silently produces a negative count. Cast first.
    n_out = int((~out["in_domain"].fillna(False).astype(bool)).sum())
    LOGGER.info("Wrote %s", args.output)
    LOGGER.info(
        "%d/%d predictions are outside the applicability domain — "
        "use those for ranking only, not as potency estimates",
        n_out,
        len(out),
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
