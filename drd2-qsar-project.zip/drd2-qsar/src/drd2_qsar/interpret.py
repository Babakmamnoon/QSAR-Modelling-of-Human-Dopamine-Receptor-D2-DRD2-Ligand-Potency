"""Model interpretation: SHAP attribution and matched-molecular-pair activity cliffs.

A fingerprint model that cannot be interrogated is a black box a medicinal
chemist will not act on. Two things make it actionable:

* **SHAP on the fingerprint bits, mapped back to substructures.** A bit index is
  meaningless on its own; ``top_bit_substructures`` finds a molecule where each
  influential bit is set and returns the atom environment that sets it, so the
  explanation is a picture of a chemical group rather than "feature 1174".
* **Activity cliffs.** The pairs where a near-identical structure change swings
  potency by orders of magnitude are exactly where any similarity-based model
  fails. Enumerating them explicitly turns "the model has some big errors" into
  "here are the six pairs that cause them".
"""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd

LOGGER = logging.getLogger("drd2_qsar.interpret")


# --------------------------------------------------------------------------- #
# SHAP
# --------------------------------------------------------------------------- #
def compute_shap(
    model,
    X_background: np.ndarray,
    X_explain: np.ndarray,
    background_size: int = 100,
    seed: int = 42,
    y_background: np.ndarray | None = None,
    surrogate_for_nontree: bool = True,
):
    """Exact TreeSHAP where the model allows it; a documented surrogate where it does not.

    TreeSHAP is exact and fast on tree ensembles. KernelSHAP, the model-agnostic
    fallback, scales so badly on a 2048-bit fingerprint that it is not a usable
    option — a single run would take hours and still be approximate.

    So when the primary model is *not* tree-based (an SVR, say), the honest move
    is not to run KernelSHAP badly. It is to fit a **surrogate gradient-boosted
    tree on the primary model's own predictions**, explain that exactly, and
    label the result as what it is: an explanation of a faithful approximation,
    not of the model itself. The surrogate's R² against the primary model's
    predictions is logged and returned so the reader can judge how much to
    trust the attribution.
    """
    import shap

    rng = np.random.default_rng(seed)
    bg_idx = rng.choice(
        len(X_background), size=min(background_size, len(X_background)), replace=False
    )
    background = X_background[bg_idx]
    meta: dict = {"method": None, "surrogate_fidelity_r2": None}

    try:
        explainer = shap.TreeExplainer(model)
        values = explainer.shap_values(X_explain, check_additivity=False)
        meta["method"] = f"TreeSHAP (exact, on {type(model).__name__})"
        LOGGER.info("SHAP: %s", meta["method"])
        return np.asarray(values), meta
    except Exception as exc:
        LOGGER.info("TreeSHAP not applicable to %s (%s)", type(model).__name__, exc)

    if not surrogate_for_nontree:
        LOGGER.warning("Falling back to KernelSHAP — this is slow and approximate")
        explainer = shap.KernelExplainer(model.predict, background)
        values = explainer.shap_values(X_explain[: min(50, len(X_explain))], nsamples=100)
        meta["method"] = "KernelSHAP (approximate, subsampled)"
        return np.asarray(values), meta

    from sklearn.metrics import r2_score
    from xgboost import XGBRegressor

    y_proxy = model.predict(X_background)
    surrogate = XGBRegressor(
        n_estimators=400,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.6,
        random_state=seed,
        n_jobs=-1,
        verbosity=0,
    ).fit(X_background, y_proxy)

    fidelity = float(r2_score(model.predict(X_explain), surrogate.predict(X_explain)))
    meta["method"] = f"TreeSHAP on a gradient-boosted surrogate of {type(model).__name__}"
    meta["surrogate_fidelity_r2"] = fidelity
    LOGGER.info(
        "SHAP: %s — surrogate reproduces the primary model's test predictions " "with R² = %.3f",
        meta["method"],
        fidelity,
    )
    if fidelity < 0.8:
        LOGGER.warning(
            "Surrogate fidelity is only R² = %.3f; treat the attribution as "
            "indicative of the feature space, not of this specific model.",
            fidelity,
        )
    values = shap.TreeExplainer(surrogate).shap_values(X_explain, check_additivity=False)
    return np.asarray(values), meta


def shap_importance(shap_values: np.ndarray, feature_names: list[str]) -> pd.DataFrame:
    """Rank features by mean |SHAP|, keeping the mean signed value for direction."""
    mean_abs = np.abs(shap_values).mean(axis=0)
    mean_signed = shap_values.mean(axis=0)
    out = pd.DataFrame(
        {
            "feature": feature_names,
            "mean_abs_shap": mean_abs,
            "mean_signed_shap": mean_signed,
            "direction": np.where(mean_signed >= 0, "increases", "decreases"),
        }
    )
    return out.sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)


def top_bit_substructures(
    importance: pd.DataFrame,
    smiles: list[str],
    featurizer,
    top_n: int = 6,
) -> list[dict]:
    """For each influential ECFP bit, find a molecule that sets it and the atoms involved.

    This is what converts a SHAP bar chart into chemistry a project team can
    read: bit 1174 becomes "this piperazine nitrogen and its two neighbours".
    """
    if not hasattr(featurizer, "bit_info"):
        LOGGER.warning("Featurizer %s cannot map bits to substructures", featurizer.name)
        return []

    from rdkit import Chem

    records: list[dict] = []
    for _, row in importance.iterrows():
        if len(records) >= top_n:
            break
        feat = str(row["feature"])
        if not feat.startswith("bit_"):
            continue
        bit = int(feat.split("_", 1)[1])

        for smi in smiles:
            info = featurizer.bit_info(smi)
            if bit not in info:
                continue
            atom_idx, radius = info[bit][0]
            mol = Chem.MolFromSmiles(smi)
            if mol is None:
                continue
            if radius > 0:
                env = Chem.FindAtomEnvironmentOfRadiusN(mol, radius, atom_idx)
                atoms = sorted(
                    {
                        a
                        for b in env
                        for a in (
                            mol.GetBondWithIdx(b).GetBeginAtomIdx(),
                            mol.GetBondWithIdx(b).GetEndAtomIdx(),
                        )
                    }
                )
            else:
                atoms = [atom_idx]
            records.append(
                {
                    "bit": bit,
                    "smiles": smi,
                    "atoms": atoms,
                    "radius": radius,
                    "mean_abs_shap": float(row["mean_abs_shap"]),
                    "direction": row["direction"],
                }
            )
            break
    LOGGER.info("Mapped %d SHAP bits back to substructures", len(records))
    return records


# --------------------------------------------------------------------------- #
# Activity cliffs
# --------------------------------------------------------------------------- #
def find_activity_cliffs(
    df: pd.DataFrame,
    similarity_threshold: float = 0.7,
    potency_delta: float = 2.0,
    max_pairs: int = 5000,
) -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    """Enumerate structurally similar pairs with large potency differences.

    Returns the cliff pairs (sorted by a SALI-like score), plus the full
    similarity and |Δ potency| vectors for the landscape plot.
    """
    from .features import rdkit_fps, tanimoto_matrix

    fps = rdkit_fps(df["smiles"].tolist())
    sims = tanimoto_matrix(fps, fps)
    y = df["pIC50"].to_numpy(dtype=float)

    iu = np.triu_indices(len(df), k=1)
    sim_flat = sims[iu]
    delta_flat = np.abs(y[iu[0]] - y[iu[1]])

    mask = (sim_flat >= similarity_threshold) & (delta_flat >= potency_delta)
    LOGGER.info(
        "Activity cliffs: %d pairs with Tanimoto >= %.2f and |ΔpIC50| >= %.1f",
        int(mask.sum()),
        similarity_threshold,
        potency_delta,
    )
    if not mask.any():
        return pd.DataFrame(), sim_flat, delta_flat

    ia, ib = iu[0][mask], iu[1][mask]
    sali = delta_flat[mask] / np.clip(1.0 - sim_flat[mask], 1e-3, None)
    pairs = pd.DataFrame(
        {
            "id_a": df.iloc[ia]["chembl_id"].values,
            "id_b": df.iloc[ib]["chembl_id"].values,
            "smiles_a": df.iloc[ia]["smiles"].values,
            "smiles_b": df.iloc[ib]["smiles"].values,
            "pIC50_a": y[ia],
            "pIC50_b": y[ib],
            "delta": delta_flat[mask],
            "similarity": sim_flat[mask],
            "SALI": sali,
        }
    )
    pairs = pairs.sort_values("SALI", ascending=False).head(max_pairs).reset_index(drop=True)
    return pairs, sim_flat, delta_flat


def cliff_error_analysis(
    cliff_pairs: pd.DataFrame, test_ids: set[str], residuals: dict[str, float]
) -> pd.DataFrame:
    """Are the model's worst test errors concentrated on activity-cliff compounds?"""
    if cliff_pairs.empty:
        return pd.DataFrame()
    cliff_members = set(cliff_pairs["id_a"]) | set(cliff_pairs["id_b"])
    rows = []
    for cid, resid in residuals.items():
        if cid not in test_ids:
            continue
        rows.append(
            {"chembl_id": cid, "abs_residual": abs(resid), "on_cliff": cid in cliff_members}
        )
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    summary = (
        out.groupby("on_cliff")["abs_residual"]
        .agg(["count", "mean", "median", "max"])
        .reset_index()
    )
    LOGGER.info("Cliff vs non-cliff test error:\n%s", summary.to_string(index=False))
    return summary
