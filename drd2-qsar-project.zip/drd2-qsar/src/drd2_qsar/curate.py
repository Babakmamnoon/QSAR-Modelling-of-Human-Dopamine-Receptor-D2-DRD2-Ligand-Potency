"""Structure standardization, plausibility filtering and replicate aggregation.

This is where the legacy dataset's real problems get fixed, and every fix is
logged as a row in an audit trail so the curation is reviewable rather than
magical. The audit trail is emitted as ``reports/curation_audit.csv`` and its
summary becomes a table in the README.

The five substantive defects this module is built to catch
----------------------------------------------------------
1. **Unit-mishandled potencies.** The legacy CSV contains pIC50 values up to
   16.4 (sub-femtomolar), which is not a physically achievable affinity for a
   small molecule at a GPCR. ``pic50_min``/``pic50_max`` reject them and the
   rejected rows are printed, not silently dropped.
2. **Salt and solvate components.** 50/631 legacy SMILES carry HBr or HCl.
   Fingerprinting them as-is makes the same parent molecule two different
   feature vectors. Largest-fragment selection strips them.
3. **Duplicate parents under different ChEMBL IDs.** Deduplication is done on
   the InChIKey *connectivity* layer, not on the accession, so salt forms and
   stereo-unspecified entries of one parent collapse together.
4. **Irreproducible replicates.** When one parent has several measurements
   spanning more than ``max_replicate_spread`` log units, the "true" value is
   unknowable from this data and the compound is dropped rather than averaged
   into a confident-looking wrong number.
5. **Mechanistic incoherence.** Dopamine, norepinephrine and apomorphine are
   *agonists*. Pooling them into a model of "inhibitor potency" is not a
   modelling choice, it is a category error. ``action_type_policy`` separates
   them.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import Descriptors
from rdkit.Chem.MolStandardize import rdMolStandardize

LOGGER = logging.getLogger("drd2_qsar.curate")
RDLogger.DisableLog("rdApp.*")

# Well-characterised DRD2 *agonists* / endogenous ligands that appear in ChEMBL
# IC50 tables. Used when the mechanism endpoint is unreachable (offline runs)
# so the agonist/antagonist policy still has teeth. Extend freely; every entry
# is a documented reference compound, not a heuristic guess.
KNOWN_DRD2_AGONISTS: dict[str, str] = {
    "CHEMBL59": "dopamine (endogenous agonist)",
    "CHEMBL1437": "norepinephrine (endogenous catecholamine)",
    "CHEMBL39": "serotonin (endogenous amine, off-target)",
    "CHEMBL26736": "2-aminotetralin catechol (agonist scaffold)",
    "CHEMBL225230": "apomorphine-type aporphine (agonist)",
    "CHEMBL27": "apomorphine",
    "CHEMBL1201314": "quinpirole",
    "CHEMBL287966": "bromocriptine",
    "CHEMBL1201087": "pramipexole",
    "CHEMBL1587": "ropinirole",
    "CHEMBL1201265": "rotigotine",
    "CHEMBL1201": "cabergoline",
}


# --------------------------------------------------------------------------- #
# Audit trail
# --------------------------------------------------------------------------- #
@dataclass
class CurationAudit:
    """Records how many rows each curation stage removed, and why."""

    steps: list[dict] = field(default_factory=list)

    def record(self, stage: str, before: int, after: int, reason: str) -> None:
        self.steps.append(
            {
                "stage": stage,
                "n_before": before,
                "n_after": after,
                "n_removed": before - after,
                "reason": reason,
            }
        )
        LOGGER.info("%-28s %6d -> %6d  (-%d)  %s", stage, before, after, before - after, reason)

    def to_frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.steps)

    def write(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.to_frame().to_csv(path, index=False)
        LOGGER.info("Wrote curation audit -> %s", path)


# --------------------------------------------------------------------------- #
# Standardization
# --------------------------------------------------------------------------- #
def build_standardizer(opts: dict):
    """Assemble the RDKit standardization closure from config flags."""
    lfc = rdMolStandardize.LargestFragmentChooser()
    uncharger = rdMolStandardize.Uncharger()
    normalizer = rdMolStandardize.Normalizer()
    metal = rdMolStandardize.MetalDisconnector()
    te = rdMolStandardize.TautomerEnumerator()

    def _standardize(smiles: str) -> str | None:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        try:
            if opts.get("disconnect_metals", True):
                mol = metal.Disconnect(mol)
            if opts.get("normalize", True):
                mol = normalizer.normalize(mol)
            if opts.get("largest_fragment", True):
                mol = lfc.choose(mol)
            if opts.get("uncharge", True):
                mol = uncharger.uncharge(mol)
            if opts.get("canonical_tautomer", True):
                mol = te.Canonicalize(mol)
            if opts.get("remove_stereo", False):
                Chem.RemoveStereochemistry(mol)
            Chem.SanitizeMol(mol)
            return Chem.MolToSmiles(mol)
        except Exception:
            return None

    return _standardize


def inchikey_parts(smiles: str) -> tuple[str | None, str | None]:
    """Return (full InChIKey, connectivity-layer InChIKey)."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, None
    try:
        key = Chem.MolToInchiKey(mol)
    except Exception:
        return None, None
    if not key:
        return None, None
    return key, key.split("-")[0]


def element_ok(smiles: str, allowed: set[str]) -> bool:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return False
    return all(a.GetSymbol() in allowed for a in mol.GetAtoms())


# --------------------------------------------------------------------------- #
# Main curation pipeline
# --------------------------------------------------------------------------- #
def curate(
    raw: pd.DataFrame,
    cfg_cur: dict,
    action_types: pd.DataFrame | None = None,
) -> tuple[pd.DataFrame, CurationAudit, pd.DataFrame]:
    """Turn a raw ChEMBL activity table into a modelling-ready dataset.

    Returns
    -------
    clean : pd.DataFrame
        One row per unique parent structure, with ``smiles``, ``pIC50``,
        ``inchikey``, ``chembl_id`` and provenance columns.
    audit : CurationAudit
        Stage-by-stage row counts.
    rejected : pd.DataFrame
        Every row that was removed, with the reason — so nothing disappears
        without an explanation.
    """
    audit = CurationAudit()
    rejected_frames: list[pd.DataFrame] = []

    def _reject(mask: pd.Series, frame: pd.DataFrame, reason: str) -> None:
        if mask.any():
            bad = frame.loc[mask].copy()
            bad["rejection_reason"] = reason
            rejected_frames.append(bad)

    df = raw.copy()
    n0 = len(df)
    audit.record("00_raw_pull", n0, n0, "rows returned by ChEMBL")

    # -- 1. required fields present ----------------------------------------- #
    before = len(df)
    need = ["canonical_smiles", "standard_value"]
    mask = df[need].isna().any(axis=1)
    _reject(mask, df, "missing SMILES or standard_value")
    df = df.loc[~mask].copy()
    audit.record("01_missing_fields", before, len(df), "null SMILES or activity value")

    # -- 2. relation / units / assay type ----------------------------------- #
    before = len(df)
    if "standard_relation" in df:
        mask = df["standard_relation"].fillna("=") != "="
        _reject(mask, df, "censored measurement (non '=' relation)")
        df = df.loc[~mask].copy()
    audit.record("02_censored", before, len(df), "kept only exact '=' measurements")

    before = len(df)
    if "standard_units" in df:
        mask = df["standard_units"].fillna("") != "nM"
        _reject(mask, df, "units other than nM")
        df = df.loc[~mask].copy()
    audit.record("03_units", before, len(df), "kept only nM")

    # -- 3. ChEMBL validity flags ------------------------------------------- #
    before = len(df)
    if "data_validity_comment" in df:
        flags = set(cfg_cur.get("drop_validity_comments", []) or [])
        comment = df["data_validity_comment"].fillna("")
        mask = comment.isin(flags) | (comment.str.len() > 0)
        _reject(mask, df, "ChEMBL data_validity_comment flag")
        df = df.loc[~mask].copy()
    audit.record("04_validity_flags", before, len(df), "ChEMBL-flagged suspect records")

    # -- 4. numeric activity, pIC50 ----------------------------------------- #
    before = len(df)
    df["standard_value"] = pd.to_numeric(df["standard_value"], errors="coerce")
    mask = df["standard_value"].isna() | (df["standard_value"] <= 0)
    _reject(mask, df, "non-positive or non-numeric activity")
    df = df.loc[~mask].copy()
    df["pIC50"] = 9.0 - np.log10(df["standard_value"].astype(float))
    audit.record("05_numeric_activity", before, len(df), "value must be positive and numeric")

    # -- 5. plausibility window (catches the unit errors) -------------------- #
    before = len(df)
    lo = float(cfg_cur.get("pic50_min", 3.0))
    hi = float(cfg_cur.get("pic50_max", 11.0))
    mask = (df["pIC50"] < lo) | (df["pIC50"] > hi)
    if mask.any():
        offenders = df.loc[mask, ["molecule_chembl_id", "pIC50"]].sort_values(
            "pIC50", ascending=False
        )
        LOGGER.warning(
            "Implausible pIC50 values outside [%.1f, %.1f] — rejecting %d rows:\n%s",
            lo,
            hi,
            int(mask.sum()),
            offenders.head(15).to_string(index=False),
        )
    _reject(mask, df, f"pIC50 outside plausibility window [{lo}, {hi}]")
    df = df.loc[~mask].copy()
    audit.record("06_plausibility_window", before, len(df), f"pIC50 in [{lo}, {hi}]")

    # -- 6. structure standardization --------------------------------------- #
    before = len(df)
    standardize = build_standardizer(cfg_cur.get("standardize", {}))
    df["smiles"] = [standardize(s) for s in df["canonical_smiles"].astype(str)]
    mask = df["smiles"].isna()
    _reject(mask, df, "RDKit could not parse/standardize the structure")
    df = df.loc[~mask].copy()
    n_salt = int(df["canonical_smiles"].astype(str).str.contains(r"\.", regex=True).sum())
    audit.record(
        "07_standardization",
        before,
        len(df),
        f"largest-fragment/uncharge/tautomer; {n_salt} multi-component inputs desalted",
    )

    # -- 7. element and size sanity ----------------------------------------- #
    before = len(df)
    allowed = set(cfg_cur.get("allowed_elements", []))
    if allowed:
        ok = df["smiles"].map(lambda s: element_ok(s, allowed))
        _reject(~ok, df, "contains a disallowed element")
        df = df.loc[ok].copy()
    mols = [Chem.MolFromSmiles(s) for s in df["smiles"]]
    df["n_heavy"] = [m.GetNumHeavyAtoms() if m else 0 for m in mols]
    lo_ha = int(cfg_cur.get("min_heavy_atoms", 8))
    hi_ha = int(cfg_cur.get("max_heavy_atoms", 70))
    mask = (df["n_heavy"] < lo_ha) | (df["n_heavy"] > hi_ha)
    _reject(mask, df, f"heavy-atom count outside [{lo_ha}, {hi_ha}]")
    df = df.loc[~mask].copy()
    audit.record(
        "08_element_size_sanity", before, len(df), f"elements + {lo_ha}-{hi_ha} heavy atoms"
    )

    # -- 8. mechanism policy (agonist / antagonist) -------------------------- #
    before = len(df)
    policy = cfg_cur.get("action_type_policy", "keep_all")
    df["action_type"] = pd.NA
    if action_types is not None and len(action_types):
        df = df.merge(
            action_types[["molecule_chembl_id", "action_type"]],
            on="molecule_chembl_id",
            how="left",
            suffixes=("_drop", ""),
        )
        if "action_type_drop" in df:
            df = df.drop(columns=["action_type_drop"])
    # offline reinforcement from the documented reference list
    is_known_agonist = df["molecule_chembl_id"].astype(str).isin(KNOWN_DRD2_AGONISTS)
    df.loc[is_known_agonist & df["action_type"].isna(), "action_type"] = "AGONIST"

    if policy == "antagonists_only":
        mask = df["action_type"].astype(str).str.upper().eq("AGONIST")
        _reject(mask, df, "agonist excluded by action_type_policy")
        df = df.loc[~mask].copy()
    elif policy == "agonists_only":
        mask = ~df["action_type"].astype(str).str.upper().eq("AGONIST")
        _reject(mask, df, "non-agonist excluded by action_type_policy")
        df = df.loc[~mask].copy()
    n_ago = int(df["action_type"].astype(str).str.upper().eq("AGONIST").sum())
    audit.record(
        "09_mechanism_policy",
        before,
        len(df),
        f"policy={policy}; {n_ago} annotated agonists remain in set",
    )

    # -- 9. optional legacy activity cutoff ---------------------------------- #
    before = len(df)
    if cfg_cur.get("apply_activity_cutoff", False):
        cutoff_nm = float(cfg_cur.get("activity_cutoff_nm", 1000))
        mask = df["standard_value"] >= cutoff_nm
        _reject(mask, df, f"IC50 >= {cutoff_nm} nM (legacy potent-only window)")
        df = df.loc[~mask].copy()
        audit.record(
            "10_activity_cutoff", before, len(df), f"legacy IC50 < {cutoff_nm} nM window APPLIED"
        )
    else:
        audit.record(
            "10_activity_cutoff", before, len(df), "NOT applied — full dynamic range retained"
        )

    # -- 10. InChIKey + replicate aggregation -------------------------------- #
    before = len(df)
    keys = [inchikey_parts(s) for s in df["smiles"]]
    df["inchikey"] = [k[0] for k in keys]
    df["inchikey14"] = [k[1] for k in keys]
    mask = df["inchikey14"].isna()
    _reject(mask, df, "InChIKey generation failed")
    df = df.loc[~mask].copy()
    audit.record("11_inchikey", before, len(df), "connectivity-layer key for deduplication")

    dedup_key = cfg_cur.get("dedup_key", "inchikey14")
    agg = cfg_cur.get("aggregate", "median")
    max_spread = float(cfg_cur.get("max_replicate_spread", 1.0))

    grouped = df.groupby(dedup_key)["pIC50"]
    spread = (grouped.max() - grouped.min()).rename("replicate_spread")
    n_rep = grouped.size().rename("n_replicates")
    central = getattr(grouped, agg)().rename("pIC50")

    summary = pd.concat([central, spread, n_rep], axis=1).reset_index()
    n_multi = int((summary["n_replicates"] > 1).sum())

    before = len(summary)
    noisy = summary["replicate_spread"] > max_spread
    if noisy.any():
        LOGGER.warning(
            "Dropping %d compounds whose replicate measurements span > %.2f log units",
            int(noisy.sum()),
            max_spread,
        )
        bad_keys = set(summary.loc[noisy, dedup_key])
        _reject(
            df[dedup_key].isin(bad_keys),
            df,
            f"replicate spread > {max_spread} log units (irreproducible)",
        )
    summary = summary.loc[~noisy].copy()

    # attach a representative structure / id per parent (first by ChEMBL id sort)
    rep = (
        df.sort_values("molecule_chembl_id")
        .drop_duplicates(dedup_key)
        .set_index(dedup_key)[
            [
                "smiles",
                "molecule_chembl_id",
                "inchikey",
                "action_type",
                "n_heavy",
                "document_year",
            ]
        ]
    )
    clean = summary.join(rep, on=dedup_key)
    clean = clean.rename(columns={"molecule_chembl_id": "chembl_id", "document_year": "year"})
    clean = clean[
        [
            "chembl_id",
            "smiles",
            "inchikey",
            dedup_key,
            "pIC50",
            "n_replicates",
            "replicate_spread",
            "action_type",
            "n_heavy",
            "year",
        ]
    ].reset_index(drop=True)

    audit.record(
        "12_replicate_aggregation",
        before,
        len(clean),
        f"{agg} over {n_multi} multi-measurement parents; spread <= {max_spread} log",
    )
    audit.record("13_final", len(clean), len(clean), "modelling-ready unique parent structures")

    rejected = (
        pd.concat(rejected_frames, ignore_index=True)
        if rejected_frames
        else pd.DataFrame(columns=list(raw.columns) + ["rejection_reason"])
    )
    return clean, audit, rejected


# --------------------------------------------------------------------------- #
# Physicochemical properties (used by the data-characterisation figures)
# --------------------------------------------------------------------------- #
PROPERTY_FUNCS = {
    "MW": Descriptors.MolWt,
    "cLogP": Descriptors.MolLogP,
    "TPSA": Descriptors.TPSA,
    "HBD": Descriptors.NumHDonors,
    "HBA": Descriptors.NumHAcceptors,
    "RotB": Descriptors.NumRotatableBonds,
    "AromaticRings": Descriptors.NumAromaticRings,
    "FractionCSP3": Descriptors.FractionCSP3,
    "HeavyAtoms": Descriptors.HeavyAtomCount,
    "QED": None,  # filled below to avoid an import cycle
}


def compute_properties(smiles: pd.Series) -> pd.DataFrame:
    """Compute the standard property panel for a series of SMILES."""
    from rdkit.Chem import QED

    rows = []
    for smi in smiles:
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            rows.append({k: np.nan for k in PROPERTY_FUNCS})
            continue
        rec = {}
        for name, fn in PROPERTY_FUNCS.items():
            if name == "QED":
                try:
                    rec[name] = QED.qed(mol)
                except Exception:
                    rec[name] = np.nan
            else:
                rec[name] = fn(mol)
        rows.append(rec)
    props = pd.DataFrame(rows, index=smiles.index)
    # Lipinski / Veber compliance flags
    props["Lipinski_violations"] = (
        (props["MW"] > 500).astype(int)
        + (props["cLogP"] > 5).astype(int)
        + (props["HBD"] > 5).astype(int)
        + (props["HBA"] > 10).astype(int)
    )
    props["Veber_pass"] = ((props["RotB"] <= 10) & (props["TPSA"] <= 140)).astype(int)
    return props
