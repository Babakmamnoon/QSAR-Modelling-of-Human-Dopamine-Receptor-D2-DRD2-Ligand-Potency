"""Evaluation: metrics with confidence intervals, validation protocols, uncertainty.

Nothing here reports a bare point estimate. A test set of ~150 compounds gives an
R² whose 95% interval is routinely ±0.15 wide; quoting "R² = 0.62" from such a
set and comparing it to someone else's "R² = 0.66" is comparing noise. Every
metric in this module carries a bootstrap interval, and the model comparison is
read off overlapping intervals rather than off the ranking.

Contents
--------
``regression_metrics``      point estimates for the standard panel
``bootstrap_metrics``       the same panel with percentile bootstrap 95% CIs
``nested_cv``               unbiased performance + inner-loop tuning
``y_scrambling``            label-permutation null with an empirical p-value
``ApplicabilityDomain``     Tanimoto-to-training-set distance + error binning
``conformal_intervals``     split-conformal prediction intervals with coverage
``learning_curve``          performance vs training-set size, with CIs
``repeated_split_eval``     multi-seed repeats to remove single-split luck
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.base import clone
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import KFold, RandomizedSearchCV

LOGGER = logging.getLogger("drd2_qsar.evaluate")


# --------------------------------------------------------------------------- #
# Core metrics
# --------------------------------------------------------------------------- #
def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    """The standard QSAR regression panel.

    ``R2`` is the coefficient of determination against the *test* variance
    (scikit-learn convention), not the squared Pearson correlation — the two
    differ whenever predictions are biased, and conflating them is a common way
    to overstate a model.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    ok = np.isfinite(y_true) & np.isfinite(y_pred)
    y_true, y_pred = y_true[ok], y_pred[ok]
    if len(y_true) < 3:
        return {
            k: np.nan
            for k in (
                "R2",
                "RMSE",
                "MAE",
                "Pearson_r",
                "Spearman_rho",
                "Kendall_tau",
                "MedAE",
                "max_error",
                "pct_within_0.5",
                "pct_within_1.0",
                "n",
            )
        }

    resid = y_true - y_pred
    # A constant prediction (the mean baseline) has undefined correlation rather
    # than zero correlation. Reporting NaN is correct; letting scipy warn on
    # every bootstrap resample is not.
    degenerate = np.ptp(y_pred) == 0 or np.ptp(y_true) == 0
    if degenerate:
        pearson = spearman = kendall = np.nan
    else:
        pearson = float(stats.pearsonr(y_true, y_pred)[0])
        spearman = float(stats.spearmanr(y_true, y_pred)[0])
        kendall = float(stats.kendalltau(y_true, y_pred)[0])

    return {
        "R2": float(r2_score(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "MedAE": float(np.median(np.abs(resid))),
        "Pearson_r": pearson,
        "Spearman_rho": spearman,
        "Kendall_tau": kendall,
        "max_error": float(np.max(np.abs(resid))),
        # the medicinal-chemistry-relevant numbers: how often is the call usable
        "pct_within_0.5": float((np.abs(resid) <= 0.5).mean() * 100),
        "pct_within_1.0": float((np.abs(resid) <= 1.0).mean() * 100),
        "n": int(len(y_true)),
    }


def bootstrap_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    n_resamples: int = 1000,
    ci: float = 0.95,
    seed: int = 42,
) -> pd.DataFrame:
    """Percentile-bootstrap confidence intervals for every metric.

    Resampling is over test-set compounds with replacement. This captures the
    uncertainty from *which molecules happen to be in the test set*, which on a
    few-hundred-compound set is the dominant source of variance in the reported
    number.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    rng = np.random.default_rng(seed)
    n = len(y_true)

    point = regression_metrics(y_true, y_pred)
    draws: dict[str, list[float]] = {k: [] for k in point}

    for _ in range(n_resamples):
        idx = rng.integers(0, n, size=n)
        if len(np.unique(y_true[idx])) < 2:  # degenerate resample
            continue
        m = regression_metrics(y_true[idx], y_pred[idx])
        for k, v in m.items():
            draws[k].append(v)

    alpha = (1.0 - ci) / 2.0
    rows = []
    for k, v in point.items():
        arr = np.asarray([d for d in draws[k] if np.isfinite(d)], dtype=float)
        if k == "n" or arr.size == 0:
            rows.append(
                {"metric": k, "value": v, "ci_low": np.nan, "ci_high": np.nan, "ci_width": np.nan}
            )
            continue
        lo, hi = np.quantile(arr, [alpha, 1 - alpha])
        rows.append(
            {
                "metric": k,
                "value": v,
                "ci_low": float(lo),
                "ci_high": float(hi),
                "ci_width": float(hi - lo),
            }
        )
    return pd.DataFrame(rows)


def format_ci(row: pd.Series, digits: int = 3) -> str:
    """'0.612 [0.541, 0.674]' — the only acceptable way to quote a metric here."""
    if not np.isfinite(row.get("ci_low", np.nan)):
        return f"{row['value']:.{digits}f}"
    return f"{row['value']:.{digits}f} [{row['ci_low']:.{digits}f}, {row['ci_high']:.{digits}f}]"


def metrics_table(bootstrap_df: pd.DataFrame, digits: int = 3) -> dict[str, str]:
    out = {}
    for _, r in bootstrap_df.iterrows():
        # counts are counts, not measurements — "n = 121.000" is a formatting bug
        out[r["metric"]] = f"{int(r['value'])}" if r["metric"] == "n" else format_ci(r, digits)
    return out


# --------------------------------------------------------------------------- #
# Nested cross-validation
# --------------------------------------------------------------------------- #
@dataclass
class NestedCVResult:
    model_name: str
    outer_scores: list[dict[str, float]] = field(default_factory=list)
    best_params: list[dict[str, Any]] = field(default_factory=list)
    oof_true: np.ndarray | None = None
    oof_pred: np.ndarray | None = None

    def summary(self) -> pd.DataFrame:
        df = pd.DataFrame(self.outer_scores)
        return pd.DataFrame(
            {
                "metric": df.columns,
                "mean": df.mean().values,
                "std": df.std(ddof=1).values,
                "sem": (df.std(ddof=1) / np.sqrt(len(df))).values,
            }
        )


def nested_cv(
    estimator,
    X: np.ndarray,
    y: np.ndarray,
    param_distributions: dict,
    model_name: str = "model",
    outer_folds: int = 5,
    inner_folds: int = 3,
    n_iter: int = 30,
    scoring: str = "neg_root_mean_squared_error",
    seed: int = 42,
    n_jobs: int = -1,
    groups: np.ndarray | None = None,
) -> NestedCVResult:
    """Nested CV: the inner loop tunes, the outer loop scores.

    Tuning inside the same folds you score on is the classic way to leak the
    test signal into hyperparameter choice and inflate the result by a few
    points of R². Here the inner ``RandomizedSearchCV`` never sees the outer
    fold it is evaluated on.

    If ``groups`` is supplied (e.g. scaffold labels), the outer folds are
    group-disjoint so the CV estimate matches the scaffold-split protocol.
    """
    from sklearn.model_selection import GroupKFold

    if groups is not None:
        outer = GroupKFold(n_splits=outer_folds)
        outer_iter = outer.split(X, y, groups=groups)
    else:
        outer = KFold(n_splits=outer_folds, shuffle=True, random_state=seed)
        outer_iter = outer.split(X, y)

    result = NestedCVResult(model_name=model_name)
    oof_true, oof_pred = [], []

    for fold, (tr, te) in enumerate(outer_iter):
        if param_distributions:
            search = RandomizedSearchCV(
                clone(estimator),
                param_distributions,
                n_iter=n_iter,
                cv=KFold(n_splits=inner_folds, shuffle=True, random_state=seed + fold),
                scoring=scoring,
                random_state=seed + fold,
                n_jobs=n_jobs,
                refit=True,
            )
            search.fit(X[tr], y[tr])
            best = search.best_estimator_
            result.best_params.append(search.best_params_)
        else:
            best = clone(estimator).fit(X[tr], y[tr])
            result.best_params.append({})

        pred = best.predict(X[te])
        result.outer_scores.append(regression_metrics(y[te], pred))
        oof_true.append(y[te])
        oof_pred.append(pred)
        LOGGER.info(
            "  [%s] outer fold %d/%d  RMSE=%.3f  R2=%.3f",
            model_name,
            fold + 1,
            outer_folds,
            result.outer_scores[-1]["RMSE"],
            result.outer_scores[-1]["R2"],
        )

    result.oof_true = np.concatenate(oof_true)
    result.oof_pred = np.concatenate(oof_pred)
    return result


# --------------------------------------------------------------------------- #
# Y-scrambling
# --------------------------------------------------------------------------- #
def y_scrambling(
    estimator,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    n_permutations: int = 100,
    seed: int = 42,
) -> dict[str, Any]:
    """Label-permutation test (OECD QSAR validation principle 4).

    The training labels are shuffled and the model refitted. A model that
    learns real structure–activity signal collapses to R² ≈ 0; one that is
    memorising noise or exploiting leakage keeps scoring well. The empirical
    p-value is the fraction of permuted runs that match or beat the real model.
    """
    rng = np.random.default_rng(seed)
    real = clone(estimator).fit(X_train, y_train)
    real_r2 = r2_score(y_test, real.predict(X_test))
    real_rmse = float(np.sqrt(mean_squared_error(y_test, real.predict(X_test))))

    null_r2, null_rmse = [], []
    for i in range(n_permutations):
        y_perm = rng.permutation(y_train)
        m = clone(estimator).fit(X_train, y_perm)
        p = m.predict(X_test)
        null_r2.append(r2_score(y_test, p))
        null_rmse.append(float(np.sqrt(mean_squared_error(y_test, p))))
        if (i + 1) % 25 == 0:
            LOGGER.info("  y-scrambling %d/%d", i + 1, n_permutations)

    null_r2 = np.asarray(null_r2)
    p_value = float((np.sum(null_r2 >= real_r2) + 1) / (n_permutations + 1))
    return {
        "real_r2": float(real_r2),
        "real_rmse": real_rmse,
        "null_r2": null_r2.tolist(),
        "null_rmse": null_rmse,
        "null_r2_mean": float(null_r2.mean()),
        "null_r2_std": float(null_r2.std(ddof=1)),
        "p_value": p_value,
        "n_permutations": n_permutations,
    }


# --------------------------------------------------------------------------- #
# Applicability domain
# --------------------------------------------------------------------------- #
class ApplicabilityDomain:
    """Tanimoto-similarity applicability domain.

    A QSAR model is only meaningful inside the chemical neighbourhood it was
    trained on. This computes, for each query compound, the mean Tanimoto
    similarity to its ``k`` nearest training neighbours, and defines the domain
    boundary from the training set's own distribution (5th percentile of
    leave-one-out neighbour similarity).

    The useful output is not the flag — it is the *error-versus-distance curve*,
    which shows quantitatively that predictions degrade as you leave the domain.
    That curve is what lets a project team decide whether to trust a prediction.
    """

    def __init__(self, k: int = 5):
        self.k = k

    def fit(self, train_fps):
        from .features import tanimoto_matrix

        self.train_fps_ = [f for f in train_fps if f is not None]
        sims = tanimoto_matrix(self.train_fps_, self.train_fps_)
        np.fill_diagonal(sims, -1.0)  # exclude self
        k = min(self.k, sims.shape[1] - 1)
        part = np.sort(sims, axis=1)[:, -k:]
        self.train_scores_ = part.mean(axis=1)
        self.threshold_ = float(np.percentile(self.train_scores_, 5))
        LOGGER.info(
            "AD fitted: training mean-%dNN similarity = %.3f ± %.3f, threshold = %.3f",
            k,
            self.train_scores_.mean(),
            self.train_scores_.std(),
            self.threshold_,
        )
        return self

    def score(self, query_fps) -> np.ndarray:
        """Mean Tanimoto to the k nearest training neighbours (higher = safer)."""
        from .features import tanimoto_matrix

        sims = tanimoto_matrix(query_fps, self.train_fps_)
        k = min(self.k, sims.shape[1])
        return np.sort(sims, axis=1)[:, -k:].mean(axis=1)

    def in_domain(self, query_fps) -> np.ndarray:
        return self.score(query_fps) >= self.threshold_

    def error_profile(
        self,
        query_fps,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        n_bins: int = 5,
        n_boot: int = 500,
        seed: int = 42,
    ) -> pd.DataFrame:
        """Absolute error binned by AD similarity, each bin with a bootstrap CI."""
        score = self.score(query_fps)
        err = np.abs(np.asarray(y_true) - np.asarray(y_pred))
        edges = np.quantile(score, np.linspace(0, 1, n_bins + 1))
        edges[-1] += 1e-9
        rng = np.random.default_rng(seed)

        rows = []
        for i in range(n_bins):
            m = (score >= edges[i]) & (score < edges[i + 1])
            if m.sum() < 2:
                continue
            e = err[m]
            boots = [np.sqrt(np.mean(rng.choice(e, size=len(e)) ** 2)) for _ in range(n_boot)]
            rows.append(
                {
                    "bin": i + 1,
                    "sim_low": float(edges[i]),
                    "sim_high": float(edges[i + 1]),
                    "sim_mid": float((edges[i] + edges[i + 1]) / 2),
                    "n": int(m.sum()),
                    "RMSE": float(np.sqrt(np.mean(e**2))),
                    "MAE": float(e.mean()),
                    "rmse_ci_low": float(np.percentile(boots, 2.5)),
                    "rmse_ci_high": float(np.percentile(boots, 97.5)),
                    "frac_in_domain": float((score[m] >= self.threshold_).mean()),
                }
            )
        return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# Conformal prediction (Tier E)
# --------------------------------------------------------------------------- #
def conformal_intervals(
    estimator,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    alpha: float = 0.2,
    calibration_fraction: float = 0.2,
    seed: int = 42,
) -> dict[str, Any]:
    """Split-conformal prediction intervals with a distribution-free coverage guarantee.

    Implemented directly rather than via a wrapper so the mechanism is visible:

    1. Hold out a calibration slice of the training data.
    2. Fit on the rest; compute absolute residuals on calibration ("nonconformity").
    3. The (1-alpha) quantile of those residuals, with the finite-sample
       correction ``ceil((n+1)(1-alpha))/n``, is the interval half-width.

    The guarantee is marginal coverage ≥ 1-alpha under exchangeability. Under a
    *scaffold* split exchangeability is deliberately violated — that is the
    point of the split — so empirical coverage is expected to fall short of
    nominal, and reporting that shortfall honestly is more informative than
    reporting a guarantee that does not hold.
    """
    rng = np.random.default_rng(seed)
    n = len(X_train)
    perm = rng.permutation(n)
    n_cal = max(int(round(calibration_fraction * n)), 20)
    cal_idx, fit_idx = perm[:n_cal], perm[n_cal:]

    model = clone(estimator).fit(X_train[fit_idx], y_train[fit_idx])
    cal_resid = np.abs(y_train[cal_idx] - model.predict(X_train[cal_idx]))

    m = len(cal_resid)
    level = min(np.ceil((m + 1) * (1 - alpha)) / m, 1.0)
    qhat = float(np.quantile(cal_resid, level, method="higher"))

    pred = model.predict(X_test)
    return {
        "model": model,
        "prediction": pred,
        "lower": pred - qhat,
        "upper": pred + qhat,
        "half_width": qhat,
        "alpha": alpha,
        "n_calibration": m,
    }


def coverage_curve(
    estimator,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    alphas: np.ndarray | None = None,
    calibration_fraction: float = 0.2,
    seed: int = 42,
) -> pd.DataFrame:
    """Nominal vs empirical coverage — the calibration plot for prediction intervals."""
    if alphas is None:
        alphas = np.linspace(0.05, 0.5, 10)
    rows = []
    for a in alphas:
        res = conformal_intervals(
            estimator,
            X_train,
            y_train,
            X_test,
            alpha=float(a),
            calibration_fraction=calibration_fraction,
            seed=seed,
        )
        covered = (y_test >= res["lower"]) & (y_test <= res["upper"])
        rows.append(
            {
                "alpha": float(a),
                "nominal_coverage": 1 - float(a),
                "empirical_coverage": float(covered.mean()),
                "mean_interval_width": float(2 * res["half_width"]),
            }
        )
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# Learning curve and repeated splits
# --------------------------------------------------------------------------- #
def learning_curve(
    estimator,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
    fractions: list[float],
    n_repeats: int = 5,
    seed: int = 42,
) -> pd.DataFrame:
    """RMSE/R² as a function of training-set size, with across-repeat CIs.

    Answers the question every project team asks: would more data help, or has
    this endpoint saturated?
    """
    rng = np.random.default_rng(seed)
    rows = []
    for frac in fractions:
        n_sub = max(int(round(frac * len(X_train))), 20)
        for rep in range(n_repeats):
            idx = rng.choice(len(X_train), size=n_sub, replace=False)
            m = clone(estimator).fit(X_train[idx], y_train[idx])
            met = regression_metrics(y_test, m.predict(X_test))
            rows.append({"fraction": frac, "n_train": n_sub, "repeat": rep, **met})
    df = pd.DataFrame(rows)
    agg = (
        df.groupby(["fraction", "n_train"])[["RMSE", "R2", "MAE", "Spearman_rho"]]
        .agg(["mean", "std"])
        .reset_index()
    )
    agg.columns = ["_".join(c).rstrip("_") for c in agg.columns]
    return agg


def repeated_split_eval(
    estimator,
    df: pd.DataFrame,
    featurize: Callable[[pd.DataFrame], np.ndarray],
    split_fn: Callable[[pd.DataFrame, int], dict[str, np.ndarray]],
    n_seeds: int = 10,
    base_seed: int = 42,
) -> pd.DataFrame:
    """Repeat the whole split-fit-score cycle under different seeds.

    A single split's score is a random variable. Reporting one number from one
    split — which is what the legacy notebook did — hides a standard deviation
    that is often larger than the difference between two models being compared.
    """
    rows = []
    for i in range(n_seeds):
        seed = base_seed + i
        idx = split_fn(df, seed)
        X = featurize(df)
        y = df["pIC50"].to_numpy(dtype=float)
        m = clone(estimator).fit(X[idx["train"]], y[idx["train"]])
        met = regression_metrics(y[idx["test"]], m.predict(X[idx["test"]]))
        rows.append({"seed": seed, **met})
        LOGGER.info("  repeat seed=%d  RMSE=%.3f  R2=%.3f", seed, met["RMSE"], met["R2"])
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# Comparison helper
# --------------------------------------------------------------------------- #
def compare_models(results: dict[str, pd.DataFrame], metric: str = "RMSE") -> pd.DataFrame:
    """Assemble the model-comparison table used by the forest plot.

    Models are ordered by the point estimate, but the column that matters is
    the interval: two models whose intervals overlap have not been shown to
    differ on this dataset, whatever the ranking suggests.
    """
    rows = []
    for name, boot in results.items():
        r = boot.loc[boot["metric"] == metric]
        if r.empty:
            continue
        r = r.iloc[0]
        rows.append(
            {
                "model": name,
                "metric": metric,
                "value": r["value"],
                "ci_low": r["ci_low"],
                "ci_high": r["ci_high"],
            }
        )
    out = pd.DataFrame(rows)
    ascending = metric in ("RMSE", "MAE", "MedAE", "max_error")
    return out.sort_values("value", ascending=ascending).reset_index(drop=True)
