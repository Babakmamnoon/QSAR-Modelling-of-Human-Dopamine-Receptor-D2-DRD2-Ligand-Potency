"""Live ChEMBL ingestion with a provenance manifest.

This module replaces the old ``wget`` of a pre-baked CSV. The dataset is now
*derived*, not *supplied*: the exact query is expressed in code, executed against
the ChEMBL web services, and written to disk next to a manifest recording the
ChEMBL release, the pull date, the query parameters and the row count. That
manifest is what makes the headline numbers auditable.

Design notes
------------
* Only ``standard_relation == '='`` rows are requested. Censored measurements
  (``>10000``) are real information but they are *not* regression targets, and
  silently treating ``>`` as ``=`` is one of the commonest ways a public-data
  QSAR model is quietly corrupted.
* ChEMBL's own ``data_validity_comment`` flags are honoured server-side where
  possible and re-checked client-side. These flags are exactly what catch the
  unit-mishandled records (dopamine at "pIC50 14") that poisoned the legacy CSV.
* ``assay_type='B'`` restricts to binding assays, so functional and ADMET
  readouts do not get pooled into one target column.
* The raw pull is cached. Re-running the pipeline must not re-query ChEMBL
  blindly, both out of courtesy to the EBI and so results stay reproducible
  after ChEMBL ships a new release.

Offline use
-----------
If the ChEMBL services are unreachable (locked-down CI, air-gapped machine),
``fetch_activities`` raises :class:`ChEMBLUnavailable`. ``load_or_fetch`` then
falls back to the cached raw pull if one exists, and records in the manifest
that the data came from cache rather than a live query.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

LOGGER = logging.getLogger("drd2_qsar.chembl")

# Columns requested from the activity endpoint.
ACTIVITY_FIELDS = [
    "molecule_chembl_id",
    "canonical_smiles",
    "standard_type",
    "standard_relation",
    "standard_value",
    "standard_units",
    "pchembl_value",
    "assay_chembl_id",
    "assay_type",
    "assay_description",
    "target_chembl_id",
    "target_organism",
    "document_chembl_id",
    "document_year",
    "data_validity_comment",
    "activity_comment",
    "potential_duplicate",
]


class ChEMBLUnavailable(RuntimeError):
    """Raised when the ChEMBL web services cannot be reached."""


@dataclass
class PullManifest:
    """Everything needed to explain where a dataset came from."""

    target_chembl_id: str
    standard_types: list[str]
    assay_type: str | None
    standard_relation: str
    standard_units: str
    target_organism: str | None
    pulled_at_utc: str
    chembl_release: str
    source: str  # "live" | "cache" | "legacy_snapshot"
    n_rows_raw: int
    query: dict[str, Any]

    def write(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2))
        LOGGER.info("Wrote pull manifest -> %s", path)


# --------------------------------------------------------------------------- #
# Live query
# --------------------------------------------------------------------------- #
def _chembl_release() -> str:
    """Ask ChEMBL which release is being served, so results are versioned."""
    try:
        from chembl_webresource_client.new_client import new_client

        status = new_client.status.all()  # type: ignore[attr-defined]
        rec = status[0] if isinstance(status, list) else status
        return str(rec.get("chembl_db_version", "unknown"))
    except Exception:  # pragma: no cover - network dependent
        return "unknown"


def fetch_activities(cfg_chembl: dict[str, Any]) -> tuple[pd.DataFrame, PullManifest]:
    """Query ChEMBL for the target's binding activities.

    Returns the raw (uncurated) activity table plus its provenance manifest.
    """
    try:
        from chembl_webresource_client.new_client import new_client
    except Exception as exc:  # pragma: no cover
        raise ChEMBLUnavailable(f"chembl_webresource_client unavailable: {exc}") from exc

    target = cfg_chembl["target_chembl_id"]
    types = list(cfg_chembl.get("standard_types", ["IC50"]))
    if not cfg_chembl.get("pool_endpoints", False):
        types = types[:1]

    query: dict[str, Any] = {
        "target_chembl_id": target,
        "standard_type__in": types,
        "standard_relation": cfg_chembl.get("standard_relation", "="),
        "standard_units": cfg_chembl.get("standard_units", "nM"),
    }
    if cfg_chembl.get("assay_type"):
        query["assay_type"] = cfg_chembl["assay_type"]
    if cfg_chembl.get("target_organism"):
        query["target_organism"] = cfg_chembl["target_organism"]

    LOGGER.info("Querying ChEMBL activities: %s", query)
    try:
        qs = new_client.activity.filter(**query).only(ACTIVITY_FIELDS)  # type: ignore[attr-defined]
        records = list(qs)
    except Exception as exc:  # pragma: no cover - network dependent
        raise ChEMBLUnavailable(f"ChEMBL query failed: {exc}") from exc

    df = pd.DataFrame.from_records(records)
    LOGGER.info("ChEMBL returned %d raw activity rows", len(df))

    manifest = PullManifest(
        target_chembl_id=target,
        standard_types=types,
        assay_type=cfg_chembl.get("assay_type"),
        standard_relation=cfg_chembl.get("standard_relation", "="),
        standard_units=cfg_chembl.get("standard_units", "nM"),
        target_organism=cfg_chembl.get("target_organism"),
        pulled_at_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        chembl_release=_chembl_release(),
        source="live",
        n_rows_raw=len(df),
        query=query,
    )
    return df, manifest


# --------------------------------------------------------------------------- #
# Caching / fallback
# --------------------------------------------------------------------------- #
def load_or_fetch(
    cfg_chembl: dict[str, Any],
    raw_dir: Path,
    force_refresh: bool = False,
    allow_legacy_snapshot: bool = True,
) -> tuple[pd.DataFrame, PullManifest]:
    """Return the raw activity table, preferring a live pull, falling back to cache.

    Resolution order
    ----------------
    1. ``force_refresh`` -> always re-query ChEMBL.
    2. A cached parquet from a previous live pull.
    3. A live query.
    4. The legacy pre-curated CSV snapshot (clearly marked in the manifest), so
       the pipeline is still runnable on a machine with no ChEMBL access.
    """
    raw_dir = Path(raw_dir)
    cache_path = raw_dir / f"{cfg_chembl['target_chembl_id']}_activities_raw.parquet"
    manifest_path = raw_dir / f"{cfg_chembl['target_chembl_id']}_pull_manifest.json"

    if cache_path.exists() and not force_refresh:
        df = pd.read_parquet(cache_path)
        if manifest_path.exists():
            man = PullManifest(**json.loads(manifest_path.read_text()))
            man.source = "cache"
        else:  # cache without manifest -- reconstruct a minimal one
            man = PullManifest(
                target_chembl_id=cfg_chembl["target_chembl_id"],
                standard_types=list(cfg_chembl.get("standard_types", ["IC50"])),
                assay_type=cfg_chembl.get("assay_type"),
                standard_relation=cfg_chembl.get("standard_relation", "="),
                standard_units=cfg_chembl.get("standard_units", "nM"),
                target_organism=cfg_chembl.get("target_organism"),
                pulled_at_utc="unknown",
                chembl_release="unknown",
                source="cache",
                n_rows_raw=len(df),
                query={},
            )
        LOGGER.info("Loaded cached raw pull (%d rows) from %s", len(df), cache_path)
        return df, man

    try:
        df, man = fetch_activities(cfg_chembl)
        if cfg_chembl.get("cache_raw", True):
            raw_dir.mkdir(parents=True, exist_ok=True)
            df.to_parquet(cache_path, index=False)
            man.write(manifest_path)
        return df, man
    except ChEMBLUnavailable as exc:
        LOGGER.warning("Live ChEMBL pull unavailable: %s", exc)
        export = _find_chembl_export(raw_dir)
        if export is not None:
            return read_chembl_export(export, cfg_chembl)
        if not allow_legacy_snapshot:
            raise
        return _load_legacy_snapshot(raw_dir, cfg_chembl)


# --------------------------------------------------------------------------- #
# ChEMBL web-interface export
# --------------------------------------------------------------------------- #
# Column names as the ChEMBL web UI writes them -> the canonical schema this
# pipeline uses internally (which matches the REST API's field names).
EXPORT_COLUMN_MAP = {
    "Molecule ChEMBL ID": "molecule_chembl_id",
    "Smiles": "canonical_smiles",
    "Standard Type": "standard_type",
    "Standard Relation": "standard_relation",
    "Standard Value": "standard_value",
    "Standard Units": "standard_units",
    "pChEMBL Value": "pchembl_value",
    "Data Validity Comment": "data_validity_comment",
    "Comment": "activity_comment",
    "Potential Duplicate": "potential_duplicate",
    "Assay ChEMBL ID": "assay_chembl_id",
    "Assay Description": "assay_description",
    "Assay Type": "assay_type",
    "Target ChEMBL ID": "target_chembl_id",
    "Target Organism": "target_organism",
    "Document ChEMBL ID": "document_chembl_id",
    "Document Year": "document_year",
    "Action Type": "action_type",
}


def _find_chembl_export(raw_dir: Path) -> Path | None:
    """Look for a ChEMBL web-export CSV in the raw data directory.

    A web export is recognised by its header, not its filename: the ChEMBL UI
    writes semicolon-separated, quoted columns with names like
    ``"Molecule ChEMBL ID"``. That signature is unambiguous, so a file is only
    treated as an export if it actually carries it.
    """
    for candidate in sorted(Path(raw_dir).glob("*.csv")):
        try:
            head = candidate.open(encoding="utf-8", errors="replace").readline()
        except OSError:
            continue
        if "Molecule ChEMBL ID" in head and "Standard Value" in head:
            LOGGER.info("Found ChEMBL web export: %s", candidate)
            return candidate
    return None


def read_chembl_export(path: Path, cfg_chembl: dict[str, Any]) -> tuple[pd.DataFrame, PullManifest]:
    """Read a CSV exported from the ChEMBL web interface into the canonical schema.

    This is a genuine raw activity table — the same rows the REST API returns,
    just downloaded through the browser — so it is a first-class data source
    rather than a degraded fallback. Every curation stage applies to it
    unchanged: censored measurements, non-binding assays, validity-flagged rows
    and implausible potencies are all still present and still get removed, with
    the reasons recorded.

    Two format quirks are normalised here:

    * the export is **semicolon**-separated, not comma-separated;
    * ``Standard Relation`` values arrive wrapped in literal single quotes
      (``'='``, ``'>'``), which would otherwise never match the ``'='`` filter
      and would silently drop the entire dataset.
    """
    path = Path(path)
    sep = ";" if ";" in path.open(encoding="utf-8", errors="replace").readline() else ","
    raw = pd.read_csv(path, sep=sep, low_memory=False)
    n_in = len(raw)

    df = pd.DataFrame(index=raw.index)
    for src, dst in EXPORT_COLUMN_MAP.items():
        df[dst] = raw[src] if src in raw.columns else pd.NA

    # The UI wraps relations in literal quotes: "'='" -> "="
    df["standard_relation"] = df["standard_relation"].astype("string").str.strip().str.strip("'\"")
    for col in ("standard_type", "standard_units", "assay_type", "action_type"):
        df[col] = df[col].astype("string").str.strip().str.strip("'\"")
    df["standard_value"] = pd.to_numeric(df["standard_value"], errors="coerce")

    # Honour the configured endpoint/target scope, so a broad export does not
    # quietly widen the modelling question.
    types = {t.upper() for t in cfg_chembl.get("standard_types", ["IC50"])}
    keep = df["standard_type"].astype("string").str.upper().isin(types)
    target = cfg_chembl.get("target_chembl_id")
    if target and df["target_chembl_id"].notna().any():
        keep &= df["target_chembl_id"].astype("string").str.upper() == str(target).upper()
    df = df.loc[keep].reset_index(drop=True)

    LOGGER.info(
        "Read ChEMBL web export: %d rows -> %d after endpoint/target scoping " "(relations: %s)",
        n_in,
        len(df),
        df["standard_relation"].value_counts(dropna=False).head(4).to_dict(),
    )

    man = PullManifest(
        target_chembl_id=str(target),
        standard_types=sorted(types),
        assay_type=cfg_chembl.get("assay_type"),
        standard_relation=cfg_chembl.get("standard_relation", "="),
        standard_units=cfg_chembl.get("standard_units", "nM"),
        target_organism=cfg_chembl.get("target_organism"),
        pulled_at_utc=datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat(
            timespec="seconds"
        ),
        chembl_release="unknown (web-interface export)",
        source="chembl_web_export",
        n_rows_raw=len(df),
        query={
            "file": path.name,
            "note": "raw activity export downloaded from the ChEMBL web interface; "
            "identical in content to the REST query, so all curation applies",
        },
    )
    return df, man


def _load_legacy_snapshot(
    raw_dir: Path, cfg_chembl: dict[str, Any]
) -> tuple[pd.DataFrame, PullManifest]:
    """Last-resort fallback: the pre-curated CSV shipped with the legacy repo.

    This snapshot is *already* filtered to IC50 < 1000 nM and carries the unit
    errors this pipeline is designed to catch. It is adapted into raw-activity
    shape so the curation stages still exercise on it, but the manifest records
    ``source='legacy_snapshot'`` and downstream reports flag the provenance
    loudly. This path exists so the pipeline is runnable offline -- it is not
    the path the published numbers should come from.
    """
    snapshot = raw_dir / "DRD2_legacy_snapshot.csv"
    if not snapshot.exists():
        raise ChEMBLUnavailable(
            "No ChEMBL access, no cached pull, and no legacy snapshot at "
            f"{snapshot}. Run on a machine that can reach www.ebi.ac.uk, or "
            "place a cached parquet in data/raw/."
        )
    legacy = pd.read_csv(snapshot)
    LOGGER.warning(
        "FALLBACK: using legacy pre-curated snapshot (%d rows). "
        "Headline metrics should be regenerated from a live ChEMBL pull.",
        len(legacy),
    )
    # pIC50 -> nM so the standard curation path applies unchanged.
    df = pd.DataFrame(
        {
            "molecule_chembl_id": legacy["Name"],
            "canonical_smiles": legacy["SMILES"],
            "standard_type": "IC50",
            "standard_relation": "=",
            "standard_value": np.power(10.0, 9.0 - legacy["pIC50"].astype(float)),
            "standard_units": "nM",
            "pchembl_value": legacy["pIC50"].astype(float),
            "assay_chembl_id": pd.NA,
            "assay_type": "B",
            "assay_description": pd.NA,
            "target_chembl_id": cfg_chembl["target_chembl_id"],
            "target_organism": "Homo sapiens",
            "document_chembl_id": pd.NA,
            "document_year": pd.NA,
            "data_validity_comment": pd.NA,
            "activity_comment": pd.NA,
            "potential_duplicate": 0,
        }
    )
    man = PullManifest(
        target_chembl_id=cfg_chembl["target_chembl_id"],
        standard_types=["IC50"],
        assay_type="B",
        standard_relation="=",
        standard_units="nM",
        target_organism="Homo sapiens",
        pulled_at_utc="n/a (legacy snapshot)",
        chembl_release="unknown (pre-curated snapshot)",
        source="legacy_snapshot",
        n_rows_raw=len(df),
        query={"note": "offline fallback, not a live ChEMBL query"},
    )
    return df, man


def fetch_action_types(molecule_ids: list[str]) -> pd.DataFrame:
    """Look up mechanism annotations so agonists can be separated from antagonists.

    ChEMBL's ``mechanism`` endpoint only covers compounds with a curated
    mechanism of action -- typically drugs and well-studied tools -- so most
    screening compounds come back unannotated. That is expected; the point is
    that the ones that *are* annotated (dopamine, apomorphine, quinpirole)
    can be pulled out of an "inhibitor" model where they do not belong.
    """
    try:
        from chembl_webresource_client.new_client import new_client
    except Exception as exc:  # pragma: no cover
        raise ChEMBLUnavailable(str(exc)) from exc

    rows: list[dict[str, Any]] = []
    chunk = 200
    for i in range(0, len(molecule_ids), chunk):
        batch = molecule_ids[i : i + chunk]
        try:
            recs = new_client.mechanism.filter(  # type: ignore[attr-defined]
                molecule_chembl_id__in=batch
            ).only(["molecule_chembl_id", "action_type", "mechanism_of_action"])
            rows.extend(list(recs))
        except Exception as exc:  # pragma: no cover
            LOGGER.warning("mechanism lookup failed for batch %d: %s", i // chunk, exc)
    if not rows:
        return pd.DataFrame(columns=["molecule_chembl_id", "action_type", "mechanism_of_action"])
    out = pd.DataFrame.from_records(rows).drop_duplicates("molecule_chembl_id")
    LOGGER.info("Recovered action_type for %d compounds", len(out))
    return out
