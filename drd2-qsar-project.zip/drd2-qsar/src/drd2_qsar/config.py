"""Configuration loading and global seed control.

The whole pipeline is driven by ``configs/drd2.yaml``. Nothing in the codebase
hard-codes a hyperparameter, a threshold, or a path; if you want to change the
experiment you change the YAML, and the YAML is written into every result
artifact so any number can be traced back to the settings that produced it.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import yaml

LOGGER = logging.getLogger("drd2_qsar")


# --------------------------------------------------------------------------- #
# Config container
# --------------------------------------------------------------------------- #
@dataclass
class Config:
    """Dot-and-bracket accessible view over the YAML configuration."""

    raw: dict[str, Any] = field(default_factory=dict)
    path: Path | None = None

    # -- access ------------------------------------------------------------- #
    def __getitem__(self, key: str) -> Any:
        return self.raw[key]

    def get(self, dotted: str, default: Any = None) -> Any:
        """Fetch a nested value with a dotted path, e.g. ``cfg.get("split.strategy")``."""
        node: Any = self.raw
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    # -- derived paths ------------------------------------------------------ #
    @property
    def seed(self) -> int:
        return int(self.get("project.seed", 42))

    @property
    def data_dir(self) -> Path:
        return Path(self.get("project.data_dir", "data"))

    @property
    def output_dir(self) -> Path:
        return Path(self.get("project.output_dir", "reports"))

    @property
    def figure_dir(self) -> Path:
        return Path(self.get("project.figure_dir", "reports/figures"))

    @property
    def model_dir(self) -> Path:
        return Path(self.get("project.model_dir", "models"))

    def ensure_dirs(self) -> None:
        for p in (
            self.data_dir / "raw",
            self.data_dir / "interim",
            self.data_dir / "processed",
            self.output_dir,
            self.figure_dir,
            self.model_dir,
        ):
            p.mkdir(parents=True, exist_ok=True)

    # -- provenance --------------------------------------------------------- #
    def fingerprint(self) -> str:
        """Stable hash of the configuration, stamped into every result file."""
        blob = json.dumps(self.raw, sort_keys=True, default=str).encode()
        return hashlib.sha256(blob).hexdigest()[:12]

    def to_dict(self) -> dict[str, Any]:
        return json.loads(json.dumps(self.raw, default=str))


def load_config(path: str | Path) -> Config:
    path = Path(path)
    with path.open() as fh:
        raw = yaml.safe_load(fh)
    return Config(raw=raw, path=path)


# --------------------------------------------------------------------------- #
# Reproducibility
# --------------------------------------------------------------------------- #
def set_global_seed(seed: int) -> None:
    """Seed every RNG the pipeline can reach, and say so in the log.

    Deterministic behaviour is part of the deliverable: the same config plus the
    same cached raw pull must produce byte-identical metrics.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:  # optional, only if torch is installed alongside
        import torch

        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass
    LOGGER.info("Global seed set to %d", seed)


def git_revision() -> str:
    """Best-effort git SHA for the provenance manifest."""
    try:
        return (
            subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"], stderr=subprocess.DEVNULL
            )
            .decode()
            .strip()
        )
    except Exception:
        return "unknown"


def environment_manifest() -> dict[str, str]:
    """Versions of everything that can change a number, for the results header."""
    import platform

    versions: dict[str, str] = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "git_revision": git_revision(),
    }
    for mod in ("rdkit", "numpy", "pandas", "sklearn", "xgboost", "scipy"):
        try:
            m = __import__(mod)
            versions[mod] = getattr(m, "__version__", "unknown")
        except ImportError:
            versions[mod] = "not installed"
    return versions


def setup_logging(level: int = logging.INFO) -> logging.Logger:
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    return LOGGER
