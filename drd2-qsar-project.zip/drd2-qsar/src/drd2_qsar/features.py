"""Molecular featurizer zoo.

Every featurizer exposes the same ``transform(smiles) -> np.ndarray`` contract so
the descriptor ablation (Tier E) is a loop rather than six near-duplicate
scripts. Fingerprints are generated with RDKit's modern
``rdFingerprintGenerator`` API (the older ``GetMorganFingerprintAsBitVect``
helpers are deprecated).

Why these six
-------------
* **ECFP4 / ECFP6** — the circular-fingerprint workhorses; ECFP4 (radius 2) is
  the default for ligand-based potency models.
* **FCFP4** — the feature-class variant; abstracts atom identity to
  pharmacophoric roles, so it generalises across scaffolds better than ECFP
  while losing some specificity.
* **MACCS** — 166 hand-designed keys; a deliberately weak, low-dimensional
  control. If a 2048-bit fingerprint cannot beat MACCS, the extra dimensions
  are not buying anything.
* **RDKit descriptors** — ~200 interpretable physicochemical descriptors;
  tests whether potency here is driven by bulk properties rather than
  specific substructure.
* **ECFP4 + descriptors** — the usual production combination.
"""

from __future__ import annotations

import logging
from typing import Protocol

import numpy as np
import pandas as pd
from rdkit import Chem, DataStructs
from rdkit.Chem import Descriptors, MACCSkeys, rdFingerprintGenerator

LOGGER = logging.getLogger("drd2_qsar.features")


class Featurizer(Protocol):
    name: str
    is_binary: bool

    def transform(self, smiles: list[str]) -> np.ndarray: ...


# --------------------------------------------------------------------------- #
# Fingerprints
# --------------------------------------------------------------------------- #
class MorganFingerprint:
    """ECFP/FCFP circular fingerprints."""

    def __init__(
        self,
        radius: int = 2,
        n_bits: int = 2048,
        features: bool = False,
        counts: bool = False,
        name: str | None = None,
    ):
        self.radius = radius
        self.n_bits = n_bits
        self.features = features
        self.counts = counts
        self.is_binary = not counts
        self.name = name or f"{'fcfp' if features else 'ecfp'}{radius * 2}"
        invgen = rdFingerprintGenerator.GetMorganFeatureAtomInvGen() if features else None
        self._gen = rdFingerprintGenerator.GetMorganGenerator(
            radius=radius, fpSize=n_bits, atomInvariantsGenerator=invgen
        )

    def _one(self, smi: str) -> np.ndarray:
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            return np.zeros(self.n_bits, dtype=np.float32)
        fp = (
            self._gen.GetCountFingerprintAsNumPy(mol)
            if self.counts
            else self._gen.GetFingerprintAsNumPy(mol)
        )
        return np.asarray(fp, dtype=np.float32)

    def transform(self, smiles: list[str]) -> np.ndarray:
        return np.vstack([self._one(s) for s in smiles])

    def bit_info(self, smi: str) -> dict:
        """Map set bits back to the atom environments that set them (for SHAP)."""
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            return {}
        ao = rdFingerprintGenerator.AdditionalOutput()
        ao.AllocateBitInfoMap()
        self._gen.GetFingerprint(mol, additionalOutput=ao)
        return ao.GetBitInfoMap()


class MACCSFingerprint:
    name = "maccs"
    is_binary = True
    n_bits = 167

    def transform(self, smiles: list[str]) -> np.ndarray:
        out = np.zeros((len(smiles), self.n_bits), dtype=np.float32)
        for i, smi in enumerate(smiles):
            mol = Chem.MolFromSmiles(smi)
            if mol is None:
                continue
            arr = np.zeros((self.n_bits,), dtype=np.int8)
            DataStructs.ConvertToNumpyArray(MACCSkeys.GenMACCSKeys(mol), arr)
            out[i] = arr
        return out


# --------------------------------------------------------------------------- #
# Descriptors
# --------------------------------------------------------------------------- #
class RDKitDescriptors:
    """All RDKit 2D descriptors, NaN/inf-cleaned and variance-filtered downstream."""

    name = "rdkit_descriptors"
    is_binary = False

    def __init__(self) -> None:
        self._names = [n for n, _ in Descriptors.descList]
        self._funcs = [f for _, f in Descriptors.descList]
        self.n_bits = len(self._names)

    @property
    def feature_names(self) -> list[str]:
        return list(self._names)

    def transform(self, smiles: list[str]) -> np.ndarray:
        out = np.full((len(smiles), self.n_bits), np.nan, dtype=np.float64)
        for i, smi in enumerate(smiles):
            mol = Chem.MolFromSmiles(smi)
            if mol is None:
                continue
            for j, fn in enumerate(self._funcs):
                try:
                    out[i, j] = fn(mol)
                except Exception:
                    out[i, j] = np.nan
        out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)
        return out.astype(np.float32)


class ConcatFeaturizer:
    """Horizontal concatenation of several featurizers (e.g. ECFP4 + descriptors)."""

    def __init__(self, parts: list, name: str):
        self.parts = parts
        self.name = name
        self.is_binary = False
        self.n_bits = sum(getattr(p, "n_bits", 0) for p in parts)

    def transform(self, smiles: list[str]) -> np.ndarray:
        return np.hstack([p.transform(smiles) for p in self.parts])


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #
def get_featurizer(name: str, n_bits: int = 2048, counts: bool = False):
    name = name.lower()
    if name == "ecfp4":
        return MorganFingerprint(radius=2, n_bits=n_bits, counts=counts, name="ecfp4")
    if name == "ecfp6":
        return MorganFingerprint(radius=3, n_bits=n_bits, counts=counts, name="ecfp6")
    if name == "fcfp4":
        return MorganFingerprint(
            radius=2, n_bits=n_bits, features=True, counts=counts, name="fcfp4"
        )
    if name == "fcfp6":
        return MorganFingerprint(
            radius=3, n_bits=n_bits, features=True, counts=counts, name="fcfp6"
        )
    if name == "maccs":
        return MACCSFingerprint()
    if name in ("rdkit_descriptors", "descriptors"):
        return RDKitDescriptors()
    if name == "ecfp4_plus_descriptors":
        return ConcatFeaturizer(
            [
                MorganFingerprint(radius=2, n_bits=n_bits, counts=counts, name="ecfp4"),
                RDKitDescriptors(),
            ],
            name="ecfp4_plus_descriptors",
        )
    raise ValueError(f"Unknown featurizer: {name!r}")


def featurize_frame(df: pd.DataFrame, featurizer, smiles_col: str = "smiles") -> np.ndarray:
    LOGGER.info("Featurizing %d molecules with %s", len(df), featurizer.name)
    X = featurizer.transform(df[smiles_col].tolist())
    LOGGER.info("Feature matrix: %s (density %.3f)", X.shape, float((X != 0).mean()))
    return X


# --------------------------------------------------------------------------- #
# Similarity helpers (used by AD, k-NN baseline, activity cliffs)
# --------------------------------------------------------------------------- #
def rdkit_fps(smiles: list[str], radius: int = 2, n_bits: int = 2048):
    """Native RDKit bit vectors — needed for fast BulkTanimotoSimilarity."""
    gen = rdFingerprintGenerator.GetMorganGenerator(radius=radius, fpSize=n_bits)
    out = []
    for smi in smiles:
        mol = Chem.MolFromSmiles(smi)
        out.append(gen.GetFingerprint(mol) if mol is not None else None)
    return out


def tanimoto_matrix(query_fps, ref_fps) -> np.ndarray:
    """Dense Tanimoto similarity matrix, shape (len(query), len(ref))."""
    ref_valid = [f for f in ref_fps if f is not None]
    sims = np.zeros((len(query_fps), len(ref_valid)), dtype=np.float32)
    for i, q in enumerate(query_fps):
        if q is None:
            continue
        sims[i] = np.asarray(DataStructs.BulkTanimotoSimilarity(q, ref_valid), dtype=np.float32)
    return sims
