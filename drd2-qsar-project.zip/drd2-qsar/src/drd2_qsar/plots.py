"""The publication figure suite.

One style module, one palette, one export path. Every figure in the report is
produced here so the whole set reads as a single system rather than as a dozen
matplotlib defaults accumulated over a weekend.

Design rules applied throughout
-------------------------------
* Colours are assigned by the *job* they do — categorical hues for identity
  (train/val/test), a single-hue sequential ramp for magnitude (AD similarity,
  density), a two-hue diverging pair for polarity (signed residuals). Never a
  rainbow, never a hue at a diverging midpoint.
* The categorical order is fixed and validated for colour-vision deficiency
  (worst all-pairs CVD ΔE 9.2, normal-vision ΔE 24.0 across the three slots in
  use). Identity is never carried by colour alone: every multi-series panel
  also carries a legend, and most carry direct labels.
* Marks are thin, grids are recessive, and axes never start at a misleading
  baseline.
* Figures export to PNG (300 dpi) and SVG so they are usable in both a README
  and a slide.
"""

from __future__ import annotations

import logging
from pathlib import Path

import matplotlib as mpl
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

LOGGER = logging.getLogger("drd2_qsar.plots")

# --------------------------------------------------------------------------- #
# Design tokens
# --------------------------------------------------------------------------- #
SURFACE = "#fcfcfb"
INK_PRIMARY = "#0b0b0b"
INK_SECONDARY = "#52514e"
INK_MUTED = "#8a8985"
GRID = "#e6e5e1"

# Validated categorical order (identity encoding)
SERIES = {
    "train": "#2a78d6",  # blue
    "val": "#eb6834",  # orange
    "test": "#1baf7a",  # aqua
    "extra": "#eda100",  # yellow
    "accent": "#4a3aa7",  # violet
    "bad": "#e34948",  # red (status only)
}
CATEGORICAL = [
    "#2a78d6",
    "#eb6834",
    "#1baf7a",
    "#eda100",
    "#e87ba4",
    "#008300",
    "#4a3aa7",
    "#e34948",
]

# Sequential blue ramp (magnitude encoding)
SEQ_BLUE = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
CMAP_SEQ = LinearSegmentedColormap.from_list("drd2_seq", SEQ_BLUE)
# Diverging blue<->red with a neutral gray midpoint (polarity encoding)
CMAP_DIV = LinearSegmentedColormap.from_list(
    "drd2_div", ["#184f95", "#6da7ec", "#f0efec", "#ef8a89", "#b3211f"]
)


def set_style(dpi: int = 300) -> None:
    """Apply the project style to every subsequent matplotlib figure."""
    mpl.rcParams.update(
        {
            "figure.dpi": 110,
            "savefig.dpi": dpi,
            "figure.facecolor": SURFACE,
            "axes.facecolor": SURFACE,
            "savefig.facecolor": SURFACE,
            "savefig.bbox": "tight",
            "font.family": "sans-serif",
            "font.sans-serif": ["DejaVu Sans", "Helvetica", "Arial"],
            "font.size": 9,
            "axes.titlesize": 11,
            "axes.titleweight": "semibold",
            "axes.titlelocation": "left",
            "axes.titlepad": 10,
            "axes.labelsize": 9,
            "axes.labelcolor": INK_SECONDARY,
            "axes.edgecolor": GRID,
            "axes.linewidth": 0.8,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": True,
            "axes.axisbelow": True,
            "grid.color": GRID,
            "grid.linewidth": 0.6,
            "grid.alpha": 1.0,
            "xtick.color": INK_MUTED,
            "ytick.color": INK_MUTED,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "legend.frameon": False,
            "legend.fontsize": 8,
            "lines.linewidth": 2.0,
            "lines.markersize": 5,
            "text.color": INK_PRIMARY,
        }
    )


def save(fig: plt.Figure, name: str, out_dir: Path, formats=("png", "svg")) -> list[Path]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for fmt in formats:
        p = out_dir / f"{name}.{fmt}"
        fig.savefig(p, format=fmt)
        paths.append(p)
    plt.close(fig)
    LOGGER.info("Figure -> %s", paths[0])
    return paths


def _panel_label(ax, letter: str) -> None:
    ax.text(
        -0.12,
        1.08,
        letter,
        transform=ax.transAxes,
        fontsize=11,
        fontweight="bold",
        color=INK_PRIMARY,
        va="top",
        ha="left",
    )


# =========================================================================== #
# 15. Data characterisation panel
# =========================================================================== #
def plot_data_overview(
    df: pd.DataFrame, props: pd.DataFrame, out_dir: Path, formats=("png", "svg")
) -> list[Path]:
    """Potency distribution plus the physicochemical property panel."""
    fig, axes = plt.subplots(3, 3, figsize=(12, 9.5))
    axes = axes.ravel()

    # A -- potency distribution
    ax = axes[0]
    ax.hist(df["pIC50"], bins=30, color=SERIES["train"], edgecolor=SURFACE, linewidth=0.5)
    ax.axvline(df["pIC50"].median(), color=SERIES["bad"], linestyle="--", linewidth=1.5)
    ax.annotate(
        f"median {df['pIC50'].median():.2f}",
        xy=(df["pIC50"].median(), ax.get_ylim()[1] * 0.92),
        xytext=(6, 0),
        textcoords="offset points",
        color=INK_SECONDARY,
        fontsize=8,
    )
    ax.set_xlabel("pIC$_{50}$")
    ax.set_ylabel("Compounds")
    ax.set_title("Potency distribution")
    _panel_label(ax, "A")

    # B..H -- properties
    panel_props = ["MW", "cLogP", "TPSA", "HBD", "HBA", "RotB", "FractionCSP3"]
    letters = list("BCDEFGH")
    for ax, prop, letter in zip(axes[1:8], panel_props, letters):
        vals = props[prop].dropna()
        ax.hist(vals, bins=28, color=SERIES["train"], edgecolor=SURFACE, linewidth=0.5)
        ax.set_xlabel(prop)
        ax.set_ylabel("Compounds")
        ax.set_title(f"{prop}  (median {vals.median():.1f})")
        _panel_label(ax, letter)

    # I -- Lipinski compliance
    ax = axes[8]
    counts = props["Lipinski_violations"].value_counts().sort_index()
    bars = ax.bar(
        counts.index.astype(str),
        counts.values,
        color=[
            SERIES["test"] if i == 0 else SERIES["extra"] if i == 1 else SERIES["bad"]
            for i in counts.index
        ],
        edgecolor=SURFACE,
        linewidth=1.5,
    )
    for b, v in zip(bars, counts.values):
        ax.annotate(
            f"{v}",
            xy=(b.get_x() + b.get_width() / 2, v),
            xytext=(0, 3),
            textcoords="offset points",
            ha="center",
            fontsize=8,
            color=INK_SECONDARY,
        )
    ax.set_xlabel("Lipinski violations")
    ax.set_ylabel("Compounds")
    ax.set_title(f"Ro5 compliance  ({(props['Lipinski_violations'] == 0).mean():.0%} clean)")
    _panel_label(ax, "I")

    fig.suptitle(
        f"DRD2 dataset characterisation  ·  n = {len(df)} unique parent structures",
        x=0.01,
        ha="left",
        fontsize=13,
        fontweight="semibold",
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    return save(fig, "fig01_data_overview", out_dir, formats)


def plot_property_vs_potency(
    df: pd.DataFrame, props: pd.DataFrame, out_dir: Path, formats=("png", "svg")
) -> list[Path]:
    """Is potency here just a bulk-property effect? Usually not — worth showing."""
    cols = ["MW", "cLogP", "TPSA", "FractionCSP3"]
    fig, axes = plt.subplots(1, 4, figsize=(14, 3.4))
    for ax, col, letter in zip(axes, cols, "ABCD"):
        x = props[col].to_numpy(dtype=float)
        y = df["pIC50"].to_numpy(dtype=float)
        ok = np.isfinite(x) & np.isfinite(y)
        hb = ax.hexbin(x[ok], y[ok], gridsize=26, cmap=CMAP_SEQ, mincnt=1, linewidths=0)
        r = np.corrcoef(x[ok], y[ok])[0, 1]
        ax.set_xlabel(col)
        ax.set_ylabel("pIC$_{50}$" if col == cols[0] else "")
        ax.set_title(f"{col}  ·  r = {r:+.2f}")
        _panel_label(ax, letter)
        cb = fig.colorbar(hb, ax=ax, pad=0.02, fraction=0.045)
        cb.set_label("compounds", fontsize=7, color=INK_MUTED)
        cb.ax.tick_params(labelsize=7, color=INK_MUTED)
    fig.suptitle(
        "Potency versus bulk physicochemical properties",
        x=0.01,
        ha="left",
        fontsize=12,
        fontweight="semibold",
    )
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    return save(fig, "fig02_property_vs_potency", out_dir, formats)


# =========================================================================== #
# 16. Chemical space
# =========================================================================== #
def plot_chemical_space(
    coords: dict[str, np.ndarray],
    df: pd.DataFrame,
    split_idx: dict[str, np.ndarray],
    out_dir: Path,
    formats=("png", "svg"),
) -> list[Path]:
    """UMAP and PCA of the fingerprint space: potency on the left, split on the right.

    The right-hand panel is the visual proof that the scaffold split actually
    separates chemistry — the test points sit in their own regions rather than
    dusted uniformly through the training cloud, which is what a random split
    looks like.
    """
    n = len(coords)
    fig, axes = plt.subplots(n, 2, figsize=(11.5, 5.2 * n), squeeze=False)

    for row, (name, xy) in enumerate(coords.items()):
        # left: coloured by potency (sequential = magnitude)
        ax = axes[row][0]
        sc = ax.scatter(
            xy[:, 0],
            xy[:, 1],
            c=df["pIC50"],
            cmap=CMAP_SEQ,
            s=14,
            linewidths=0.4,
            edgecolors=SURFACE,
        )
        cb = fig.colorbar(sc, ax=ax, pad=0.02, fraction=0.046)
        cb.set_label("pIC$_{50}$", fontsize=8, color=INK_SECONDARY)
        cb.ax.tick_params(labelsize=7, color=INK_MUTED)
        ax.set_title(f"{name.upper()} of ECFP4 — coloured by potency")
        ax.set_xlabel(f"{name.upper()}-1")
        ax.set_ylabel(f"{name.upper()}-2")
        _panel_label(ax, "AC"[row] if row < 2 else str(row))

        # right: coloured by partition (categorical = identity, + markers)
        ax = axes[row][1]
        markers = {"train": "o", "val": "^", "test": "s"}
        for part in ("train", "val", "test"):
            ids = split_idx.get(part)
            if ids is None or len(ids) == 0:
                continue
            ax.scatter(
                xy[ids, 0],
                xy[ids, 1],
                c=SERIES[part],
                s=16,
                marker=markers[part],
                linewidths=0.5,
                edgecolors=SURFACE,
                label=f"{part} (n={len(ids)})",
                alpha=0.85,
            )
        ax.legend(loc="best", markerscale=1.3)
        ax.set_title(f"{name.upper()} of ECFP4 — scaffold split partitions")
        ax.set_xlabel(f"{name.upper()}-1")
        ax.set_ylabel(f"{name.upper()}-2")
        _panel_label(ax, "BD"[row] if row < 2 else str(row))

    fig.tight_layout()
    return save(fig, "fig03_chemical_space", out_dir, formats)


# =========================================================================== #
# 17. Scaffold analysis
# =========================================================================== #
def plot_scaffold_analysis(
    df: pd.DataFrame, out_dir: Path, top_n: int = 20, formats=("png", "svg")
) -> list[Path]:
    """Scaffold frequency and per-scaffold potency spread.

    The long tail matters: if a handful of scaffolds carry most of the data, a
    random split is measuring memorisation of those series.
    """
    counts = df["scaffold"].value_counts()
    top = counts.head(top_n)

    fig, axes = plt.subplots(1, 2, figsize=(13, 5.6), gridspec_kw={"width_ratios": [1, 1.25]})

    ax = axes[0]
    ypos = np.arange(len(top))[::-1]
    ax.barh(ypos, top.values, color=SERIES["train"], edgecolor=SURFACE, linewidth=1.5, height=0.72)
    for y, v in zip(ypos, top.values):
        ax.annotate(
            f"{v}",
            xy=(v, y),
            xytext=(4, 0),
            textcoords="offset points",
            va="center",
            fontsize=7.5,
            color=INK_SECONDARY,
        )
    ax.set_yticks(ypos)
    ax.set_yticklabels([f"S{i + 1}" for i in range(len(top))], fontsize=7.5)
    ax.set_xlabel("Compounds")
    ax.set_ylabel("Bemis–Murcko scaffold rank")
    ax.set_title(
        f"Top {top_n} scaffolds  ·  {counts.size} total  ·  "
        f"top {top_n} cover {top.sum() / len(df):.0%} of the set"
    )
    _panel_label(ax, "A")

    # per-scaffold potency spread for the same top scaffolds
    ax = axes[1]
    data = [df.loc[df["scaffold"] == s, "pIC50"].values for s in top.index]
    bp = ax.boxplot(
        data[::-1],
        vert=False,
        patch_artist=True,
        widths=0.6,
        medianprops={"color": INK_PRIMARY, "linewidth": 1.4},
        flierprops={
            "marker": ".",
            "markersize": 3,
            "markerfacecolor": INK_MUTED,
            "markeredgecolor": "none",
        },
    )
    for patch in bp["boxes"]:
        patch.set_facecolor(SERIES["train"])
        patch.set_alpha(0.55)
        patch.set_edgecolor(SERIES["train"])
    ax.set_yticklabels([f"S{i + 1}" for i in range(len(top))][::-1], fontsize=7.5)
    ax.set_xlabel("pIC$_{50}$")
    ax.set_title("Potency spread within each scaffold series")
    _panel_label(ax, "B")

    singletons = int((counts == 1).sum())
    fig.suptitle(
        f"Scaffold structure of the dataset  ·  {singletons} singleton scaffolds "
        f"({singletons / counts.size:.0%} of frameworks)",
        x=0.01,
        ha="left",
        fontsize=12,
        fontweight="semibold",
    )
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    return save(fig, "fig04_scaffold_analysis", out_dir, formats)


def plot_scaffold_grid(
    df: pd.DataFrame, out_dir: Path, top_n: int = 12, formats=("png",)
) -> list[Path]:
    """Draw the most common scaffolds as actual structures."""
    from rdkit import Chem
    from rdkit.Chem import Draw

    counts = df["scaffold"].value_counts().head(top_n)
    mols, legends = [], []
    for i, (smi, n) in enumerate(counts.items(), start=1):
        m = Chem.MolFromSmiles(smi)
        if m is None:
            continue
        sub = df.loc[df["scaffold"] == smi, "pIC50"]
        mols.append(m)
        legends.append(f"S{i} · n={n} · pIC50 {sub.median():.2f}")
    if not mols:
        return []
    img = Draw.MolsToGridImage(
        mols, molsPerRow=4, subImgSize=(260, 200), legends=legends, useSVG=False
    )
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir / "fig05_scaffold_structures.png"
    data = img.data if hasattr(img, "data") else img
    if isinstance(data, bytes):
        p.write_bytes(data)
    else:
        img.save(p)
    LOGGER.info("Figure -> %s", p)
    return [p]


# =========================================================================== #
# 18. Predicted vs observed
# =========================================================================== #
def plot_pred_vs_obs(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    metrics_text: dict[str, str],
    out_dir: Path,
    ad_score: np.ndarray | None = None,
    title: str = "Predicted vs observed potency (test set)",
    name: str = "fig06_pred_vs_obs",
    noise_floor: float | None = None,
    formats=("png", "svg"),
) -> list[Path]:
    """The headline figure, done properly.

    Fixes every defect of the legacy Yellowbrick plot: equal axes on a shared
    range (so the identity line is at 45°), an explicit ±1 log-unit band that
    states what "good enough" means in medicinal-chemistry terms, colour by
    applicability-domain distance rather than an undifferentiated blue, and
    metrics quoted with confidence intervals instead of a bare number.
    """
    y_true = np.asarray(y_true, float)
    y_pred = np.asarray(y_pred, float)
    lo = float(min(y_true.min(), y_pred.min())) - 0.35
    hi = float(max(y_true.max(), y_pred.max())) + 0.35

    fig, ax = plt.subplots(figsize=(6.6, 6.2))

    # ±1 log-unit band, then identity
    ax.fill_between(
        [lo, hi],
        [lo - 1, hi - 1],
        [lo + 1, hi + 1],
        color=SERIES["train"],
        alpha=0.07,
        linewidth=0,
        zorder=0,
    )
    ax.plot(
        [lo, hi],
        [lo, hi],
        color=INK_SECONDARY,
        linestyle="--",
        linewidth=1.2,
        zorder=2,
        label="identity",
    )

    if ad_score is not None:
        sc = ax.scatter(
            y_true,
            y_pred,
            c=ad_score,
            cmap=CMAP_SEQ,
            s=26,
            linewidths=0.5,
            edgecolors=SURFACE,
            zorder=3,
        )
        cb = fig.colorbar(sc, ax=ax, pad=0.02, fraction=0.045)
        cb.set_label(
            "applicability-domain similarity\n(mean Tanimoto to 5 nearest train)",
            fontsize=7.5,
            color=INK_SECONDARY,
        )
        cb.ax.tick_params(labelsize=7, color=INK_MUTED)
    else:
        ax.scatter(
            y_true,
            y_pred,
            color=SERIES["train"],
            s=26,
            linewidths=0.5,
            edgecolors=SURFACE,
            zorder=3,
        )

    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("Observed pIC$_{50}$")
    ax.set_ylabel("Predicted pIC$_{50}$")
    ax.set_title(title)

    lines = [
        f"R²    {metrics_text.get('R2', '—')}",
        f"RMSE  {metrics_text.get('RMSE', '—')}",
        f"MAE   {metrics_text.get('MAE', '—')}",
        f"ρ     {metrics_text.get('Spearman_rho', '—')}",
        f"within ±1 log  {metrics_text.get('pct_within_1.0', '—')} %",
        f"n = {metrics_text.get('n', '—')}",
    ]
    if noise_floor is not None:
        lines.append(f"assay noise floor  RMSE ≈ {noise_floor:.2f}")
    ax.text(
        0.03,
        0.97,
        "\n".join(lines),
        transform=ax.transAxes,
        va="top",
        ha="left",
        fontsize=8,
        family="monospace",
        color=INK_PRIMARY,
        bbox={"facecolor": SURFACE, "edgecolor": GRID, "boxstyle": "round,pad=0.5"},
    )
    ax.text(
        0.97,
        0.05,
        "shaded band = ±1 log unit",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=7.5,
        color=INK_MUTED,
    )
    ax.legend(loc="lower right", bbox_to_anchor=(1.0, 0.10))
    fig.tight_layout()
    return save(fig, name, out_dir, formats)


# =========================================================================== #
# 19. Residual diagnostics
# =========================================================================== #
def plot_residual_diagnostics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    out_dir: Path,
    noise_floor: float | None = None,
    formats=("png", "svg"),
) -> list[Path]:
    """Residual vs fitted, Q-Q, error by potency decile, and the error histogram."""
    from scipy import stats as sps

    y_true = np.asarray(y_true, float)
    y_pred = np.asarray(y_pred, float)
    resid = y_true - y_pred

    fig, axes = plt.subplots(2, 2, figsize=(11.5, 8.6))

    # A -- residual vs fitted (diverging by sign = polarity)
    ax = axes[0][0]
    vmax = float(np.abs(resid).max())
    sc = ax.scatter(
        y_pred,
        resid,
        c=resid,
        cmap=CMAP_DIV,
        vmin=-vmax,
        vmax=vmax,
        s=24,
        linewidths=0.5,
        edgecolors=SURFACE,
    )
    ax.axhline(0, color=INK_SECONDARY, linewidth=1.2)
    for lvl, ls in ((1.0, "--"), (-1.0, "--")):
        ax.axhline(lvl, color=INK_MUTED, linewidth=0.9, linestyle=ls)
    cb = fig.colorbar(sc, ax=ax, pad=0.02, fraction=0.045)
    cb.set_label("residual (log units)", fontsize=7.5, color=INK_SECONDARY)
    cb.ax.tick_params(labelsize=7, color=INK_MUTED)
    ax.set_xlabel("Predicted pIC$_{50}$")
    ax.set_ylabel("Residual (observed − predicted)")
    ax.set_title("Residuals vs fitted")
    _panel_label(ax, "A")

    # B -- Q-Q
    ax = axes[0][1]
    osm, osr = sps.probplot(resid, dist="norm", fit=False)
    ax.scatter(osm, osr, color=SERIES["train"], s=20, linewidths=0.5, edgecolors=SURFACE)
    lim = [min(osm.min(), osr.min()) - 0.2, max(osm.max(), osr.max()) + 0.2]
    ax.plot(lim, lim, color=INK_SECONDARY, linestyle="--", linewidth=1.2)
    sw = sps.shapiro(resid) if len(resid) <= 5000 else None
    ax.set_xlabel("Theoretical quantiles")
    ax.set_ylabel("Ordered residuals")
    ax.set_title(
        "Normal Q–Q" + (f"  ·  Shapiro–Wilk p = {sw.pvalue:.3g}" if sw is not None else "")
    )
    _panel_label(ax, "B")

    # C -- error by observed-potency decile (exposes regression to the mean)
    ax = axes[1][0]
    n_bins = 8
    edges = np.quantile(y_true, np.linspace(0, 1, n_bins + 1))
    edges[-1] += 1e-9
    mids, rmses, ns, biases = [], [], [], []
    for i in range(n_bins):
        m = (y_true >= edges[i]) & (y_true < edges[i + 1])
        if m.sum() < 2:
            continue
        mids.append((edges[i] + edges[i + 1]) / 2)
        rmses.append(float(np.sqrt(np.mean(resid[m] ** 2))))
        biases.append(float(resid[m].mean()))
        ns.append(int(m.sum()))
    bars = ax.bar(
        mids,
        rmses,
        width=(edges[1] - edges[0]) * 0.75,
        color=SERIES["train"],
        edgecolor=SURFACE,
        linewidth=1.5,
        label="RMSE",
    )
    ax.plot(
        mids,
        biases,
        color=SERIES["accent"],
        marker="o",
        linewidth=2,
        markeredgecolor=SURFACE,
        markeredgewidth=0.8,
        label="mean signed bias",
    )
    ax.axhline(0, color=INK_SECONDARY, linewidth=1)
    if noise_floor is not None:
        ax.axhline(
            noise_floor,
            color=SERIES["bad"],
            linestyle=":",
            linewidth=1.5,
            label=f"assay noise floor ({noise_floor:.2f})",
        )
    for b, nn in zip(bars, ns):
        ax.annotate(
            f"n={nn}",
            xy=(b.get_x() + b.get_width() / 2, b.get_height()),
            xytext=(0, 3),
            textcoords="offset points",
            ha="center",
            fontsize=7,
            color=INK_MUTED,
        )
    ax.set_xlabel("Observed pIC$_{50}$ (binned)")
    ax.set_ylabel("Error (log units)")
    ax.set_title("Error and bias across the potency range")
    ax.legend(loc="upper center", ncols=3)
    _panel_label(ax, "C")

    # D -- residual distribution
    ax = axes[1][1]
    ax.hist(resid, bins=30, color=SERIES["train"], edgecolor=SURFACE, linewidth=0.6)
    ax.axvline(0, color=INK_SECONDARY, linewidth=1.2)
    ax.axvline(
        resid.mean(),
        color=SERIES["accent"],
        linewidth=1.6,
        linestyle="--",
        label=f"mean {resid.mean():+.3f}",
    )
    ax.set_xlabel("Residual (log units)")
    ax.set_ylabel("Compounds")
    ax.set_title(f"Residual distribution  ·  SD = {resid.std(ddof=1):.3f}")
    ax.legend(loc="upper right")
    _panel_label(ax, "D")

    fig.suptitle(
        "Residual diagnostics (test set)", x=0.01, ha="left", fontsize=13, fontweight="semibold"
    )
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    return save(fig, "fig07_residual_diagnostics", out_dir, formats)


# =========================================================================== #
# 20. Learning curve
# =========================================================================== #
def plot_learning_curve(
    lc: pd.DataFrame, out_dir: Path, noise_floor: float | None = None, formats=("png", "svg")
) -> list[Path]:
    """Does more data help? Bands are ±1 SD across repeats."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, metric, letter, better in (
        (axes[0], "RMSE", "A", "lower"),
        (axes[1], "R2", "B", "higher"),
    ):
        x = lc["n_train"].to_numpy()
        m = lc[f"{metric}_mean"].to_numpy()
        s = lc[f"{metric}_std"].to_numpy()
        ax.fill_between(x, m - s, m + s, color=SERIES["train"], alpha=0.18, linewidth=0)
        ax.plot(
            x,
            m,
            color=SERIES["train"],
            marker="o",
            markeredgecolor=SURFACE,
            markeredgewidth=0.8,
            label=f"test {metric}",
        )
        if metric == "RMSE" and noise_floor is not None:
            ax.axhline(
                noise_floor,
                color=SERIES["bad"],
                linestyle=":",
                linewidth=1.6,
                label=f"assay noise floor ({noise_floor:.2f})",
            )
        ax.set_xlabel("Training-set size (compounds)")
        ax.set_ylabel(f"Test {metric}")
        ax.set_title(f"{metric} vs training-set size  ({better} is better)")
        ax.legend(loc="best")
        _panel_label(ax, letter)
    fig.suptitle(
        "Learning curve  ·  band = ±1 SD across repeats",
        x=0.01,
        ha="left",
        fontsize=12,
        fontweight="semibold",
    )
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    return save(fig, "fig08_learning_curve", out_dir, formats)


# =========================================================================== #
# 21. Model comparison forest plot
# =========================================================================== #
def plot_model_forest(
    comp: pd.DataFrame,
    out_dir: Path,
    metric: str = "RMSE",
    reference: str | None = "knn_tanimoto",
    noise_floor: float | None = None,
    display_names: dict[str, str] | None = None,
    formats=("png", "svg"),
) -> list[Path]:
    """The whole benchmark in one panel, read off intervals rather than ranks.

    The vertical reference line is the 1-NN Tanimoto baseline: any model whose
    interval overlaps it has not been shown to beat a similarity lookup.
    """
    display_names = display_names or {}
    comp = comp.copy()
    comp["label"] = comp["model"].map(lambda m: display_names.get(m, m))

    fig, ax = plt.subplots(figsize=(8.4, 0.62 * len(comp) + 2.4))
    ypos = np.arange(len(comp))[::-1]

    ref_val = None
    if reference is not None and reference in set(comp["model"]):
        ref_val = float(comp.loc[comp["model"] == reference, "value"].iloc[0])
        ax.axvline(
            ref_val,
            color=SERIES["val"],
            linestyle="--",
            linewidth=1.4,
            label=f"{display_names.get(reference, reference)} baseline",
            zorder=1,
        )
    if noise_floor is not None and metric == "RMSE":
        ax.axvline(
            noise_floor,
            color=SERIES["bad"],
            linestyle=":",
            linewidth=1.6,
            label=f"assay noise floor ({noise_floor:.2f})",
            zorder=1,
        )

    for y, (_, row) in zip(ypos, comp.iterrows()):
        colour = SERIES["test"] if row["model"] == comp.iloc[0]["model"] else SERIES["train"]
        ax.plot(
            [row["ci_low"], row["ci_high"]],
            [y, y],
            color=colour,
            linewidth=2.4,
            solid_capstyle="round",
            zorder=2,
        )
        ax.plot(
            [row["value"]],
            [y],
            marker="o",
            markersize=8,
            color=colour,
            markeredgecolor=SURFACE,
            markeredgewidth=1.2,
            zorder=3,
        )
        ax.annotate(
            f"{row['value']:.3f} [{row['ci_low']:.3f}, {row['ci_high']:.3f}]",
            xy=(row["ci_high"], y),
            xytext=(8, 0),
            textcoords="offset points",
            va="center",
            fontsize=7.5,
            color=INK_SECONDARY,
        )

    ax.set_yticks(ypos)
    ax.set_yticklabels(comp["label"], fontsize=9)
    ax.set_xlabel(f"Test {metric}  (95% bootstrap CI)")
    ax.set_title(f"Model comparison — {metric} with confidence intervals")
    ax.margins(x=0.24)
    ax.grid(axis="y", visible=False)
    ax.legend(loc="lower right")
    fig.tight_layout()
    return save(fig, f"fig09_model_forest_{metric.lower()}", out_dir, formats)


def plot_split_comparison(
    scaffold_comp: pd.DataFrame,
    random_comp: pd.DataFrame,
    out_dir: Path,
    metric: str = "RMSE",
    display_names: dict[str, str] | None = None,
    formats=("png", "svg"),
) -> list[Path]:
    """Scaffold vs random split, per model — the honesty figure.

    The gap between the two bars is the amount by which a random split flatters
    the model. Publishing it is the difference between a portfolio project and
    a tutorial.
    """
    display_names = display_names or {}
    merged = scaffold_comp.merge(random_comp, on="model", suffixes=("_scaf", "_rand"))
    merged["label"] = merged["model"].map(lambda m: display_names.get(m, m))
    merged = merged.sort_values("value_scaf")

    x = np.arange(len(merged))
    w = 0.38
    fig, ax = plt.subplots(figsize=(1.35 * len(merged) + 3.2, 4.8))
    for offset, suffix, key, colour in (
        (-w / 2 - 0.01, "_rand", "random split", SERIES["val"]),
        (+w / 2 + 0.01, "_scaf", "scaffold split", SERIES["train"]),
    ):
        vals = merged[f"value{suffix}"].to_numpy()
        lo = vals - merged[f"ci_low{suffix}"].to_numpy()
        hi = merged[f"ci_high{suffix}"].to_numpy() - vals
        ax.bar(
            x + offset,
            vals,
            width=w,
            color=colour,
            edgecolor=SURFACE,
            linewidth=2,
            label=key,
            zorder=2,
        )
        ax.errorbar(
            x + offset,
            vals,
            yerr=[lo, hi],
            fmt="none",
            ecolor=INK_SECONDARY,
            elinewidth=1.1,
            capsize=3,
            zorder=3,
        )
    for xi, (_, r) in zip(x, merged.iterrows()):
        delta = r["value_scaf"] - r["value_rand"]
        ax.annotate(
            f"Δ{delta:+.2f}",
            xy=(xi, max(r["ci_high_scaf"], r["ci_high_rand"])),
            xytext=(0, 6),
            textcoords="offset points",
            ha="center",
            fontsize=8,
            color=INK_PRIMARY,
            fontweight="semibold",
        )
    ax.set_xticks(x)
    ax.set_xticklabels(merged["label"], rotation=18, ha="right", fontsize=8.5)
    ax.set_ylabel(f"Test {metric}")
    ax.set_title(
        f"How much does a random split flatter the model?  "
        f"({metric}; higher Δ = more optimistic)"
    )
    ax.legend(loc="upper left")
    ax.grid(axis="x", visible=False)
    fig.tight_layout()
    return save(fig, "fig10_split_comparison", out_dir, formats)


# =========================================================================== #
# 10. Y-scrambling
# =========================================================================== #
def plot_y_scrambling(res: dict, out_dir: Path, formats=("png", "svg")) -> list[Path]:
    """Null distribution of R² under permuted labels, with the real model marked."""
    null = np.asarray(res["null_r2"], float)
    fig, ax = plt.subplots(figsize=(7.4, 4.4))
    ax.hist(
        null,
        bins=24,
        color=INK_MUTED,
        alpha=0.55,
        edgecolor=SURFACE,
        linewidth=0.8,
        label=f"permuted labels (n={res['n_permutations']})",
    )
    ax.axvline(
        res["real_r2"],
        color=SERIES["test"],
        linewidth=2.4,
        label=f"real model  R² = {res['real_r2']:.3f}",
    )
    ax.axvline(
        float(null.mean()),
        color=SERIES["bad"],
        linestyle="--",
        linewidth=1.4,
        label=f"null mean  R² = {null.mean():.3f}",
    )
    ax.set_xlabel("Test R² ")
    ax.set_ylabel("Permutations")
    ax.set_title(f"Y-scrambling (OECD principle 4)  ·  empirical p = {res['p_value']:.3g}")
    ax.legend(loc="upper center")
    fig.tight_layout()
    return save(fig, "fig11_y_scrambling", out_dir, formats)


# =========================================================================== #
# 12. Applicability domain
# =========================================================================== #
def plot_applicability_domain(
    ad_profile: pd.DataFrame,
    train_scores: np.ndarray,
    test_scores: np.ndarray,
    threshold: float,
    out_dir: Path,
    formats=("png", "svg"),
) -> list[Path]:
    """Domain coverage plus the error-versus-distance curve that makes it useful."""
    fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.5))

    ax = axes[0]
    bins = np.linspace(0, 1, 36)
    ax.hist(
        train_scores,
        bins=bins,
        color=SERIES["train"],
        alpha=0.75,
        edgecolor=SURFACE,
        linewidth=0.5,
        label=f"train (n={len(train_scores)})",
    )
    ax.hist(
        test_scores,
        bins=bins,
        color=SERIES["test"],
        alpha=0.75,
        edgecolor=SURFACE,
        linewidth=0.5,
        label=f"test (n={len(test_scores)})",
    )
    ax.axvline(
        threshold,
        color=SERIES["bad"],
        linestyle="--",
        linewidth=1.6,
        label=f"domain threshold ({threshold:.3f})",
    )
    frac_out = float((test_scores < threshold).mean())
    ax.set_xlabel("Mean Tanimoto to 5 nearest training compounds")
    ax.set_ylabel("Compounds")
    ax.set_title(f"Domain coverage  ·  {frac_out:.0%} of test out-of-domain", fontsize=10)
    ax.legend(loc="upper right")
    _panel_label(ax, "A")

    ax = axes[1]
    x = ad_profile["sim_mid"].to_numpy()
    y = ad_profile["RMSE"].to_numpy()
    lo = y - ad_profile["rmse_ci_low"].to_numpy()
    hi = ad_profile["rmse_ci_high"].to_numpy() - y
    ax.errorbar(
        x,
        y,
        yerr=[lo, hi],
        color=SERIES["train"],
        marker="o",
        linewidth=2,
        capsize=4,
        markeredgecolor=SURFACE,
        markeredgewidth=0.9,
        label="test RMSE (95% CI)",
    )
    for xi, yi, ni in zip(x, y, ad_profile["n"]):
        ax.annotate(
            f"n={ni}",
            xy=(xi, yi),
            xytext=(0, -14),
            textcoords="offset points",
            ha="center",
            fontsize=7,
            color=INK_MUTED,
        )
    ax.set_xlabel("Applicability-domain similarity (bin midpoint)")
    ax.set_ylabel("Test RMSE (log units)")
    ax.set_title("Error degrades away from the training domain", fontsize=10)
    ax.legend(loc="upper right")
    _panel_label(ax, "B")

    fig.tight_layout()
    return save(fig, "fig12_applicability_domain", out_dir, formats)


# =========================================================================== #
# 24. Conformal calibration
# =========================================================================== #
def plot_conformal_calibration(
    cov: pd.DataFrame, out_dir: Path, formats=("png", "svg")
) -> list[Path]:
    """Nominal vs empirical coverage, and how wide the intervals have to be."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.3))

    ax = axes[0]
    ax.plot(
        [0, 1],
        [0, 1],
        color=INK_SECONDARY,
        linestyle="--",
        linewidth=1.2,
        label="perfect calibration",
    )
    ax.plot(
        cov["nominal_coverage"],
        cov["empirical_coverage"],
        color=SERIES["train"],
        marker="o",
        markeredgecolor=SURFACE,
        markeredgewidth=0.8,
        label="split-conformal",
    )
    ax.set_xlabel("Nominal coverage (1 − α)")
    ax.set_ylabel("Empirical coverage on test")
    ax.set_title("Prediction-interval calibration")
    ax.set_xlim(0.45, 1.0)
    ax.set_ylim(0.45, 1.0)
    ax.set_aspect("equal", adjustable="box")
    ax.legend(loc="upper left")
    _panel_label(ax, "A")

    ax = axes[1]
    ax.plot(
        cov["nominal_coverage"],
        cov["mean_interval_width"],
        color=SERIES["val"],
        marker="o",
        markeredgecolor=SURFACE,
        markeredgewidth=0.8,
        label="interval width",
    )
    ax.set_xlabel("Nominal coverage (1 − α)")
    ax.set_ylabel("Interval width (log units)")
    ax.set_title("Cost of confidence: how wide the interval must be")
    ax.legend(loc="upper left")
    _panel_label(ax, "B")

    fig.tight_layout()
    return save(fig, "fig13_conformal_calibration", out_dir, formats)


# =========================================================================== #
# 22. SHAP
# =========================================================================== #
def plot_shap_summary(
    shap_values,
    X,
    feature_names,
    out_dir: Path,
    max_display: int = 20,
    formats=("png",),
) -> list[Path]:
    """SHAP beeswarm for the top contributing fingerprint bits."""
    import shap as shap_lib

    fig = plt.figure(figsize=(8.4, 6.4))
    shap_lib.summary_plot(
        shap_values,
        X,
        feature_names=feature_names,
        max_display=max_display,
        show=False,
        plot_size=None,
        color_bar_label="Bit set (1) / absent (0)",
    )
    ax = plt.gca()
    ax.set_xlabel("SHAP value (impact on predicted pIC$_{50}$)")
    ax.set_title(
        "Which substructural bits drive the prediction",
        loc="left",
        fontsize=11,
        fontweight="semibold",
    )
    fig.tight_layout()
    return save(fig, "fig14_shap_summary", out_dir, formats)


def plot_shap_bar(
    importance: pd.DataFrame, out_dir: Path, top_n: int = 20, formats=("png", "svg")
) -> list[Path]:
    """Mean |SHAP| per bit — the ranked version of the beeswarm."""
    top = importance.head(top_n)
    fig, ax = plt.subplots(figsize=(7.6, 0.34 * len(top) + 2.0))
    ypos = np.arange(len(top))[::-1]
    ax.barh(
        ypos,
        top["mean_abs_shap"],
        color=SERIES["train"],
        edgecolor=SURFACE,
        linewidth=1.5,
        height=0.72,
    )
    for y, v in zip(ypos, top["mean_abs_shap"]):
        ax.annotate(
            f"{v:.3f}",
            xy=(v, y),
            xytext=(4, 0),
            textcoords="offset points",
            va="center",
            fontsize=7.5,
            color=INK_SECONDARY,
        )
    ax.set_yticks(ypos)
    ax.set_yticklabels(top["feature"], fontsize=8)
    ax.set_xlabel("Mean |SHAP| (log units)")
    ax.set_title("Most influential features")
    ax.grid(axis="y", visible=False)
    fig.tight_layout()
    return save(fig, "fig15_shap_importance", out_dir, formats)


def plot_bit_substructures(
    records: list[dict], out_dir: Path, name: str = "fig16_shap_substructures"
) -> list[Path]:
    """Draw the atom environments behind the top SHAP bits on real molecules."""
    from rdkit import Chem
    from rdkit.Chem import Draw

    mols, legends, highlights = [], [], []
    for rec in records:
        mol = Chem.MolFromSmiles(rec["smiles"])
        if mol is None:
            continue
        mols.append(mol)
        highlights.append(rec.get("atoms", []))
        legends.append(
            f"bit {rec['bit']} · mean|SHAP| {rec['mean_abs_shap']:.3f} · "
            f"{rec['direction']} potency"
        )
    if not mols:
        return []
    img = Draw.MolsToGridImage(
        mols,
        molsPerRow=3,
        subImgSize=(300, 240),
        legends=legends,
        highlightAtomLists=highlights,
        useSVG=False,
    )
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir / f"{name}.png"
    data = img.data if hasattr(img, "data") else img
    if isinstance(data, bytes):
        p.write_bytes(data)
    else:
        img.save(p)
    LOGGER.info("Figure -> %s", p)
    return [p]


# =========================================================================== #
# 23. Activity cliffs
# =========================================================================== #
def plot_activity_cliffs(pairs: pd.DataFrame, out_dir: Path, max_pairs: int = 6) -> list[Path]:
    """Show the matched pairs where a small structural change moves potency a lot."""
    from rdkit import Chem
    from rdkit.Chem import Draw

    sel = pairs.head(max_pairs)
    mols, legends = [], []
    for _, r in sel.iterrows():
        m1 = Chem.MolFromSmiles(r["smiles_a"])
        m2 = Chem.MolFromSmiles(r["smiles_b"])
        if m1 is None or m2 is None:
            continue
        mols.extend([m1, m2])
        legends.extend(
            [
                f"{r['id_a']}  pIC50 {r['pIC50_a']:.2f}",
                f"{r['id_b']}  pIC50 {r['pIC50_b']:.2f}   "
                f"(ΔpIC50 {r['delta']:.2f}, T={r['similarity']:.2f})",
            ]
        )
    if not mols:
        return []
    img = Draw.MolsToGridImage(
        mols, molsPerRow=2, subImgSize=(320, 250), legends=legends, useSVG=False
    )
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir / "fig17_activity_cliffs.png"
    data = img.data if hasattr(img, "data") else img
    if isinstance(data, bytes):
        p.write_bytes(data)
    else:
        img.save(p)
    LOGGER.info("Figure -> %s", p)
    return [p]


def plot_cliff_landscape(
    sim: np.ndarray,
    delta: np.ndarray,
    out_dir: Path,
    sim_threshold: float = 0.7,
    delta_threshold: float = 2.0,
    formats=("png", "svg"),
) -> list[Path]:
    """SALI-style landscape: structural similarity against potency difference.

    The top-right corner is where QSAR breaks — near-identical molecules with
    very different potency. Any model's residuals concentrate there, and showing
    the region explicitly pre-empts the obvious interview question.
    """
    fig, ax = plt.subplots(figsize=(6.8, 5.4))
    hb = ax.hexbin(sim, delta, gridsize=45, cmap=CMAP_SEQ, bins="log", mincnt=1, linewidths=0)
    cb = fig.colorbar(hb, ax=ax, pad=0.02, fraction=0.046)
    cb.set_label("compound pairs (log scale)", fontsize=8, color=INK_SECONDARY)
    cb.ax.tick_params(labelsize=7, color=INK_MUTED)

    ax.axvline(sim_threshold, color=SERIES["bad"], linestyle="--", linewidth=1.4)
    ax.axhline(delta_threshold, color=SERIES["bad"], linestyle="--", linewidth=1.4)
    n_cliff = int(((sim >= sim_threshold) & (delta >= delta_threshold)).sum())
    ax.annotate(
        f"activity-cliff region\n{n_cliff:,} pairs",
        xy=(sim_threshold, delta_threshold),
        xytext=(10, 12),
        textcoords="offset points",
        fontsize=8,
        color=SERIES["bad"],
        fontweight="semibold",
    )
    ax.set_xlabel("Tanimoto similarity (ECFP4)")
    ax.set_ylabel("|ΔpIC$_{50}$|")
    ax.set_title("Structure–activity landscape")
    fig.tight_layout()
    return save(fig, "fig18_cliff_landscape", out_dir, formats)


# =========================================================================== #
# 35. Descriptor ablation
# =========================================================================== #
def plot_feature_ablation(
    abl: pd.DataFrame, out_dir: Path, metric: str = "RMSE", formats=("png", "svg")
) -> list[Path]:
    """Does the representation matter? Intervals, not a leaderboard."""
    abl = abl.sort_values("value", ascending=metric in ("RMSE", "MAE"))
    fig, ax = plt.subplots(figsize=(8.2, 0.62 * len(abl) + 2.2))
    ypos = np.arange(len(abl))[::-1]
    for y, (_, r) in zip(ypos, abl.iterrows()):
        colour = SERIES["test"] if y == ypos[0] else SERIES["train"]
        ax.plot(
            [r["ci_low"], r["ci_high"]], [y, y], color=colour, linewidth=2.4, solid_capstyle="round"
        )
        ax.plot(
            [r["value"]],
            [y],
            marker="o",
            markersize=8,
            color=colour,
            markeredgecolor=SURFACE,
            markeredgewidth=1.2,
        )
        ax.annotate(
            f"{r['value']:.3f} [{r['ci_low']:.3f}, {r['ci_high']:.3f}]",
            xy=(r["ci_high"], y),
            xytext=(8, 0),
            textcoords="offset points",
            va="center",
            fontsize=7.5,
            color=INK_SECONDARY,
        )
    ax.set_yticks(ypos)
    ax.set_yticklabels(abl["featurizer"], fontsize=9)
    ax.set_xlabel(f"Test {metric}  (95% bootstrap CI)")
    ax.set_title("Molecular representation ablation")
    ax.margins(x=0.24)
    ax.grid(axis="y", visible=False)
    fig.tight_layout()
    return save(fig, "fig19_feature_ablation", out_dir, formats)


# =========================================================================== #
# 13. Multi-seed stability
# =========================================================================== #
def plot_seed_stability(reps: pd.DataFrame, out_dir: Path, formats=("png", "svg")) -> list[Path]:
    """Spread of the headline metrics across repeated splits.

    This is the panel that says how much of a two-model difference is real.
    """
    metrics = ["RMSE", "R2", "Spearman_rho", "MAE"]
    fig, axes = plt.subplots(1, len(metrics), figsize=(3.1 * len(metrics), 4.0))
    for ax, metric, letter in zip(axes, metrics, "ABCD"):
        vals = reps[metric].to_numpy(dtype=float)
        parts = ax.violinplot([vals], showextrema=False, widths=0.7)
        for body in parts["bodies"]:
            body.set_facecolor(SERIES["train"])
            body.set_alpha(0.28)
            body.set_edgecolor(SERIES["train"])
        ax.scatter(
            np.random.default_rng(0).normal(1, 0.045, len(vals)),
            vals,
            color=SERIES["train"],
            s=26,
            linewidths=0.6,
            edgecolors=SURFACE,
            zorder=3,
        )
        ax.errorbar(
            [1],
            [vals.mean()],
            yerr=[[vals.std(ddof=1)], [vals.std(ddof=1)]],
            color=INK_PRIMARY,
            marker="_",
            markersize=22,
            linewidth=1.6,
            capsize=6,
            zorder=4,
        )
        ax.set_xticks([])
        ax.set_ylabel(metric)
        ax.set_title(f"{metric}\n{vals.mean():.3f} ± {vals.std(ddof=1):.3f}")
        _panel_label(ax, letter)
    fig.suptitle(
        f"Stability across {len(reps)} repeated scaffold splits  ·  "
        "point spread = how much a single split can mislead",
        x=0.01,
        ha="left",
        fontsize=12,
        fontweight="semibold",
    )
    fig.tight_layout(rect=(0, 0, 1, 0.9))
    return save(fig, "fig20_seed_stability", out_dir, formats)


# =========================================================================== #
# Curation audit
# =========================================================================== #
def plot_curation_waterfall(
    audit: pd.DataFrame, out_dir: Path, formats=("png", "svg")
) -> list[Path]:
    """How many compounds each curation stage removed — the data-integrity figure."""
    a = audit[audit["stage"] != "13_final"].copy()
    fig, ax = plt.subplots(figsize=(10.5, 5.0))
    x = np.arange(len(a))
    ax.bar(
        x,
        a["n_after"],
        color=SERIES["train"],
        edgecolor=SURFACE,
        linewidth=1.8,
        label="rows retained",
        zorder=2,
    )
    removed = a["n_removed"].to_numpy()
    ax.bar(
        x,
        removed,
        bottom=a["n_after"],
        color=SERIES["bad"],
        alpha=0.8,
        edgecolor=SURFACE,
        linewidth=1.8,
        label="removed at this stage",
        zorder=2,
    )
    for xi, (after, rem) in enumerate(zip(a["n_after"], removed)):
        if rem > 0:
            ax.annotate(
                f"−{rem}",
                xy=(xi, after + rem),
                xytext=(0, 4),
                textcoords="offset points",
                ha="center",
                fontsize=8,
                color=SERIES["bad"],
                fontweight="semibold",
            )
    ax.set_xticks(x)
    ax.set_xticklabels(
        [s.split("_", 1)[1].replace("_", " ") for s in a["stage"]],
        rotation=32,
        ha="right",
        fontsize=8,
    )
    ax.set_ylabel("Activity records")
    ax.set_title("Curation audit trail — every removed record has a recorded reason")
    ax.legend(loc="upper right")
    ax.grid(axis="x", visible=False)
    fig.tight_layout()
    return save(fig, "fig00_curation_waterfall", out_dir, formats)
