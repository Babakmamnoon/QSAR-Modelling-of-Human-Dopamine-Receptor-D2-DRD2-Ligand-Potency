"""DRD2 QSAR — an end-to-end, reproducible QSAR regression pipeline.

Modules
-------
config      Typed configuration loaded from YAML.
chembl      Live ChEMBL ingestion with provenance manifest.
curate      Structure standardization, sanity filtering, replicate aggregation.
features    Molecular featurizer zoo (fingerprints + descriptors).
splits      Scaffold / random / Butina / temporal partitioning.
models      Baseline ladder of scikit-learn-compatible regressors.
evaluate    Metrics with bootstrap CIs, y-scrambling, applicability domain, conformal.
interpret   SHAP attribution and matched-molecular-pair activity cliffs.
plots       The publication figure suite.
run         CLI entry point orchestrating the whole pipeline.
predict     Inference on new SMILES with AD flags and prediction intervals.
"""

__version__ = "1.0.0"

__all__ = [
    "config",
    "chembl",
    "curate",
    "features",
    "splits",
    "models",
    "evaluate",
    "interpret",
    "plots",
]
