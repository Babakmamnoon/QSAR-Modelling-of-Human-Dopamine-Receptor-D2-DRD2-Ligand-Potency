"""Dataset partitioning: scaffold, random, Butina cluster and temporal.

Why the default is a scaffold split
-----------------------------------
ChEMBL target sets are dominated by congeneric series — dozens of analogues
around one core, published together. A random split puts near-identical
analogues on both sides of the train/test line, so the test set measures
interpolation within a series the model has already memorised. The number that
comes out is real but it answers the wrong question.

A Bemis–Murcko scaffold split forces whole chemical series to land entirely in
one partition. The resulting score is lower and it is the one that predicts what
happens when the model meets next quarter's chemistry. This pipeline reports
both, side by side, and treats the gap between them as a headline result rather
than something to bury.

Splits are three-way (train / validation / test). Validation is used for early
stopping and model selection; the test set is touched exactly once, at the end.
"""

from __future__ import annotations

import logging
from collections import defaultdict

import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold

LOGGER = logging.getLogger("drd2_qsar.splits")


# --------------------------------------------------------------------------- #
# Scaffolds
# --------------------------------------------------------------------------- #
def murcko_scaffold(smiles: str, include_chirality: bool = False) -> str:
    """Bemis–Murcko framework as canonical SMILES; '' for acyclic molecules."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return ""
    try:
        scaf = MurckoScaffold.GetScaffoldForMol(mol)
        return Chem.MolToSmiles(scaf, isomericSmiles=include_chirality)
    except Exception:
        return ""


def add_scaffolds(df: pd.DataFrame, include_chirality: bool = False) -> pd.DataFrame:
    out = df.copy()
    out["scaffold"] = [murcko_scaffold(s, include_chirality) for s in out["smiles"]]
    # acyclic molecules have no framework; treat each as its own singleton group
    empty = out["scaffold"] == ""
    out.loc[empty, "scaffold"] = [f"__acyclic_{i}" for i in range(int(empty.sum()))]
    LOGGER.info(
        "%d unique Bemis-Murcko scaffolds across %d compounds (%.2f compounds/scaffold)",
        out["scaffold"].nunique(),
        len(out),
        len(out) / max(out["scaffold"].nunique(), 1),
    )
    return out


def scaffold_split(
    df: pd.DataFrame,
    test_size: float = 0.2,
    val_size: float = 0.1,
    balanced: bool = True,
    include_chirality: bool = False,
    seed: int = 42,
) -> dict[str, np.ndarray]:
    """Partition so that no Bemis–Murcko scaffold spans two subsets.

    ``balanced=True`` uses greedy bin-packing over scaffold groups sorted by
    descending size: the largest series go to train (where the model needs the
    density) and the long tail fills validation and test. ``balanced=False``
    reproduces the classic DeepChem behaviour of filling train first in
    size order.
    """
    work = add_scaffolds(df, include_chirality)
    groups: dict[str, list[int]] = defaultdict(list)
    for pos, (_, row) in enumerate(work.iterrows()):
        groups[row["scaffold"]].append(pos)

    # Order by descending group size, breaking ties with a seeded shuffle. Without
    # the seeded tie-break the ordering is fully determined by the data, the seed
    # does nothing, and the multi-seed stability analysis silently reports zero
    # variance — a split that cannot vary cannot measure split variance.
    rng = np.random.default_rng(seed)
    group_list = list(groups.values())
    tiebreak = rng.permutation(len(group_list))
    ordered = [
        group_list[i]
        for i in sorted(range(len(group_list)), key=lambda i: (-len(group_list[i]), tiebreak[i]))
    ]

    n = len(work)
    n_test = int(round(test_size * n))
    n_val = int(round(val_size * n))
    n_train = n - n_test - n_val

    train: list[int] = []
    val: list[int] = []
    test: list[int] = []

    if balanced:
        caps = {"train": n_train, "val": n_val, "test": n_test}
        buckets = {"train": train, "val": val, "test": test}
        for group in ordered:
            # place the group where it leaves the least overflow, preferring train
            deficits = {k: caps[k] - len(buckets[k]) for k in caps}
            choice = max(deficits, key=lambda k: (deficits[k], k == "train"))
            buckets[choice].extend(group)
    else:
        for group in ordered:
            if len(train) + len(group) <= n_train:
                train.extend(group)
            elif len(val) + len(group) <= n_val:
                val.extend(group)
            else:
                test.extend(group)

    idx = {
        k: np.asarray(sorted(v), dtype=int)
        for k, v in (("train", train), ("val", val), ("test", test))
    }
    _log_split(work, idx, "scaffold")
    _assert_no_scaffold_leak(work, idx)
    return idx


def random_split(
    df: pd.DataFrame, test_size: float = 0.2, val_size: float = 0.1, seed: int = 42
) -> dict[str, np.ndarray]:
    """Plain random partition — reported only as the optimistic comparison."""
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(df))
    n_test = int(round(test_size * len(df)))
    n_val = int(round(val_size * len(df)))
    idx = {
        "test": np.sort(perm[:n_test]),
        "val": np.sort(perm[n_test : n_test + n_val]),
        "train": np.sort(perm[n_test + n_val :]),
    }
    _log_split(df, idx, "random")
    return idx


def butina_split(
    df: pd.DataFrame,
    cutoff: float = 0.65,
    test_size: float = 0.2,
    val_size: float = 0.1,
    seed: int = 42,
) -> dict[str, np.ndarray]:
    """Cluster-based split using Taylor–Butina clustering on ECFP4.

    Stricter than a scaffold split in some respects: it groups by whole-molecule
    similarity rather than by framework, so analogues that differ in framework
    but remain close neighbours still cannot straddle the split.
    """
    from rdkit.ML.Cluster import Butina

    from .features import rdkit_fps

    fps = rdkit_fps(df["smiles"].tolist())
    valid = [i for i, f in enumerate(fps) if f is not None]
    from rdkit import DataStructs

    dists: list[float] = []
    for i in range(1, len(valid)):
        sims = DataStructs.BulkTanimotoSimilarity(fps[valid[i]], [fps[valid[j]] for j in range(i)])
        dists.extend(1.0 - s for s in sims)
    clusters = Butina.ClusterData(dists, len(valid), 1.0 - cutoff, isDistData=True)
    groups = [[valid[i] for i in c] for c in clusters]
    groups.sort(key=lambda g: (-len(g), g[0]))

    n = len(df)
    n_test, n_val = int(round(test_size * n)), int(round(val_size * n))
    n_train = n - n_test - n_val
    caps = {"train": n_train, "val": n_val, "test": n_test}
    buckets: dict[str, list[int]] = {"train": [], "val": [], "test": []}
    for g in groups:
        deficits = {k: caps[k] - len(buckets[k]) for k in caps}
        choice = max(deficits, key=lambda k: (deficits[k], k == "train"))
        buckets[choice].extend(g)
    idx = {k: np.asarray(sorted(v), dtype=int) for k, v in buckets.items()}
    LOGGER.info("Butina clustering at cutoff %.2f gave %d clusters", cutoff, len(groups))
    _log_split(df, idx, "butina")
    return idx


def temporal_split(
    df: pd.DataFrame,
    year_column: str = "year",
    train_before: int = 2015,
    val_fraction_of_train: float = 0.125,
    seed: int = 42,
) -> dict[str, np.ndarray]:
    """Train on older literature, test on newer — the closest thing to prospective.

    Requires a usable publication-year column. If too few rows carry a year the
    caller should fall back to the scaffold split; ``ValueError`` is raised so
    that fallback is explicit rather than silent.
    """
    if year_column not in df.columns:
        raise ValueError(f"No '{year_column}' column for a temporal split")
    years = pd.to_numeric(df[year_column], errors="coerce")
    usable = years.notna()
    if usable.mean() < 0.5:
        raise ValueError(
            f"Only {usable.mean():.0%} of rows carry a publication year; "
            "a temporal split would be dominated by missing metadata"
        )
    pos = np.arange(len(df))
    train_pool = pos[(years < train_before).fillna(False).to_numpy()]
    test_idx = pos[(years >= train_before).fillna(False).to_numpy()]
    rng = np.random.default_rng(seed)
    train_pool = rng.permutation(train_pool)
    n_val = int(round(val_fraction_of_train * len(train_pool)))
    idx = {
        "val": np.sort(train_pool[:n_val]),
        "train": np.sort(train_pool[n_val:]),
        "test": np.sort(test_idx),
    }
    _log_split(df, idx, f"temporal(<{train_before})")
    return idx


# --------------------------------------------------------------------------- #
# Dispatch + integrity checks
# --------------------------------------------------------------------------- #
def make_split(df: pd.DataFrame, cfg_split: dict, seed: int = 42) -> dict[str, np.ndarray]:
    strategy = cfg_split.get("strategy", "scaffold")
    test_size = float(cfg_split.get("test_size", 0.2))
    val_size = float(cfg_split.get("val_size", 0.1))

    if strategy == "scaffold":
        sc = cfg_split.get("scaffold", {})
        return scaffold_split(
            df,
            test_size=test_size,
            val_size=val_size,
            balanced=bool(sc.get("balanced", True)),
            include_chirality=bool(sc.get("include_chirality", False)),
            seed=seed,
        )
    if strategy == "random":
        return random_split(df, test_size, val_size, seed)
    if strategy == "butina":
        return butina_split(
            df,
            float(cfg_split.get("butina", {}).get("cutoff", 0.65)),
            test_size,
            val_size,
            seed,
        )
    if strategy == "temporal":
        t = cfg_split.get("temporal", {})
        return temporal_split(
            df, t.get("year_column", "year"), int(t.get("train_before", 2015)), seed=seed
        )
    raise ValueError(f"Unknown split strategy: {strategy!r}")


def _log_split(df: pd.DataFrame, idx: dict[str, np.ndarray], label: str) -> None:
    parts = " | ".join(f"{k}={len(v)} ({len(v) / max(len(df), 1):.1%})" for k, v in idx.items())
    LOGGER.info("%s split -> %s", label, parts)


def _assert_no_scaffold_leak(df: pd.DataFrame, idx: dict[str, np.ndarray]) -> None:
    sets = {k: set(df.iloc[v]["scaffold"]) for k, v in idx.items()}
    for a, b in (("train", "test"), ("train", "val"), ("val", "test")):
        overlap = sets[a] & sets[b]
        if overlap:
            raise AssertionError(
                f"Scaffold leakage between {a} and {b}: {len(overlap)} shared scaffolds"
            )
    LOGGER.info("Scaffold-leakage check passed: no framework spans two partitions")


def assert_no_structure_leak(df: pd.DataFrame, idx: dict[str, np.ndarray]) -> None:
    """Hard guarantee that no identical structure appears in two partitions."""
    key = "inchikey14" if "inchikey14" in df.columns else "smiles"
    sets = {k: set(df.iloc[v][key]) for k, v in idx.items()}
    for a, b in (("train", "test"), ("train", "val"), ("val", "test")):
        overlap = sets[a] & sets[b]
        if overlap:
            raise AssertionError(
                f"Structure leakage between {a} and {b}: {len(overlap)} shared {key}"
            )
    LOGGER.info("Structure-leakage check passed on '%s'", key)


def split_summary(df: pd.DataFrame, idx: dict[str, np.ndarray]) -> pd.DataFrame:
    """Per-partition size and potency distribution — goes straight into the README."""
    rows = []
    for name, ids in idx.items():
        sub = df.iloc[ids]
        rows.append(
            {
                "partition": name,
                "n": len(sub),
                "fraction": len(sub) / max(len(df), 1),
                "pIC50_mean": sub["pIC50"].mean(),
                "pIC50_std": sub["pIC50"].std(),
                "pIC50_min": sub["pIC50"].min(),
                "pIC50_max": sub["pIC50"].max(),
                "n_scaffolds": sub["scaffold"].nunique() if "scaffold" in sub else np.nan,
            }
        )
    return pd.DataFrame(rows)
