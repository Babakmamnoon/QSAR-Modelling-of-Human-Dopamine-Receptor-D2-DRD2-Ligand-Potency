"""The baseline ladder.

A QSAR result is only interpretable relative to what a trivial method achieves
on the same split. This module defines the ladder, from "predict the mean" up to
gradient boosting, so every reported number has a floor to be compared against.

The rungs
---------
``dummy_mean``      Predicts the training mean. R² = 0 by construction on the
                    training distribution; any model below this is broken.
``knn_tanimoto``    1-nearest-neighbour by Tanimoto similarity — "find the most
                    similar molecule you have already measured and copy its
                    number". On congeneric ChEMBL sets this is *hard to beat*,
                    and a model that fails to beat it has learned nothing a
                    lookup table does not already contain. This is the single
                    most important baseline in the ladder and it is the one
                    most often omitted.
``ridge``           Linear model on the fingerprint; tests whether the
                    structure–activity relationship is essentially additive.
``random_forest``   Robust, low-maintenance non-linear baseline.
``svr``             RBF-kernel SVR, the classical QSAR strong baseline.
``xgboost``         Gradient boosting; usually the production choice.
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np
from scipy.stats import loguniform, randint, uniform
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR

LOGGER = logging.getLogger("drd2_qsar.models")


# --------------------------------------------------------------------------- #
# Tanimoto k-NN — the baseline that matters
# --------------------------------------------------------------------------- #
class TanimotoKNNRegressor(BaseEstimator, RegressorMixin):
    """k-NN regression with Tanimoto similarity on binary fingerprints.

    Tanimoto is not available in scikit-learn's metric set, so it is computed
    directly: for binary vectors, ``T(a,b) = |a AND b| / (|a| + |b| - |a AND b|)``,
    which vectorises to a single matrix product plus two row sums.
    """

    def __init__(self, n_neighbors: int = 1, weighted: bool = True):
        self.n_neighbors = n_neighbors
        self.weighted = weighted

    def fit(self, X, y):
        self.X_ = np.asarray(X, dtype=np.float32)
        self.y_ = np.asarray(y, dtype=np.float64)
        self.X_popcount_ = self.X_.sum(axis=1)
        return self

    def _similarity(self, X):
        X = np.asarray(X, dtype=np.float32)
        inter = X @ self.X_.T
        union = X.sum(axis=1)[:, None] + self.X_popcount_[None, :] - inter
        with np.errstate(divide="ignore", invalid="ignore"):
            sim = np.where(union > 0, inter / union, 0.0)
        return sim

    def predict(self, X):
        sim = self._similarity(X)
        k = min(self.n_neighbors, self.X_.shape[0])
        nn = np.argpartition(-sim, kth=k - 1, axis=1)[:, :k]
        rows = np.arange(sim.shape[0])[:, None]
        nn_sim = sim[rows, nn]
        nn_y = self.y_[nn]
        if self.weighted and k > 1:
            w = np.clip(nn_sim, 1e-8, None)
            return (nn_y * w).sum(axis=1) / w.sum(axis=1)
        return nn_y.mean(axis=1)

    def nearest_similarity(self, X) -> np.ndarray:
        """Max Tanimoto to the training set — reused by the applicability domain."""
        return self._similarity(X).max(axis=1)


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #
def _xgb(seed: int, n_jobs: int):
    from xgboost import XGBRegressor

    return XGBRegressor(
        n_estimators=600,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.8,
        colsample_bytree=0.6,
        min_child_weight=3,
        reg_lambda=1.0,
        objective="reg:squarederror",
        tree_method="hist",
        random_state=seed,
        n_jobs=n_jobs,
        verbosity=0,
    )


def get_model(name: str, seed: int = 42, n_jobs: int = -1, scale: bool = False):
    """Instantiate a model by name. ``scale`` wraps it in a StandardScaler."""
    name = name.lower()
    if name == "dummy_mean":
        est: Any = DummyRegressor(strategy="mean")
    elif name in ("knn_tanimoto", "knn"):
        est = TanimotoKNNRegressor(n_neighbors=1)
    elif name == "knn_tanimoto_k5":
        est = TanimotoKNNRegressor(n_neighbors=5, weighted=True)
    elif name == "ridge":
        est = Ridge(alpha=1.0, random_state=seed)
    elif name == "random_forest":
        est = RandomForestRegressor(
            n_estimators=500,
            max_features="sqrt",
            min_samples_leaf=1,
            n_jobs=n_jobs,
            random_state=seed,
        )
    elif name == "svr":
        est = SVR(C=10.0, gamma="scale", epsilon=0.1, kernel="rbf")
        scale = True
    elif name == "xgboost":
        est = _xgb(seed, n_jobs)
    else:
        raise ValueError(f"Unknown model: {name!r}")

    if scale:
        return Pipeline([("scale", StandardScaler(with_mean=False)), ("model", est)])
    return est


# --------------------------------------------------------------------------- #
# Hyperparameter search spaces (for the inner loop of the nested CV)
# --------------------------------------------------------------------------- #
def get_param_distributions(name: str) -> dict[str, Any]:
    """Randomized-search space per model. Empty dict = nothing to tune."""
    name = name.lower()
    if name == "ridge":
        return {"alpha": loguniform(1e-3, 1e3)}
    if name in ("knn_tanimoto", "knn"):
        return {"n_neighbors": randint(1, 16)}
    if name == "random_forest":
        return {
            "n_estimators": randint(200, 900),
            "max_depth": randint(6, 40),
            "min_samples_leaf": randint(1, 8),
            "max_features": ["sqrt", "log2", 0.3],
        }
    if name == "svr":
        return {
            "model__C": loguniform(1e-1, 1e3),
            "model__gamma": loguniform(1e-5, 1e-1),
            "model__epsilon": uniform(0.01, 0.4),
        }
    if name == "xgboost":
        return {
            "n_estimators": randint(200, 1200),
            "max_depth": randint(3, 11),
            "learning_rate": loguniform(1e-2, 3e-1),
            "subsample": uniform(0.6, 0.4),
            "colsample_bytree": uniform(0.3, 0.7),
            "min_child_weight": randint(1, 10),
            "reg_lambda": loguniform(1e-2, 1e2),
        }
    return {}


MODEL_DISPLAY_NAMES = {
    "dummy_mean": "Mean predictor",
    "knn_tanimoto": "1-NN (Tanimoto)",
    "knn_tanimoto_k5": "5-NN (Tanimoto, weighted)",
    "ridge": "Ridge regression",
    "random_forest": "Random Forest",
    "svr": "SVR (RBF)",
    "xgboost": "XGBoost",
}
